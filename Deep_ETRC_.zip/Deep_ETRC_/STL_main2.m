function STL_main2()
    % STL_main2 - Academic Paper Version STL Decomposition Visualization
    % Displays data from 2021/10/1 to 2022/10/1 with enhanced aesthetics for academic publications
    
    %% ======================== HYPERPARAMETERS ========================
    % STL Decomposition Parameters
    SEASONAL_PERIOD = 24;           % 24-hour seasonal period
    SEASONAL_WINDOW = 7;            % Seasonal smoothing window (7 periods)
    TREND_WINDOW = 25;              % Trend smoothing window
    ROBUST_FLAG = true;             % Use robust STL decomposition
    
    % Date Range for Analysis
    START_DATE = datetime(2021, 10, 1);
    END_DATE = datetime(2022, 10, 1);
    
    % File Paths
    DATA_PATH = 'D:\eqrthquake\太阳能发电供需预测\代码\Deep_ER-RC_exp\merged_data.csv';
    OUTPUT_DIR = 'D:\eqrthquake\太阳能发电供需预测\代码\STL-DeepETRC_分析\Deep_ETRC_EXP\results';
    
    % Visualization Settings
    FIGURE_WIDTH = 1200;            % Figure width in pixels
    FIGURE_HEIGHT = 900;            % Figure height in pixels
    DPI = 300;                      % High DPI for publication quality
    
    %% ======================== LOAD AND FILTER DATA ========================
    fprintf('Loading data from: %s\n', DATA_PATH);
    
    % Read the CSV file
    data = readtable(DATA_PATH);
    
    % Convert datetime column
    data.datetime = datetime(data.datetime, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
    
    % Filter data for the specified date range
    date_mask = data.datetime >= START_DATE & data.datetime < END_DATE;
    filtered_data = data(date_mask, :);
    
    fprintf('Data loaded successfully. Filtered records: %d\n', height(filtered_data));
    fprintf('Time range: %s to %s\n', datestr(START_DATE), datestr(END_DATE));
    
    % Extract time series data
    supply_data = filtered_data.target_0;  % Solar power supply
    demand_data = filtered_data.target_1;  % Power demand
    time_vector = filtered_data.datetime;
    
    %% ======================== PERFORM STL DECOMPOSITION ========================
    fprintf('Performing STL decomposition...\n');
    
    % Decompose supply data
    fprintf('Decomposing supply data...\n');
    [supply_trend, supply_seasonal, supply_remainder] = perform_stl_decomposition(...
        supply_data, SEASONAL_PERIOD, SEASONAL_WINDOW, TREND_WINDOW, ROBUST_FLAG);
    
    % Decompose demand data
    fprintf('Decomposing demand data...\n');
    [demand_trend, demand_seasonal, demand_remainder] = perform_stl_decomposition(...
        demand_data, SEASONAL_PERIOD, SEASONAL_WINDOW, TREND_WINDOW, ROBUST_FLAG);
    
    fprintf('STL decomposition completed successfully.\n');
    
    %% ======================== CREATE ACADEMIC VISUALIZATIONS ========================
    fprintf('Creating academic-quality visualizations...\n');
    
    % Create output directory if it doesn't exist
    if ~exist(OUTPUT_DIR, 'dir')
        mkdir(OUTPUT_DIR);
    end
    
    % Generate supply decomposition plot
    create_academic_stl_plot(time_vector, supply_data, supply_trend, supply_seasonal, supply_remainder, ...
        'Supply', OUTPUT_DIR, 'stl_decomposition_supply_academic.png', FIGURE_WIDTH, FIGURE_HEIGHT, DPI);
    
    % Generate demand decomposition plot
    create_academic_stl_plot(time_vector, demand_data, demand_trend, demand_seasonal, demand_remainder, ...
        'Demand', OUTPUT_DIR, 'stl_decomposition_demand_academic.png', FIGURE_WIDTH, FIGURE_HEIGHT, DPI);
    
    %% ======================== PRINT SUMMARY STATISTICS ========================
    print_decomposition_summary(supply_data, supply_trend, supply_seasonal, supply_remainder, 'Supply');
    print_decomposition_summary(demand_data, demand_trend, demand_seasonal, demand_remainder, 'Demand');
    
    fprintf('\nAcademic STL decomposition analysis completed successfully!\n');
    fprintf('Results saved to: %s\n', OUTPUT_DIR);
end

%% ======================== HELPER FUNCTIONS ========================

function [trend, seasonal, remainder] = perform_stl_decomposition(data, period, seasonal_window, trend_window, robust)
    % Perform STL decomposition using existing STL function
    
    % Remove NaN values
    valid_idx = ~isnan(data);
    clean_data = data(valid_idx);
    
    if length(clean_data) < 2 * period
        error('Insufficient data for STL decomposition. Need at least %d points.', 2 * period);
    end
    
    % Create U structure for STL function
    U_temp.u_train = clean_data;
    U_temp.u_test = [];
    U_temp.y_train = [];
    U_temp.y_test = [];
    
    % Call existing STL function
    U_decomposed = STL(U_temp, period);
    
    % Extract decomposed components
    seasonal_clean = U_decomposed.u_train(:, 1, 1);  % Seasonal component
    trend_clean = U_decomposed.u_train(:, 1, 2);     % Trend component
    remainder_clean = U_decomposed.u_train(:, 1, 3); % Remainder component
    
    % Initialize output arrays with NaN
    trend = NaN(size(data));
    seasonal = NaN(size(data));
    remainder = NaN(size(data));
    
    % Fill in the decomposed values
    trend(valid_idx) = trend_clean;
    seasonal(valid_idx) = seasonal_clean;
    remainder(valid_idx) = remainder_clean;
end

function create_academic_stl_plot(time_vector, original, trend, seasonal, remainder, data_type, output_dir, filename, fig_width, fig_height, dpi)
    % Create publication-quality STL decomposition plot with academic styling
    
    % Academic color palette - Uniform blue theme
    colors = struct();
    colors.original = [0.2, 0.4, 0.8];           % Blue
    colors.trend = [0.2, 0.4, 0.8];              % Blue
    colors.seasonal = [0.2, 0.4, 0.8];           % Blue
    colors.remainder = [0.2, 0.4, 0.8];          % Blue
    colors.grid = [0.9, 0.9, 0.9];               % Light gray
    
    % Create figure with specific dimensions
    fig = figure('Position', [100, 100, fig_width, fig_height], ...
                 'Color', 'white', 'PaperPositionMode', 'auto');
    
    % Set up subplot layout with better spacing to avoid overlap
    subplot_positions = [
        0.10, 0.78, 0.85, 0.16;  % Original data
        0.10, 0.58, 0.85, 0.16;  % Trend
        0.10, 0.38, 0.85, 0.16;  % Seasonal
        0.10, 0.15, 0.85, 0.16   % Remainder
    ];
    
    % Plot original data
    ax1 = subplot('Position', subplot_positions(1,:));
    plot(time_vector, original, 'Color', colors.original, 'LineWidth', 1.2);
    title(sprintf('Original %s Data (Oct 2021 - Oct 2022)', data_type), ...
          'FontSize', 11, 'FontWeight', 'bold', 'FontName', 'Times New Roman');
    ylabel(sprintf('%s (kWh)', data_type), 'FontSize', 10, 'FontName', 'Times New Roman');
    grid on; grid minor;
    set(gca, 'GridColor', colors.grid, 'MinorGridColor', colors.grid, ...
             'FontSize', 9, 'FontName', 'Times New Roman');
    set(gca, 'YTickLabelMode', 'manual');
    yticks = get(gca, 'YTick');
    set(gca, 'YTickLabel', arrayfun(@(x) sprintf('%.0f', x), yticks, 'UniformOutput', false));
    
    % Plot trend component
    ax2 = subplot('Position', subplot_positions(2,:));
    plot(time_vector, trend, 'Color', colors.trend, 'LineWidth', 1.5);
    title('Trend Component', 'FontSize', 11, 'FontWeight', 'bold', 'FontName', 'Times New Roman');
    ylabel('Trend (kWh)', 'FontSize', 10, 'FontName', 'Times New Roman');
    grid on; grid minor;
    set(gca, 'GridColor', colors.grid, 'MinorGridColor', colors.grid, ...
             'FontSize', 9, 'FontName', 'Times New Roman');
    set(gca, 'YTickLabelMode', 'manual');
    yticks = get(gca, 'YTick');
    set(gca, 'YTickLabel', arrayfun(@(x) sprintf('%.0f', x), yticks, 'UniformOutput', false));
    
    % Plot seasonal component
    ax3 = subplot('Position', subplot_positions(3,:));
    plot(time_vector, seasonal, 'Color', colors.seasonal, 'LineWidth', 1.2);
    title('Seasonal Component', 'FontSize', 11, 'FontWeight', 'bold', 'FontName', 'Times New Roman');
    ylabel('Seasonal (kWh)', 'FontSize', 10, 'FontName', 'Times New Roman');
    grid on; grid minor;
    set(gca, 'GridColor', colors.grid, 'MinorGridColor', colors.grid, ...
             'FontSize', 9, 'FontName', 'Times New Roman');
    set(gca, 'YTickLabelMode', 'manual');
    yticks = get(gca, 'YTick');
    set(gca, 'YTickLabel', arrayfun(@(x) sprintf('%.0f', x), yticks, 'UniformOutput', false));
    
    % Plot remainder component
    ax4 = subplot('Position', subplot_positions(4,:));
    plot(time_vector, remainder, 'Color', colors.remainder, 'LineWidth', 1.0);
    title('Remainder Component', 'FontSize', 11, 'FontWeight', 'bold', 'FontName', 'Times New Roman');
    ylabel('Remainder (kWh)', 'FontSize', 10, 'FontName', 'Times New Roman');
    xlabel('Time', 'FontSize', 10, 'FontName', 'Times New Roman');
    grid on; grid minor;
    set(gca, 'GridColor', colors.grid, 'MinorGridColor', colors.grid, ...
             'FontSize', 9, 'FontName', 'Times New Roman');
    set(gca, 'YTickLabelMode', 'manual');
    yticks = get(gca, 'YTick');
    set(gca, 'YTickLabel', arrayfun(@(x) sprintf('%.0f', x), yticks, 'UniformOutput', false));
    
    % Synchronize x-axes
    linkaxes([ax1, ax2, ax3, ax4], 'x');
    
    % Set x-axis formatting for all subplots
    axes_list = [ax1, ax2, ax3, ax4];
    for i = 1:length(axes_list)
        axes(axes_list(i));
        xlim([time_vector(1), time_vector(end)]);
        
        % Set month ticks
        month_ticks = datetime(2021, 10:15, 1);  % Oct 2021 to Mar 2023
        month_ticks = month_ticks(month_ticks >= time_vector(1) & month_ticks <= time_vector(end));
        
        if i == length(axes_list)  % Only show x-labels on bottom subplot
            set(gca, 'XTick', month_ticks);
            set(gca, 'XTickLabel', datestr(month_ticks, 'mmm yyyy'));
            xtickangle(45);
        else
            set(gca, 'XTickLabel', []);
        end
    end
    
    % Add overall title with consistent font size
    sgtitle(sprintf('STL Decomposition of %s Data', data_type), ...
            'FontSize', 13, 'FontWeight', 'bold', 'FontName', 'Times New Roman');
    
    % Save the figure
    output_path = fullfile(output_dir, filename);
    print(fig, output_path, '-dpng', sprintf('-r%d', dpi));
    fprintf('%s decomposition saved: %s\n', data_type, output_path);
    
    % Keep the figure open for viewing (don't close automatically)
    % close(fig);  % Commented out to keep figure open
end

function print_decomposition_summary(original, trend, seasonal, remainder, data_type)
    % Print detailed statistics for decomposition components
    
    fprintf('\n%s Data:\n', data_type);
    
    % Calculate variance explained by each component
    total_var = var(original, 'omitnan');
    trend_var = var(trend, 'omitnan');
    seasonal_var = var(seasonal, 'omitnan');
    remainder_var = var(remainder, 'omitnan');
    
    trend_pct = (trend_var / total_var) * 100;
    seasonal_pct = (seasonal_var / total_var) * 100;
    remainder_pct = (remainder_var / total_var) * 100;
    
    fprintf('  Original %s - Mean: %.4f, Std: %.4f, Range: [%.4f, %.4f]\n', ...
            data_type, mean(original, 'omitnan'), std(original, 'omitnan'), ...
            min(original), max(original));
    fprintf('  Trend - Mean: %.4f, Std: %.4f, Range: [%.4f, %.4f]\n', ...
            mean(trend, 'omitnan'), std(trend, 'omitnan'), min(trend), max(trend));
    fprintf('  Seasonal - Mean: %.4f, Std: %.4f, Range: [%.4f, %.4f]\n', ...
            mean(seasonal, 'omitnan'), std(seasonal, 'omitnan'), min(seasonal), max(seasonal));
    fprintf('  Remainder - Mean: %.4f, Std: %.4f, Range: [%.4f, %.4f]\n', ...
            mean(remainder, 'omitnan'), std(remainder, 'omitnan'), min(remainder), max(remainder));
    fprintf('  Variance Explained - Trend: %.2f%%, Seasonal: %.2f%%, Remainder: %.2f%%\n', ...
            trend_pct, seasonal_pct, remainder_pct);
end