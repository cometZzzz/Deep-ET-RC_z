function visualize_daily_patterns(data_file, output_dir, max_patterns)
%% visualize_daily_patterns - 可视化电力供需的日周期特点
% 
% 输入参数:
%   data_file    - 数据文件路径 (CSV格式，包含datetime, target_0, target_1列)
%   output_dir   - 输出目录，用于保存生成的图表
%   max_patterns - 最大展示的模式数量 (默认为16)
%
% 功能:
%   1. 从长时间序列中提取有代表性的日期
%   2. 创建网格布局展示这些日期的供需曲线
%   3. 按季节分组展示典型模式
%   4. 计算并展示日周期模式的关键特征

    % 参数检查
    if nargin < 3
        max_patterns = 16; % 默认最多展示16个模式
    end
    
    fprintf('开始分析电力供需日周期模式...\n');
    
    % 确保输出目录存在
    if ~exist(output_dir, 'dir')
        mkdir(output_dir);
    end
    
    % 加载数据
    fprintf('加载数据: %s\n', data_file);
    data = readtable(data_file);
    
    % 确保datetime列是日期时间格式
    if ~isdatetime(data.datetime)
        data.datetime = datetime(data.datetime);
    end
    
    % 提取供给和消耗数据
    supply = data.target_0;
    demand = data.target_1;
    
    % 提取日期信息
    dates = data.datetime;
    
    % 按天分组数据
    [uniqueDays, ~, dayIndices] = unique(dateshift(dates, 'start', 'day'));
    numDays = length(uniqueDays);
    
    fprintf('数据集包含 %d 天的记录\n', numDays);
    
    % 创建每日供需模式矩阵
    dailyPatterns = struct('day', cell(numDays, 1), 'supply', cell(numDays, 1), ...
                          'demand', cell(numDays, 1), 'season', cell(numDays, 1), ...
                          'features', cell(numDays, 1));
    
    % 提取每日模式
    for i = 1:numDays
        dayData = data(dayIndices == i, :);
        
        if height(dayData) < 20  % 跳过数据不完整的日期
            continue;
        end
        
        % 获取日期和季节
        currentDay = uniqueDays(i);
        currentMonth = month(currentDay);
        if currentMonth >= 3 && currentMonth <= 5
            season = '春季';
        elseif currentMonth >= 6 && currentMonth <= 8
            season = '夏季';
        elseif currentMonth >= 9 && currentMonth <= 11
            season = '秋季';
        else
            season = '冬季';
        end
        
        % 提取当天的供需数据
        daySupply = dayData.target_0;
        dayDemand = dayData.target_1;
        
        % 计算特征
        features = struct();
        features.supply_mean = mean(daySupply);
        features.supply_max = max(daySupply);
        features.supply_min = min(daySupply);
        features.supply_range = features.supply_max - features.supply_min;
        features.demand_mean = mean(dayDemand);
        features.demand_max = max(dayDemand);
        features.demand_min = min(dayDemand);
        features.demand_range = features.demand_max - features.demand_min;
        features.correlation = corr(daySupply, dayDemand);
        
        % 存储数据
        dailyPatterns(i).day = currentDay;
        dailyPatterns(i).supply = daySupply;
        dailyPatterns(i).demand = dayDemand;
        dailyPatterns(i).season = season;
        dailyPatterns(i).features = features;
    end
    
    % 移除空记录
    emptyIdx = cellfun(@isempty, {dailyPatterns.supply});
    dailyPatterns(emptyIdx) = [];
    
    fprintf('成功提取 %d 天的完整日周期模式\n', length(dailyPatterns));
    
    % 提取特征矩阵用于聚类
    featureMatrix = zeros(length(dailyPatterns), 9);
    for i = 1:length(dailyPatterns)
        f = dailyPatterns(i).features;
        featureMatrix(i, :) = [f.supply_mean, f.supply_max, f.supply_min, f.supply_range, ...
                              f.demand_mean, f.demand_max, f.demand_min, f.demand_range, ...
                              f.correlation];
    end
    
    % 标准化特征
    featureMatrix = zscore(featureMatrix);
    
    % 使用K-means聚类找出代表性模式
    k = min(max_patterns, length(dailyPatterns));
    fprintf('使用K-means聚类选择 %d 个代表性日期...\n', k);
    
    [clusterIdx, centroids] = kmeans(featureMatrix, k);
    
    % 为每个聚类找出最接近中心的样本
    representativeDays = zeros(k, 1);
    for i = 1:k
        clusterMembers = find(clusterIdx == i);
        
        if isempty(clusterMembers)
            continue;
        end
        
        % 计算到中心的距离
        memberFeatures = featureMatrix(clusterMembers, :);
        distances = sqrt(sum((memberFeatures - centroids(i, :)).^2, 2));
        
        % 找出最接近中心的样本
        [~, minIdx] = min(distances);
        representativeDays(i) = clusterMembers(minIdx);
    end
    
    % 移除无效值
    representativeDays(representativeDays == 0) = [];
    
    fprintf('选择了 %d 个代表性日期进行可视化\n', length(representativeDays));
    
    % 按季节对代表性日期进行排序
    seasonOrder = {'春季', '夏季', '秋季', '冬季'};
    seasonIdx = zeros(length(representativeDays), 1);
    
    for i = 1:length(representativeDays)
        idx = representativeDays(i);
        season = dailyPatterns(idx).season;
        seasonIdx(i) = find(strcmp(seasonOrder, season));
    end
    
    [~, sortIdx] = sortrows([seasonIdx, (1:length(representativeDays))']);
    representativeDays = representativeDays(sortIdx);
    
    % 创建网格布局可视化
    fprintf('创建网格布局可视化...\n');
    
    % 确定网格大小
    n = length(representativeDays);
    rows = ceil(sqrt(n));
    cols = ceil(n / rows);
    
    % 创建图形
    fig = figure('Position', [100, 100, 1200, 800], 'Visible', 'off');
    
    for i = 1:length(representativeDays)
        idx = representativeDays(i);
        pattern = dailyPatterns(idx);
        
        % 创建子图
        subplot(rows, cols, i);
        
        % 绘制供需曲线
        yyaxis left;
        plot(pattern.supply, 'b-', 'LineWidth', 1.5);
        ylabel('供给 (kW)');
        
        yyaxis right;
        plot(pattern.demand, 'r-', 'LineWidth', 1.5);
        ylabel('消耗 (kW)');
        
        % 设置标题和轴标签
        title(sprintf('%s (%s)', datestr(pattern.day, 'yyyy-mm-dd'), pattern.season));
        xlabel('小时');
        
        % 设置x轴刻度
        if length(pattern.supply) >= 24
            xticks(1:4:24);
            xticklabels({'0', '4', '8', '12', '16', '20'});
        end
        
        % 添加网格
        grid on;
    end
    
    % 添加总标题
    sgtitle('电力供需日周期模式 - 代表性日期', 'FontSize', 16, 'FontWeight', 'bold');
    
    % 保存图形
    filename = fullfile(output_dir, 'daily_patterns_grid.png');
    saveas(fig, filename);
    fprintf('保存网格布局图: %s\n', filename);
    close(fig);
    
    % 按季节分组可视化
    fprintf('创建季节分组可视化...\n');
    
    for s = 1:length(seasonOrder)
        season = seasonOrder{s};
        
        % 找出当前季节的代表性日期
        seasonDays = [];
        for i = 1:length(representativeDays)
            idx = representativeDays(i);
            if strcmp(dailyPatterns(idx).season, season)
                seasonDays = [seasonDays, idx];
            end
        end
        
        if isempty(seasonDays)
            continue;
        end
        
        % 创建图形
        fig = figure('Position', [100, 100, 1200, 800], 'Visible', 'off');
        
        % 确定网格大小
        n = length(seasonDays);
        rows = ceil(sqrt(n));
        cols = ceil(n / rows);
        
        for i = 1:length(seasonDays)
            idx = seasonDays(i);
            pattern = dailyPatterns(idx);
            
            % 创建子图
            subplot(rows, cols, i);
            
            % 绘制供需曲线
            yyaxis left;
            plot(pattern.supply, 'b-', 'LineWidth', 1.5);
            ylabel('供给 (kW)');
            ylim([0, max(pattern.supply) * 1.1]);
            
            yyaxis right;
            plot(pattern.demand, 'r-', 'LineWidth', 1.5);
            ylabel('消耗 (kW)');
            ylim([0, max(pattern.demand) * 1.1]);
            
            % 设置标题和轴标签
            title(datestr(pattern.day, 'yyyy-mm-dd'));
            xlabel('小时');
            
            % 设置x轴刻度
            if length(pattern.supply) >= 24
                xticks(1:4:24);
                xticklabels({'0', '4', '8', '12', '16', '20'});
            end
            
            % 添加网格
            grid on;
        end
        
        % 添加总标题
        sgtitle(sprintf('电力供需日周期模式 - %s', season), 'FontSize', 16, 'FontWeight', 'bold');
        
        % 保存图形
        filename = fullfile(output_dir, sprintf('daily_patterns_%s.png', season));
        saveas(fig, filename);
        fprintf('保存季节分组图: %s\n', filename);
        close(fig);
    end
    
    % 创建特征分析图
    fprintf('创建特征分析图...\n');
    
    fig = figure('Position', [100, 100, 1200, 800], 'Visible', 'off');
    
    % 提取所选日期的特征
    selectedFeatures = zeros(length(representativeDays), 9);
    dayLabels = cell(length(representativeDays), 1);
    
    for i = 1:length(representativeDays)
        idx = representativeDays(i);
        pattern = dailyPatterns(idx);
        f = pattern.features;
        
        selectedFeatures(i, :) = [f.supply_mean, f.supply_max, f.supply_min, f.supply_range, ...
                                 f.demand_mean, f.demand_max, f.demand_min, f.demand_range, ...
                                 f.correlation];
        
        dayLabels{i} = datestr(pattern.day, 'mm/dd');
    end
    
    % 特征名称
    featureNames = {'供给均值', '供给最大值', '供给最小值', '供给范围', ...
                   '消耗均值', '消耗最大值', '消耗最小值', '消耗范围', ...
                   '相关系数'};
    
    % 绘制热图
    subplot(2, 2, 1);
    imagesc(selectedFeatures);
    colorbar;
    colormap('jet');
    
    % 设置坐标轴
    set(gca, 'XTick', 1:length(featureNames), 'XTickLabel', featureNames, 'XTickLabelRotation', 45);
    set(gca, 'YTick', 1:length(dayLabels), 'YTickLabel', dayLabels);
    
    title('代表性日期特征热图');
    
    % 绘制供给峰值时间分布
    subplot(2, 2, 2);
    peakHours = zeros(length(representativeDays), 1);
    
    for i = 1:length(representativeDays)
        idx = representativeDays(i);
        pattern = dailyPatterns(idx);
        [~, peakHour] = max(pattern.supply);
        peakHours(i) = peakHour;
    end
    
    histogram(peakHours, 24, 'FaceColor', [0.2, 0.6, 0.8]);
    title('供给峰值时间分布');
    xlabel('小时');
    ylabel('频率');
    xlim([0, 24]);
    grid on;
    
    % 绘制消耗峰值时间分布
    subplot(2, 2, 3);
    peakHours = zeros(length(representativeDays), 1);
    
    for i = 1:length(representativeDays)
        idx = representativeDays(i);
        pattern = dailyPatterns(idx);
        [~, peakHour] = max(pattern.demand);
        peakHours(i) = peakHour;
    end
    
    histogram(peakHours, 24, 'FaceColor', [0.8, 0.2, 0.2]);
    title('消耗峰值时间分布');
    xlabel('小时');
    ylabel('频率');
    xlim([0, 24]);
    grid on;
    
    % 绘制供需相关性分布
    subplot(2, 2, 4);
    correlations = zeros(length(representativeDays), 1);
    
    for i = 1:length(representativeDays)
        idx = representativeDays(i);
        pattern = dailyPatterns(idx);
        correlations(i) = pattern.features.correlation;
    end
    
    histogram(correlations, 10, 'FaceColor', [0.2, 0.8, 0.2]);
    title('供需相关性分布');
    xlabel('相关系数');
    ylabel('频率');
    grid on;
    
    % 添加总标题
    sgtitle('电力供需日周期特征分析', 'FontSize', 16, 'FontWeight', 'bold');
    
    % 保存图形
    filename = fullfile(output_dir, 'daily_patterns_features.png');
    saveas(fig, filename);
    fprintf('保存特征分析图: %s\n', filename);
    close(fig);
    
    % 创建典型日模式图
    fprintf('创建典型日模式图...\n');
    
    % 按季节计算平均模式和标准差
    seasonPatterns = struct();
    seasons = {'春季', '夏季', '秋季', '冬季'};
    
    for s = 1:length(seasonOrder)
        season = seasonOrder{s};
        seasonIndices = find(strcmp({dailyPatterns.season}, season));
        
        if isempty(seasonIndices)
            continue;
        end
        
        % 确保所有天的数据长度相同
        minLength = inf;
        for i = 1:length(seasonIndices)
            idx = seasonIndices(i);
            minLength = min(minLength, length(dailyPatterns(idx).supply));
        end
        
        % 创建矩阵存储所有天的数据
        supplyMatrix = zeros(length(seasonIndices), minLength);
        demandMatrix = zeros(length(seasonIndices), minLength);
        
        for i = 1:length(seasonIndices)
            idx = seasonIndices(i);
            supplyMatrix(i, :) = dailyPatterns(idx).supply(1:minLength);
            demandMatrix(i, :) = dailyPatterns(idx).demand(1:minLength);
        end
        
        % 计算平均值和标准差
        meanSupply = mean(supplyMatrix, 1);
        stdSupply = std(supplyMatrix, 0, 1);
        meanDemand = mean(demandMatrix, 1);
        stdDemand = std(demandMatrix, 0, 1);
        
        % 存储结果
        % 将中文季节名转换为字段名
        fieldName = ['season', num2str(find(strcmp(seasons, season)))];
        seasonPatterns.(fieldName).name = season;
        seasonPatterns.(fieldName).meanSupply = meanSupply;
        seasonPatterns.(fieldName).stdSupply = stdSupply;
        seasonPatterns.(fieldName).meanDemand = meanDemand;
        seasonPatterns.(fieldName).stdDemand = stdDemand;
    end
    
    % 创建图形
    fig = figure('Position', [100, 100, 1200, 800], 'Visible', 'off');
    
    for s = 1:length(seasonOrder)
        season = seasonOrder{s};
        
        if ~isfield(seasonPatterns, season)
            continue;
        end
        
        % 创建子图
        subplot(2, 2, s);
        
        % 获取数据
        meanSupply = seasonPatterns.(season).meanSupply;
        stdSupply = seasonPatterns.(season).stdSupply;
        meanDemand = seasonPatterns.(season).meanDemand;
        stdDemand = seasonPatterns.(season).stdDemand;
        
        % 创建x轴
        x = 1:length(meanSupply);
        
        % 绘制供给曲线及其置信区间
        yyaxis left;
        shadedErrorBar(x, meanSupply, stdSupply, 'lineprops', {'b-', 'LineWidth', 2});
        ylabel('供给 (kW)');
        
        % 绘制消耗曲线及其置信区间
        yyaxis right;
        shadedErrorBar(x, meanDemand, stdDemand, 'lineprops', {'r-', 'LineWidth', 2});
        ylabel('消耗 (kW)');
        
        % 设置标题和轴标签
        title(season);
        xlabel('小时');
        
        % 设置x轴刻度
        if length(meanSupply) >= 24
            xticks(1:4:24);
            xticklabels({'0', '4', '8', '12', '16', '20'});
        end
        
        % 添加网格
        grid on;
    end
    
    % 添加总标题
    sgtitle('电力供需日周期典型模式 (均值±标准差)', 'FontSize', 16, 'FontWeight', 'bold');
    
    % 添加图例
    h = axes('position', [0, 0, 1, 1], 'visible', 'off');
    legend(h, {'供给', '供给标准差', '消耗', '消耗标准差'}, 'Orientation', 'horizontal', ...
           'Position', [0.5, 0.02, 0, 0], 'Units', 'normalized');
    
    % 保存图形
    filename = fullfile(output_dir, 'daily_patterns_typical.png');
    saveas(fig, filename);
    fprintf('保存典型日模式图: %s\n', filename);
    close(fig);
    
    fprintf('电力供需日周期模式分析完成！\n');
    fprintf('所有图表已保存到: %s\n', output_dir);
end

function h = shadedErrorBar(x, y, errBar, varargin)
% shadedErrorBar - 绘制带有阴影误差条的曲线
%
% 简化版本，仅用于本函数内部

    % 解析输入参数
    p = inputParser;
    p.addParameter('lineprops', {'b-', 'LineWidth', 1.5}, @(x) iscell(x) || ischar(x));
    p.parse(varargin{:});
    
    lineProps = p.Results.lineprops;
    
    % 确保x是列向量
    x = x(:);
    
    % 确保y是列向量
    y = y(:);
    
    % 确保errBar是列向量
    errBar = errBar(:);
    
    % 计算上下边界
    upperBound = y + errBar;
    lowerBound = y - errBar;
    
    % 绘制主曲线
    h = plot(x, y, lineProps{:});
    
    % 获取颜色
    if ischar(lineProps{1})
        mainColor = lineProps{1}(1);
    else
        mainColor = 'b';
    end
    
    % 设置填充颜色
    switch mainColor
        case 'r'
            fillColor = [1, 0.7, 0.7];
        case 'g'
            fillColor = [0.7, 1, 0.7];
        case 'b'
            fillColor = [0.7, 0.7, 1];
        otherwise
            fillColor = [0.8, 0.8, 0.8];
    end
    
    % 绘制填充区域
    hold on;
    fill([x; flipud(x)], [upperBound; flipud(lowerBound)], fillColor, 'EdgeColor', 'none', 'FaceAlpha', 0.3);
    
    % 返回主曲线句柄
end