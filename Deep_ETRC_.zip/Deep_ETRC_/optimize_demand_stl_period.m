% 脚本用途：对“需求（Consumption）”数据进行STL分解周期窗口候选 [12,24,48,72,168,336] 的批量评估与可视化，输出期刊风格图与分析说明
% 简介：统一学术排版（tiledlayout、紧凑留白、300DPI），英文标题与Supply一致（Times New Roman），文件名包含参数但图内不显示参数
function optimize_demand_stl_period()
    % 需求数据STL周期窗口优化脚本
    % 包含优化路径记录和可解释性短评功能
    
    fprintf('=== 需求数据STL周期窗口优化 ===\n');
    
    % 初始化优化路径记录
    optimization_log = struct();
    optimization_log.start_time = datetime('now');
    optimization_log.data_type = 'demand';
    optimization_log.tested_periods = [];
    optimization_log.optimization_path = {};
    optimization_log.interpretability_comments = {};
    
    % 加载数据
    fprintf('加载数据...\n');
    data = readtable('merged_data.csv');
    
    % 统一目标列命名，避免混淆（14列为供给，15列为消耗）
    if any(strcmp(data.Properties.VariableNames, 'target_0')) && any(strcmp(data.Properties.VariableNames, 'target_1'))
        data = renamevars(data, {'target_0','target_1'}, {'supply','demand'});
    end
    
    % 筛选数据（2021年10月1日到2022年10月1日）
    start_date = datetime(2021, 10, 1);
    end_date = datetime(2022, 10, 1);
    
    % 转换时间列
    data.datetime = datetime(data.datetime, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
    filtered_data = data(data.datetime >= start_date & data.datetime < end_date, :);
    
    fprintf('数据加载完成。筛选记录数: %d\n', height(filtered_data));
    fprintf('时间范围: %s 到 %s\n\n', datestr(min(filtered_data.datetime)), datestr(max(filtered_data.datetime)));
    
    % 提取需求数据
    demand_data = filtered_data.demand;  % 原target_1
    time_data = filtered_data.datetime;
    
    % 记录数据基本信息
    optimization_log.data_info = struct();
    optimization_log.data_info.total_points = length(demand_data);
    optimization_log.data_info.time_range = [min(time_data), max(time_data)];
    optimization_log.data_info.mean_value = mean(demand_data);
    optimization_log.data_info.std_value = std(demand_data);
    optimization_log.data_info.min_value = min(demand_data);
    optimization_log.data_info.max_value = max(demand_data);
    
    % 定义测试的周期窗口（小时）
    test_periods = [12, 24, 48, 72, 168, 336]; % 12h, 1d, 2d, 3d, 1w, 2w
    period_names = {'12h', '24h', '48h', '72h', '168h', '336h'};
    
    % 创建结果目录
    results_dir = 'results/stl_optimization_demand';
    if ~exist(results_dir, 'dir')
        mkdir(results_dir);
    end
    
    % 存储所有结果
    all_results = struct();
    
    % 测试每个周期窗口
    for i = 1:length(test_periods)
        period = test_periods(i);
        period_name = period_names{i};
        
        fprintf('--- 测试周期窗口: %d 小时 ---\n', period);
        
        % 记录优化路径
        step_info = struct();
        step_info.step = i;
        step_info.period = period;
        step_info.period_name = period_name;
        step_info.start_time = datetime('now');
        
        % 执行STL分解
        [trend, seasonal, remainder] = perform_stl_decomposition(demand_data, period);
        
        % 计算评估指标
        metrics = calculate_evaluation_metrics(demand_data, trend, seasonal, remainder);
        
        % 生成可解释性短评
        interpretability_comment = generate_interpretability_comment(period, metrics, demand_data);
        
        % 记录步骤完成信息
        step_info.end_time = datetime('now');
        step_info.duration = step_info.end_time - step_info.start_time;
        step_info.metrics = metrics;
        step_info.interpretability = interpretability_comment;
        
        % 生成并保存图表
        fig_path = fullfile(results_dir, sprintf('demand_stl_period_%s.png', period_name));
        generate_stl_plot(demand_data, trend, seasonal, remainder, time_data, period, fig_path);
        fprintf('图表已保存: %s\n', fig_path);

        % 保存本周期的分析解释到文本文件（参数仅在文件名中体现）
        analysis_path = fullfile(results_dir, sprintf('demand_stl_period_%s_analysis.txt', period_name));
        fid = fopen(analysis_path, 'w');
        if fid ~= -1
            fprintf(fid, '分析对象: 需求(Consumption)\n');
            fprintf(fid, '周期窗口: %s\n', period_name);
            fprintf(fid, '时间范围: %s 到 %s\n', datestr(min(time_data)), datestr(max(time_data)));
            fprintf(fid, '\n[评估指标]\n');
            fprintf(fid, '原始数据 - 均值: %.2f, 标准差: %.2f\n', metrics.original_mean, metrics.original_std);
            fprintf(fid, '趋势组件 - 方差解释: %.2f%%\n', metrics.trend_var_explained);
            fprintf(fid, '季节组件 - 方差解释: %.2f%%\n', metrics.seasonal_var_explained);
            fprintf(fid, '残差组件 - 方差解释: %.2f%%\n', metrics.remainder_var_explained);
            fprintf(fid, '季节性强度: %.3f\n', metrics.seasonal_strength);
            fprintf(fid, '趋势强度: %.3f\n', metrics.trend_strength);
            if isfield(metrics, 'remainder_smoothness')
                fprintf(fid, '残差平滑度: %.2f\n', metrics.remainder_smoothness);
            end
            if isfield(metrics, 'reconstruction_error')
                fprintf(fid, '重构误差: %.4f\n', metrics.reconstruction_error);
            end
            fprintf(fid, '\n[可解释性短评]\n');
            if isstruct(interpretability_comment)
                fields = fieldnames(interpretability_comment);
                for fidx = 1:numel(fields)
                    val = interpretability_comment.(fields{fidx});
                    if isnumeric(val)
                        fprintf(fid, '%s: %.4f\n', fields{fidx}, val);
                    else
                        fprintf(fid, '%s: %s\n', fields{fidx}, string(val));
                    end
                end
            else
                fprintf(fid, '该周期的解释性信息不可用。\n');
            end
            fclose(fid);
            fprintf('分析解释已保存: %s\n', analysis_path);
        else
            fprintf('警告: 无法写入分析解释文件: %s\n', analysis_path);
        end
        
        % 打印分析结果和可解释性短评
        print_analysis_results(period, period_name, metrics, interpretability_comment);
        
        % 存储结果
        all_results.(sprintf('period_%s', period_name)) = struct(...
            'period', period, ...
            'metrics', metrics, ...
            'interpretability', interpretability_comment, ...
            'fig_path', fig_path);
        
        % 添加到优化路径记录
        optimization_log.tested_periods(end+1) = period;
        optimization_log.optimization_path{end+1} = step_info;
        optimization_log.interpretability_comments{end+1} = interpretability_comment;
        
        fprintf('\n');
    end
    
    % 生成对比分析报告
    fprintf('=== STL周期窗口对比分析报告 ===\n\n');
    generate_comparison_report(test_periods, period_names, all_results);
    
    % 选择最佳参数
    [best_period, best_metrics, recommendation_reason] = select_best_period(test_periods, period_names, all_results);
    
    % 记录最终推荐结果
    optimization_log.end_time = datetime('now');
    optimization_log.total_duration = optimization_log.end_time - optimization_log.start_time;
    optimization_log.best_period = best_period;
    optimization_log.best_metrics = best_metrics;
    optimization_log.recommendation_reason = recommendation_reason;
    
    % 保存优化路径日志
    log_file = fullfile(results_dir, 'optimization_log.mat');
    save(log_file, 'optimization_log');
    
    % 生成优化路径报告
    generate_optimization_path_report(optimization_log, results_dir);
    
    fprintf('\n=== 需求数据STL周期窗口优化完成 ===\n');
    fprintf('优化路径日志已保存到: %s\n', log_file);
    fprintf('所有结果图表已保存到: %s\n', results_dir);
    fprintf('请查看生成的图表、分析报告和优化路径日志。\n');
end

function [trend, seasonal, remainder] = perform_stl_decomposition(data, period)
    % 执行STL分解 - 使用简化的高性能分解函数
    try
        [trend, seasonal, remainder] = stl_decompose_simple(data, period);
    catch ME
        fprintf('STL分解失败 (周期=%d): %s\n', period, ME.message);
        % 如果失败，返回简单的分解
        trend = movmean(data, min(period, length(data)/4));
        seasonal = zeros(size(data));
        remainder = data - trend;
    end
end

function metrics = calculate_evaluation_metrics(original, trend, seasonal, remainder)
    % 计算评估指标
    
    % 基本统计
    metrics.original_mean = mean(original);
    metrics.original_std = std(original);
    
    % 方差解释
    total_var = var(original);
    trend_var = var(trend);
    seasonal_var = var(seasonal);
    remainder_var = var(remainder);
    
    metrics.trend_var_explained = (trend_var / total_var) * 100;
    metrics.seasonal_var_explained = (seasonal_var / total_var) * 100;
    metrics.remainder_var_explained = (remainder_var / total_var) * 100;
    
    % 强度指标
    metrics.seasonal_strength = seasonal_var / (seasonal_var + remainder_var);
    metrics.trend_strength = trend_var / (trend_var + remainder_var);
    
    % 残差平滑度
    if length(remainder) > 1
        remainder_diff = diff(remainder);
        metrics.remainder_smoothness = mean(abs(remainder_diff));
    else
        metrics.remainder_smoothness = 0;
    end
    
    % 重构误差
    reconstructed = trend + seasonal + remainder;
    metrics.reconstruction_error = mean(abs(original - reconstructed));
    
    % 季节性规律性评估
    if length(seasonal) > 0
        metrics.seasonal_regularity = 1 - (std(seasonal) / (mean(abs(seasonal)) + eps));
    else
        metrics.seasonal_regularity = 0;
    end
end

function comment = generate_interpretability_comment(period, metrics, original_data)
    % 生成可解释性短评
    
    comment = struct();
    comment.period_hours = period;
    
    % 周期合理性评估
    if period == 24
        comment.period_rationale = '24小时周期符合日常用电模式，能捕捉日内需求变化规律';
    elseif period == 168
        comment.period_rationale = '168小时(1周)周期能捕捉工作日与周末的需求差异模式';
    elseif period == 12
        comment.period_rationale = '12小时周期可能过于细致，容易将噪声误认为季节性';
    elseif period >= 336
        comment.period_rationale = '长周期(≥2周)可能捕捉月度或季节性变化，但对短期预测意义有限';
    else
        comment.period_rationale = sprintf('%d小时周期介于日内和周内模式之间', period);
    end
    
    % 季节性强度评估
    if metrics.seasonal_strength > 0.6
        comment.seasonality_assessment = '季节性模式非常明显，分解效果良好';
    elseif metrics.seasonal_strength > 0.3
        comment.seasonality_assessment = '季节性模式较为明显，分解合理';
    elseif metrics.seasonal_strength > 0.1
        comment.seasonality_assessment = '季节性模式较弱，可能存在其他周期性';
    else
        comment.seasonality_assessment = '季节性模式很弱，该周期可能不适合此数据';
    end
    
    % 趋势分析
    if metrics.trend_strength > 0.7
        comment.trend_assessment = '趋势组件占主导，数据具有明显的长期变化趋势';
    elseif metrics.trend_strength > 0.4
        comment.trend_assessment = '趋势组件适中，数据在季节性基础上有一定趋势变化';
    else
        comment.trend_assessment = '趋势组件较弱，数据主要表现为季节性和随机波动';
    end
    
    % 残差质量评估
    remainder_ratio = metrics.remainder_var_explained / 100;
    if remainder_ratio < 0.2
        comment.residual_quality = '残差占比很低，分解质量优秀';
    elseif remainder_ratio < 0.4
        comment.residual_quality = '残差占比适中，分解质量良好';
    elseif remainder_ratio < 0.6
        comment.residual_quality = '残差占比较高，分解质量一般';
    else
        comment.residual_quality = '残差占比过高，该周期可能不适合，建议尝试其他周期';
    end
    
    % 预测适用性评估
    if metrics.seasonal_strength > 0.4 && remainder_ratio < 0.5
        comment.prediction_suitability = '该周期参数适合用于预测建模，季节性和趋势模式清晰';
    elseif metrics.seasonal_strength > 0.2 && remainder_ratio < 0.6
        comment.prediction_suitability = '该周期参数可用于预测建模，但需注意残差处理';
    else
        comment.prediction_suitability = '该周期参数预测效果可能有限，建议考虑其他周期';
    end
    
    % 综合评分和建议
    score = metrics.seasonal_strength * 0.4 + (1 - remainder_ratio) * 0.4 + metrics.trend_strength * 0.2;
    comment.overall_score = score;
    
    if score > 0.7
        comment.overall_recommendation = '强烈推荐：该周期参数表现优秀';
    elseif score > 0.5
        comment.overall_recommendation = '推荐：该周期参数表现良好';
    elseif score > 0.3
        comment.overall_recommendation = '可考虑：该周期参数表现一般';
    else
        comment.overall_recommendation = '不推荐：该周期参数表现较差';
    end
end

function generate_stl_plot(original, trend, seasonal, remainder, time_data, period, save_path)
    % 生成期刊风格STL分解图表（tiledlayout、紧凑留白、英文与Supply统一）
    
    % 统一蓝色主题
    colors = struct('c',[0.2,0.4,0.8]);
    
    % 创建图形并设置高分辨率输出参数
    fig = figure('Position',[100,100,1200,900],'Color','white','PaperPositionMode','auto');
    tl = tiledlayout(fig,4,1,'TileSpacing','compact','Padding','compact');
    sgtitle(tl,'STL Decomposition - Consumption Data','FontName','Times New Roman','FontSize',13,'FontWeight','bold');
    
    % Original
    ax1 = nexttile(tl,1);
    plot(ax1, time_data, original, 'Color', colors.c, 'LineWidth', 1.2);
    title(ax1,'Original Consumption Data','FontName','Times New Roman','FontSize',11,'FontWeight','bold');
    ylabel(ax1,'Consumption (kWh)','FontName','Times New Roman','FontSize',10);
    grid(ax1,'on'); grid(ax1,'minor'); box(ax1,'on'); set(ax1,'FontName','Times New Roman','FontSize',9);
    
    % Trend
    ax2 = nexttile(tl,2);
    plot(ax2, time_data, trend, 'Color', colors.c, 'LineWidth', 1.2);
    title(ax2,'Trend Component','FontName','Times New Roman','FontSize',11,'FontWeight','bold');
    ylabel(ax2,'Trend (kWh)','FontName','Times New Roman','FontSize',10);
    grid(ax2,'on'); grid(ax2,'minor'); box(ax2,'on'); set(ax2,'FontName','Times New Roman','FontSize',9);
    
    % Seasonal
    ax3 = nexttile(tl,3);
    plot(ax3, time_data, seasonal, 'Color', colors.c, 'LineWidth', 1.2);
    title(ax3,'Seasonal Component','FontName','Times New Roman','FontSize',11,'FontWeight','bold');
    ylabel(ax3,'Seasonal (kWh)','FontName','Times New Roman','FontSize',10);
    grid(ax3,'on'); grid(ax3,'minor'); box(ax3,'on'); set(ax3,'FontName','Times New Roman','FontSize',9);
    
    % Remainder
    ax4 = nexttile(tl,4);
    plot(ax4, time_data, remainder, 'Color', colors.c, 'LineWidth', 1.2);
    title(ax4,'Remainder Component','FontName','Times New Roman','FontSize',11,'FontWeight','bold');
    ylabel(ax4,'Remainder (kWh)','FontName','Times New Roman','FontSize',10);
    xlabel(ax4,'Time','FontName','Times New Roman','FontSize',10);
    grid(ax4,'on'); grid(ax4,'minor'); box(ax4,'on'); set(ax4,'FontName','Times New Roman','FontSize',9);
    
    % 同步x轴并设置时间刻度（只在底部显示）
    linkaxes([ax1,ax2,ax3,ax4],'x');
    set(ax1,'XTickLabel',[]); set(ax2,'XTickLabel',[]); set(ax3,'XTickLabel',[]);
    xtickangle(ax4,45);
    try
        startT = time_data(1); endT = time_data(end);
        month_ticks = startT:calmonths(1):endT;
        set(ax4,'XTick',month_ticks);
        ax4.XTickLabel = cellstr(datestr(month_ticks,'mmm yyyy'));
    catch
        % 兼容处理（非datetime时间轴）
    end
    
    % 高分辨率保存
    print(fig, save_path, '-dpng', '-r300');
end

function print_analysis_results(period, period_name, metrics, interpretability)
    % 打印分析结果和可解释性短评
    
    fprintf('周期 %d 小时 - 分析结果:\n', period);
    fprintf('  原始数据 - 均值: %.2f, 标准差: %.2f\n', metrics.original_mean, metrics.original_std);
    fprintf('  趋势组件 - 方差解释: %.2f%%\n', metrics.trend_var_explained);
    fprintf('  季节组件 - 方差解释: %.2f%%\n', metrics.seasonal_var_explained);
    fprintf('  残差组件 - 方差解释: %.2f%%\n', metrics.remainder_var_explained);
    fprintf('  季节性强度: %.3f\n', metrics.seasonal_strength);
    fprintf('  趋势强度: %.3f\n', metrics.trend_strength);
    fprintf('  残差平滑度: %.2f\n', metrics.remainder_smoothness);
    fprintf('  重构误差: %.4f\n', metrics.reconstruction_error);
    
    fprintf('\n--- 可解释性短评 ---\n');
    fprintf('周期合理性: %s\n', interpretability.period_rationale);
    fprintf('季节性评估: %s\n', interpretability.seasonality_assessment);
    fprintf('趋势分析: %s\n', interpretability.trend_assessment);
    fprintf('残差质量: %s\n', interpretability.residual_quality);
    fprintf('预测适用性: %s\n', interpretability.prediction_suitability);
    fprintf('综合评分: %.3f\n', interpretability.overall_score);
    fprintf('总体建议: %s\n', interpretability.overall_recommendation);
end

function generate_comparison_report(periods, period_names, results)
    % 生成对比分析报告
    
    fprintf('周期(h) | 趋势解释%% | 季节解释%% | 残差解释%% | 季节强度 | 趋势强度 | 残差平滑度 | 综合评分\n');
    fprintf('--------|----------|----------|----------|----------|----------|----------|----------\n');
    
    for i = 1:length(periods)
        period_name = period_names{i};
        result = results.(sprintf('period_%s', period_name));
        metrics = result.metrics;
        interp = result.interpretability;
        
        fprintf('%8d |%9.2f |%9.2f |%9.2f |%9.3f |%9.3f |%11.2f |%9.3f\n', ...
            periods(i), metrics.trend_var_explained, metrics.seasonal_var_explained, ...
            metrics.remainder_var_explained, metrics.seasonal_strength, ...
            metrics.trend_strength, metrics.remainder_smoothness, interp.overall_score);
    end
end

function [best_period, best_metrics, reason] = select_best_period(periods, period_names, results)
    % 选择最佳周期参数
    
    best_score = -1;
    best_period = periods(1);
    best_metrics = [];
    best_result = [];
    
    fprintf('\n=== 参数推荐分析 ===\n');
    
    % 找到各项最佳指标
    max_seasonal_strength = -1;
    min_remainder_smooth = inf;
    max_seasonal_explained = -1;
    
    for i = 1:length(periods)
        period_name = period_names{i};
        result = results.(sprintf('period_%s', period_name));
        metrics = result.metrics;
        interp = result.interpretability;
        
        if interp.overall_score > best_score
            best_score = interp.overall_score;
            best_period = periods(i);
            best_metrics = metrics;
            best_result = result;
        end
        
        if metrics.seasonal_strength > max_seasonal_strength
            max_seasonal_strength = metrics.seasonal_strength;
            best_seasonal_period = periods(i);
        end
        
        if metrics.remainder_smoothness < min_remainder_smooth
            min_remainder_smooth = metrics.remainder_smoothness;
            best_smooth_period = periods(i);
        end
        
        if metrics.seasonal_var_explained > max_seasonal_explained
            max_seasonal_explained = metrics.seasonal_var_explained;
            best_explained_period = periods(i);
        end
    end
    
    fprintf('最强季节性: %d小时 (季节强度: %.3f)\n', best_seasonal_period, max_seasonal_strength);
    fprintf('最平滑残差: %d小时 (平滑度: %.2f)\n', best_smooth_period, min_remainder_smooth);
    fprintf('最强季节解释: %d小时 (解释方差: %.2f%%)\n', best_explained_period, max_seasonal_explained);
    
    fprintf('\n*** 推荐最佳周期参数: %d小时 ***\n', best_period);
    fprintf('综合评分: %.3f (季节性强度: %.3f, 季节解释: %.2f%%, 残差平滑度: %.2f)\n', ...
        best_score, best_metrics.seasonal_strength, best_metrics.seasonal_var_explained, best_metrics.remainder_smoothness);
    
    % 生成推荐理由
    reason = sprintf('基于综合评分选择%d小时周期：%s', best_period, best_result.interpretability.overall_recommendation);
    fprintf('推荐理由: %s\n', reason);
end

function generate_optimization_path_report(log, results_dir)
    % 生成优化路径报告
    
    report_file = fullfile(results_dir, 'optimization_path_report.txt');
    fid = fopen(report_file, 'w');
    
    fprintf(fid, '=== 需求数据STL周期窗口优化路径报告 ===\n\n');
    fprintf(fid, '优化开始时间: %s\n', datestr(log.start_time));
    fprintf(fid, '优化结束时间: %s\n', datestr(log.end_time));
    fprintf(fid, '总耗时: %s\n\n', char(log.total_duration));
    
    fprintf(fid, '数据基本信息:\n');
    fprintf(fid, '  数据点数: %d\n', log.data_info.total_points);
    fprintf(fid, '  时间范围: %s 到 %s\n', datestr(log.data_info.time_range(1)), datestr(log.data_info.time_range(2)));
    fprintf(fid, '  均值: %.2f, 标准差: %.2f\n', log.data_info.mean_value, log.data_info.std_value);
    fprintf(fid, '  最小值: %.2f, 最大值: %.2f\n\n', log.data_info.min_value, log.data_info.max_value);
    
    fprintf(fid, '优化路径详情:\n');
    for i = 1:length(log.optimization_path)
        step = log.optimization_path{i};
        fprintf(fid, '\n步骤 %d: 测试 %d 小时周期\n', step.step, step.period);
        fprintf(fid, '  开始时间: %s\n', datestr(step.start_time));
        fprintf(fid, '  结束时间: %s\n', datestr(step.end_time));
        fprintf(fid, '  耗时: %s\n', char(step.duration));
        fprintf(fid, '  季节性强度: %.3f\n', step.metrics.seasonal_strength);
        fprintf(fid, '  综合评分: %.3f\n', step.interpretability.overall_score);
        fprintf(fid, '  可解释性短评: %s\n', step.interpretability.overall_recommendation);
    end
    
    fprintf(fid, '\n最终推荐结果:\n');
    fprintf(fid, '  最佳周期: %d 小时\n', log.best_period);
    fprintf(fid, '  推荐理由: %s\n', log.recommendation_reason);
    
    fclose(fid);
    
    fprintf('优化路径报告已保存到: %s\n', report_file);
end