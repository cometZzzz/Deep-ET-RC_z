% 代码用途：补跑 Consumption 侧的 STL+ET 4组实验
% 简介：调用 deep_et_rc_basic(settings) 保存结果至既定目录

outDir = fullfile('D:\eqrthquake\太阳能发电供需预测\代码\STL-DeepETRC_分析\Deep_ETRC_EXP','NewResult','Exp2_1');
if ~exist(outDir, 'dir'); mkdir(outDir); end

layers_list = [1 2 3 4];
for li = 1:numel(layers_list)
    L = layers_list(li);
    exp_name = sprintf('%s_%s_L%d', 'Consumption', 'STL', L);
    settings = struct();
    settings.TARGET_NAME = 'Consumption';
    settings.USE_STL = true;
    settings.NUM_ET_LAYERS = L;
    settings.RES_SIZES = max(20, round(linspace(120, 60, L)));
    settings.LEAK_RATES = linspace(0.5, 0.3, L);
    settings.SPECTRAL_RADII = 0.90 * ones(1, L);
    settings.RIDGE_REG = 1e-4;
    settings.SPARSITY = 0.1;
    settings.AUTO_WASHOUT = true;
    settings.WASHOUT_USER = 48;
    settings.APPEND_INPUT_TO_READOUT = true;
    settings.STATE_STANDARDIZE = true;
    settings.USE_FIXED_FEATURES = false;
    settings.INCLUDE_TARGET_IN_FEATURES = true;
    settings.EXCLUDE_DATETIME = true;
    settings.STL_SEASON_LENGTH_HOURS = 168;
    settings.STL_USE_REMAINDER_AS_TARGET = true;
    settings.STL_APPEND_COMPONENTS_TO_FEATURES = true;
    settings.SAVE_RESULTS = true;
    settings.OUTPUT_DIR = outDir;
    settings.EXP_NAME = exp_name;
    fprintf('\n>>> 补跑实验：%s\n', exp_name);
    deep_et_rc_basic(settings);
    close all;
end
fprintf('\n补跑完成：Consumption STL L1-L4 已执行。\n');