% 用途与简介：实验1.2——使用LLM优化器迭代优化STL分解的季节周期窗口参数，分别针对电力供给（Supply）与电力消耗（Consumption）进行分解、评估、可视化与记录优化过程，输出统一英文标注图与分析摘要。
function exp_1_2_stl_optimize()

    %% ======================== PATHS & OUTPUT ========================
    % 数据与输出路径（统一Windows路径与安全拼接）
    DATA_FILE = fullfile('D:\eqrthquake\太阳能发电供需预测\代码', 'Deep_ER-RC_exp', 'merged_data.csv');
    OUT_DIR = fullfile('D:\eqrthquake\太阳能发电供需预测\代码', 'STL-DeepETRC_分析', 'Deep_ETRC_EXP', 'NewResult', 'Exp1_2');

    if ~exist(OUT_DIR, 'dir')
        parentDir = fileparts(OUT_DIR);
        if ~exist(parentDir, 'dir')
            mkdir(parentDir);
        end
        mkdir(OUT_DIR);
    end

    % 将当前脚本目录加入路径，确保本目录中的辅助函数可被调用
    addpath(fileparts(mfilename('fullpath')));

    %% ======================== VISUAL PARAMS ========================
    FIG_POSITION = [100, 100, 1200, 800];
    FONT_NAME = 'Arial';
    FONT_SIZE = 11;
    LINE_WIDTH = 1.3;

    %% ======================== LOAD DATA ========================
    fprintf('Loading merged data: %s\n', DATA_FILE);
    T = readtable(DATA_FILE);
    % 统一列名（供给=target_0，消耗=target_1）
    if any(strcmp(T.Properties.VariableNames, 'target_0'))
        T.Properties.VariableNames{strcmp(T.Properties.VariableNames, 'target_0')} = 'Supply';
    end
    if any(strcmp(T.Properties.VariableNames, 'target_1'))
        T.Properties.VariableNames{strcmp(T.Properties.VariableNames, 'target_1')} = 'Consumption';
    end
    % 时间列
    if ~isdatetime(T.datetime)
        try
            T.datetime = datetime(T.datetime, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
        catch
            T.datetime = datetime(T.datetime);
        end
    end

    time = T.datetime;
    s_series = T.Supply;        % 电力供给
    c_series = T.Consumption;   % 电力消耗

    %% ======================== INITIAL CANDIDATES ========================
    % 候选季节窗口（小时）：围绕日周期24并包含周周期168
    init_candidates = [22, 23, 24, 25, 26, 168];

    %% ======================== SUPPLY OPTIMIZATION ========================
    fprintf('\n=== [Supply] STL seasonal window optimization ===\n');
    [best_s, log_s] = optimize_stl_window(time, s_series, init_candidates, OUT_DIR, 'Supply', ...
                                          FIG_POSITION, FONT_NAME, FONT_SIZE, LINE_WIDTH);

    %% ======================== CONSUMPTION OPTIMIZATION ========================
    fprintf('\n=== [Consumption] STL seasonal window optimization ===\n');
    try
        [best_c, log_c] = optimize_stl_window(time, c_series, init_candidates, OUT_DIR, 'Consumption', ...
                                              FIG_POSITION, FONT_NAME, FONT_SIZE, LINE_WIDTH);
    catch ME
        warning('[Consumption] optimization failed: %s', ME.message);
        % 退化策略：仅评估初始集合一次并选择最佳，无微调
        [best_c, ~] = evaluate_candidate_set(time, c_series, init_candidates, OUT_DIR, 'Consumption', ...
                                             FIG_POSITION, FONT_NAME, FONT_SIZE, LINE_WIDTH);
        log_c.key_points = sprintf('[Consumption] fallback best=%d (single-pass)', best_c);
        % 保存一次最终图
        [tr_c, se_c, re_c] = perform_stl_decomposition_1d(c_series, best_c);
        fig_c = figure('Position', FIG_POSITION); set(fig_c, 'Color', 'w');
        tiledlayout(4,1,'Padding','compact','TileSpacing','compact');
        nexttile; plot(time, c_series, 'Color', [0.1 0.3 0.6], 'LineWidth', LINE_WIDTH); title('Consumption Original', 'FontName', FONT_NAME, 'FontSize', FONT_SIZE); ylabel('Value'); grid on;
        nexttile; plot(time, tr_c, 'Color', [0.2 0.6 0.2], 'LineWidth', LINE_WIDTH); title('Trend', 'FontName', FONT_NAME, 'FontSize', FONT_SIZE); ylabel('Value'); grid on;
        nexttile; plot(time, se_c, 'Color', [0.85 0.33 0.1], 'LineWidth', LINE_WIDTH); title(sprintf('Seasonal (Window=%dh)', best_c), 'FontName', FONT_NAME, 'FontSize', FONT_SIZE); ylabel('Value'); grid on;
        nexttile; plot(time, re_c, 'Color', [0.5 0.5 0.5], 'LineWidth', LINE_WIDTH); title('Remainder', 'FontName', FONT_NAME, 'FontSize', FONT_SIZE); ylabel('Value'); grid on; xlabel('Time');
        fname_c = fullfile(OUT_DIR, sprintf('%s_stl_final_window_%dh.png', 'consumption', best_c));
        try
            exportgraphics(fig_c, fname_c, 'Resolution', 300);
        catch
            saveas(fig_c, fname_c);
        end
        close(fig_c);
    end

    %% ======================== SUMMARY & SAVE ========================
    summary_file = fullfile(OUT_DIR, 'optimization_summary.txt');
    fid = fopen(summary_file, 'w');
    fprintf(fid, 'Experiment 1.2 - STL Seasonal Window Optimization Summary\n');
    fprintf(fid, 'Output directory: %s\n\n', OUT_DIR);
    fprintf(fid, 'Supply selected seasonal window: %d hours\n', best_s);
    if exist('best_c','var') && ~isempty(best_c)
        fprintf(fid, 'Consumption selected seasonal window: %d hours\n\n', best_c);
    else
        fprintf(fid, 'Consumption selection: failed to compute (see logs).\n\n');
    end
    fprintf(fid, 'Supply optimization log key points:\n%s\n\n', log_s.key_points);
    fprintf(fid, 'Consumption optimization log key points:\n%s\n', log_c.key_points);
    fclose(fid);
    fprintf('Summary saved: %s\n', summary_file);

    fprintf('\nAll figures and logs saved to: %s\n', OUT_DIR);
end

%% ======================== OPTIMIZER FUNCTION ========================
function [best_w, log_info] = optimize_stl_window(time, series, candidates, outDir, label, ...
                                                  figPos, fontName, fontSize, lineWidth)
    % 迭代优化季节窗口：
    % 1) 在初始候选中选择最佳；
    % 2) 周围微调（±1、±2小时）；
    % 3) 若最优不变则停止。

    % 日志与结果容器
    log_info.key_points = '';
    log_file = fullfile(outDir, sprintf('stl_optimization_log_%s.txt', lower(label)));
    fidlog = fopen(log_file, 'w');
    fprintf(fidlog, 'STL optimization log for %s\n', label);
    fprintf(fidlog, 'Initial candidates: %s \n\n', sprintf('%d ', candidates));

    % 第一次选择
    [best_w, best_score] = evaluate_candidate_set(time, series, candidates, outDir, label, figPos, fontName, fontSize, lineWidth);
    log_info.key_points = sprintf('[%s] initial best=%d (score=%.4f)', label, best_w, best_score);
    fprintf(fidlog, '%s\n', log_info.key_points);

    % 微调集合
    refine_candidates = unique(max(1, [best_w-2, best_w-1, best_w, best_w+1, best_w+2]));
    fprintf(fidlog, 'Refine candidates: %s \n', sprintf('%d ', refine_candidates));

    [refine_best_w, refine_best_score] = evaluate_candidate_set(time, series, refine_candidates, outDir, label, figPos, fontName, fontSize, lineWidth);
    fprintf(fidlog, '[%s] refine best=%d (score=%.4f)\n', label, refine_best_w, refine_best_score);

    if refine_best_w ~= best_w && refine_best_score > best_score
        % 第二次迭代（进一步微调）
        best_w = refine_best_w;
        best_score = refine_best_score;
        second_refine = unique(max(1, [best_w-2, best_w-1, best_w, best_w+1, best_w+2]));
        fprintf(fidlog, 'Second refine candidates: %s \n', sprintf('%d ', second_refine));
        [second_best_w, second_best_score] = evaluate_candidate_set(time, series, second_refine, outDir, label, figPos, fontName, fontSize, lineWidth);
        fprintf(fidlog, '[%s] second refine best=%d (score=%.4f)\n', label, second_best_w, second_best_score);
        if second_best_score > best_score
            best_w = second_best_w;
            best_score = second_best_score;
        end
    end

    % 最终使用最佳窗口生成一次“最终分解图”
    [trend, seasonal, remainder] = perform_stl_decomposition_1d(series, best_w);
    final_fig = figure('Position', figPos);
    tiledlayout(4,1,'Padding','compact','TileSpacing','compact');
    set(final_fig, 'Color', 'w');

    % 原始序列
    nexttile; plot(time, series, 'Color', [0.1 0.3 0.6], 'LineWidth', lineWidth);
    title(sprintf('%s Original Series', label), 'FontName', fontName, 'FontSize', fontSize);
    ylabel('Value'); grid on;

    % 趋势
    nexttile; plot(time, trend, 'Color', [0.2 0.6 0.2], 'LineWidth', lineWidth);
    title('Trend', 'FontName', fontName, 'FontSize', fontSize); ylabel('Value'); grid on;

    % 季节性
    nexttile; plot(time, seasonal, 'Color', [0.85 0.33 0.1], 'LineWidth', lineWidth);
    title(sprintf('Seasonal (Window=%dh)', best_w), 'FontName', fontName, 'FontSize', fontSize);
    ylabel('Value'); grid on;

    % 残差
    nexttile; plot(time, remainder, 'Color', [0.5 0.5 0.5], 'LineWidth', lineWidth);
    title('Remainder', 'FontName', fontName, 'FontSize', fontSize); ylabel('Value'); grid on;
    xlabel('Time');

    % 保存最终图
    final_name = fullfile(outDir, sprintf('%s_stl_final_window_%dh.png', lower(label), best_w));
    try
        exportgraphics(final_fig, final_name, 'Resolution', 300);
    catch
        saveas(final_fig, final_name);
    end
    close(final_fig);

    % 记录关键指标
    metrics = compute_metrics(series, trend, seasonal, remainder);
    fprintf(fidlog, '\nFinal selection for %s: window=%dh\n', label, best_w);
    fprintf(fidlog, 'seasonal_strength=%.4f, remainder_smoothness=%.4f, reconstruction_error=%.4f\n', ...
            metrics.seasonal_strength, metrics.remainder_smoothness, metrics.reconstruction_error);
    fclose(fidlog);
    fprintf('Optimization log saved: %s\n', log_file);
end

%% ======================== EVALUATE CANDIDATES ========================
function [best_w, best_score] = evaluate_candidate_set(time, series, candidates, outDir, label, figPos, fontName, fontSize, lineWidth)
    best_w = candidates(1);
    best_score = -inf;
    for w = candidates
        [trend, seasonal, remainder] = perform_stl_decomposition_1d(series, w);
        m = compute_metrics(series, trend, seasonal, remainder);
        s = score_metrics(m);

        % 可视化并保存每个候选分解图
        fig = figure('Position', figPos); set(fig, 'Color', 'w');
        tiledlayout(4,1,'Padding','compact','TileSpacing','compact');
        nexttile; plot(time, series, 'Color', [0.1 0.3 0.6], 'LineWidth', lineWidth); title(sprintf('%s Original', label), 'FontName', fontName, 'FontSize', fontSize); ylabel('Value'); grid on;
        nexttile; plot(time, trend, 'Color', [0.2 0.6 0.2], 'LineWidth', lineWidth); title('Trend', 'FontName', fontName, 'FontSize', fontSize); ylabel('Value'); grid on;
        nexttile; plot(time, seasonal, 'Color', [0.85 0.33 0.1], 'LineWidth', lineWidth); title(sprintf('Seasonal (Window=%dh)', w), 'FontName', fontName, 'FontSize', fontSize); ylabel('Value'); grid on;
        nexttile; plot(time, remainder, 'Color', [0.5 0.5 0.5], 'LineWidth', lineWidth); title('Remainder', 'FontName', fontName, 'FontSize', fontSize); ylabel('Value'); grid on; xlabel('Time');

        fname = fullfile(outDir, sprintf('%s_stl_candidate_%dh.png', lower(label), w));
        try
            exportgraphics(fig, fname, 'Resolution', 300);
        catch
            saveas(fig, fname);
        end
        close(fig);

        % 更新最优
        if s > best_score
            best_score = s;
            best_w = w;
        end
    end
end

%% ======================== STL 1D WRAPPER ========================
function [trend, seasonal, remainder] = perform_stl_decomposition_1d(data, season_length)
    % 优先使用仓库内的快速实现（stl_decompose_simple）
    if exist('stl_decompose_simple', 'file')
        [trend, seasonal, remainder] = stl_decompose_simple(data, season_length);
        return;
    end
    % 次选：更完整的一维实现（stl_decompose_1d）
    if exist('stl_decompose_1d', 'file')
        [trend, seasonal, remainder] = stl_decompose_1d(data, season_length);
        return;
    end
    % 兜底：简单移动平均+季节均值的分解
    [trend, seasonal, remainder] = simple_fallback_stl(data, season_length);
end

function [trend, seasonal, remainder] = simple_fallback_stl(data, season_length)
    n = length(data);
    if n < 2 * season_length
        k = max(3, floor(n/4));
    else
        k = max(3, min(season_length, floor(n/2)));
    end
    if mod(k,2)==0, k = k+1; end

    % 趋势（移动平均）
    trend = movmean(data, k, 'Endpoints', 'shrink');
    % 去趋势
    detrended = data - trend;
    % 季节性（按周期位置平均）
    seasonal = zeros(n,1);
    if season_length < n
        for i = 1:season_length
            idx = i:season_length:n;
            if numel(idx) > 1
                seasonal(idx) = median(detrended(idx));
            elseif numel(idx) == 1
                seasonal(idx) = detrended(idx);
            end
        end
    end
    remainder = data - trend - seasonal;
end

%% ======================== METRICS & SCORING ========================
function m = compute_metrics(original, trend, seasonal, remainder)
    total_var = var(original);
    trend_var = var(trend);
    seasonal_var = var(seasonal);
    remainder_var = var(remainder);

    m.seasonal_strength = seasonal_var / max(1e-12, (seasonal_var + remainder_var));
    m.trend_strength = trend_var / max(1e-12, (trend_var + remainder_var));

    if numel(remainder) > 1
        m.remainder_smoothness = mean(abs(diff(remainder)));
    else
        m.remainder_smoothness = 0;
    end

    recon = trend + seasonal + remainder;
    m.reconstruction_error = mean(abs(original - recon));
    m.total_var = total_var;
end

function s = score_metrics(m)
    % 综合评分：越大越好
    % 强季节性（权重0.5），平滑残差（权重0.3，取负），低重构误差（权重0.2，取负）
    s = 0.5 * m.seasonal_strength - 0.3 * m.remainder_smoothness - 0.2 * m.reconstruction_error;
end