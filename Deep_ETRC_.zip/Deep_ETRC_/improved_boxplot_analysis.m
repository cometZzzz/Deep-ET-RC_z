%% 改进的箱线图分析 - 解释ResESN箱子窄的原因
% 作者: AI Assistant
% 日期: 2024年10月

clear; clc; close all;

%% 1. 数据准备
fprintf('=== 箱线图合理性分析 ===\n');

% 各模型的MAE数据
lstm_supply_mae = 1790.254;
lstm_demand_mae = 3516.014;

resESN_supply_mae = 963.713211220977;
resESN_demand_mae = 755.83277844897;

deepESN_supply_mae = 2947.30063792049;
deepESN_demand_mae = 559.707061264671;

deepETRC_supply_mae = 43.9046978443561;
deepETRC_demand_mae = 619.175591658494;

%% 2. 分析各模型的数据分布特征
fprintf('\n各模型供需预测误差分析:\n');
fprintf('模型\t\t供给MAE\t\t需求MAE\t\t差值\t\t平均值\n');
fprintf('------------------------------------------------------------\n');

models = {'LSTM', 'ResESN', 'DeepESN', 'Deep ET-RC'};
supply_maes = [lstm_supply_mae, resESN_supply_mae, deepESN_supply_mae, deepETRC_supply_mae];
demand_maes = [lstm_demand_mae, resESN_demand_mae, deepESN_demand_mae, deepETRC_demand_mae];

for i = 1:length(models)
    diff_val = abs(supply_maes(i) - demand_maes(i));
    avg_val = (supply_maes(i) + demand_maes(i)) / 2;
    fprintf('%s\t\t%.2f\t\t%.2f\t\t%.2f\t\t%.2f\n', ...
        models{i}, supply_maes(i), demand_maes(i), diff_val, avg_val);
end

%% 3. 创建详细的可视化分析
figure('Position', [100, 100, 1400, 1000]);

% 3.1 原始箱线图
subplot(2, 3, 1);
mae_data = [
    lstm_supply_mae, resESN_supply_mae, deepESN_supply_mae, deepETRC_supply_mae;
    lstm_demand_mae, resESN_demand_mae, deepESN_demand_mae, deepETRC_demand_mae
];
boxplot(mae_data, 'Labels', models);
title('原始箱线图 (仅2个数据点)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('MAE值', 'FontSize', 10);
grid on;

% 3.2 供给vs需求对比
subplot(2, 3, 2);
x = 1:4;
bar_width = 0.35;
bar1 = bar(x - bar_width/2, supply_maes, bar_width, 'FaceColor', [0.2 0.6 0.8]);
hold on;
bar2 = bar(x + bar_width/2, demand_maes, bar_width, 'FaceColor', [0.8 0.4 0.2]);
set(gca, 'XTickLabel', models);
title('供给vs需求MAE对比', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('MAE值', 'FontSize', 10);
legend({'供给', '需求'}, 'Location', 'northeast');
grid on;

% 添加数值标注
for i = 1:length(models)
    text(i - bar_width/2, supply_maes(i) + 50, sprintf('%.0f', supply_maes(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 8);
    text(i + bar_width/2, demand_maes(i) + 50, sprintf('%.0f', demand_maes(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 8);
end

% 3.3 差值分析
subplot(2, 3, 3);
differences = abs(supply_maes - demand_maes);
bar(differences, 'FaceColor', [0.6 0.8 0.3]);
set(gca, 'XTickLabel', models);
title('供需预测误差差值', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('|供给MAE - 需求MAE|', 'FontSize', 10);
grid on;

% 添加数值标注
for i = 1:length(models)
    text(i, differences(i) + max(differences)*0.02, sprintf('%.0f', differences(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 9, 'FontWeight', 'bold');
end

% 3.4 模拟更多数据点的箱线图
subplot(2, 3, 4);
% 为每个模型生成模拟数据点（基于供给和需求的均值和标准差）
rng(42); % 设置随机种子以保证可重复性
n_points = 20; % 每个模型生成20个数据点

simulated_data = [];
for i = 1:length(models)
    mean_val = (supply_maes(i) + demand_maes(i)) / 2;
    std_val = abs(supply_maes(i) - demand_maes(i)) / 4; % 使用差值的1/4作为标准差
    
    % 生成正态分布的数据点
    sim_points = normrnd(mean_val, std_val, n_points, 1);
    sim_points = max(sim_points, 0); % 确保非负
    
    simulated_data = [simulated_data, sim_points];
end

boxplot(simulated_data, 'Labels', models);
title('模拟数据箱线图 (每模型20个点)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('模拟MAE值', 'FontSize', 10);
grid on;

% 3.5 变异系数分析
subplot(2, 3, 5);
cv_values = differences ./ ((supply_maes + demand_maes) / 2); % 变异系数 = 标准差/均值的近似
bar(cv_values, 'FaceColor', [0.8 0.6 0.4]);
set(gca, 'XTickLabel', models);
title('预测稳定性指标 (变异系数)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('变异系数', 'FontSize', 10);
grid on;

% 添加数值标注
for i = 1:length(models)
    text(i, cv_values(i) + max(cv_values)*0.02, sprintf('%.3f', cv_values(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 9, 'FontWeight', 'bold');
end

% 3.6 综合性能雷达图
subplot(2, 3, 6);
% 归一化数据用于雷达图
norm_supply = 1 - (supply_maes - min(supply_maes)) / (max(supply_maes) - min(supply_maes));
norm_demand = 1 - (demand_maes - min(demand_maes)) / (max(demand_maes) - min(demand_maes));
norm_stability = 1 - (cv_values - min(cv_values)) / (max(cv_values) - min(cv_values));

% 简化的雷达图显示
angles = linspace(0, 2*pi, 4);
colors = {'r-o', 'g-s', 'b-^', 'm-d'};

for i = 1:length(models)
    radar_data = [norm_supply(i), norm_demand(i), norm_stability(i), norm_supply(i)]; % 闭合
    polar(angles, radar_data, colors{i});
    hold on;
end
title('综合性能对比 (归一化)', 'FontSize', 12, 'FontWeight', 'bold');
legend(models, 'Location', 'best');

%% 4. 总体布局调整
sgtitle('箱线图合理性分析 - ResESN箱子窄的原因解释', 'FontSize', 16, 'FontWeight', 'bold');

%% 5. 保存结果和生成分析报告
results_dir = 'results/boxplot_analysis';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

saveas(gcf, fullfile(results_dir, 'boxplot_analysis_detailed.png'));
saveas(gcf, fullfile(results_dir, 'boxplot_analysis_detailed.fig'));

% 生成详细分析报告
report_file = fullfile(results_dir, 'boxplot_analysis_report.txt');
fid = fopen(report_file, 'w');

fprintf(fid, '=== 箱线图合理性分析报告 ===\n');
fprintf(fid, '生成时间: %s\n\n', datestr(now));

fprintf(fid, '1. 问题分析: 为什么ResESN的箱子这么窄？\n\n');

fprintf(fid, '答案: ResESN箱子窄是因为其供给和需求预测误差相对接近，\n');
fprintf(fid, '表现出较好的预测稳定性，但这并不意味着整体性能最好。\n\n');

fprintf(fid, '2. 数据分析:\n');
fprintf(fid, '模型\t\t供给MAE\t需求MAE\t差值\t\t变异系数\n');
fprintf(fid, '--------------------------------------------------------\n');
for i = 1:length(models)
    fprintf(fid, '%s\t\t%.1f\t%.1f\t%.1f\t\t%.3f\n', ...
        models{i}, supply_maes(i), demand_maes(i), differences(i), cv_values(i));
end

fprintf(fid, '\n3. 关键发现:\n');
fprintf(fid, '- ResESN差值最小(%.1f)，显示预测稳定性好\n', differences(2));
fprintf(fid, '- 但ResESN平均MAE(%.1f)不是最低的\n', (supply_maes(2) + demand_maes(2))/2);
fprintf(fid, '- Deep ET-RC虽然差值较大(%.1f)，但平均MAE最低(%.1f)\n', ...
    differences(4), (supply_maes(4) + demand_maes(4))/2);

fprintf(fid, '\n4. 箱线图解释:\n');
fprintf(fid, '- 箱子窄 = 供需预测误差接近 = 预测稳定性好\n');
fprintf(fid, '- 箱子宽 = 供需预测误差差异大 = 预测稳定性差\n');
fprintf(fid, '- 但箱子位置(高度)更重要，反映整体误差水平\n');

fprintf(fid, '\n5. 结论:\n');
fprintf(fid, '- ResESN: 稳定但误差较大\n');
fprintf(fid, '- Deep ET-RC: 整体误差最小，是最佳模型\n');
fprintf(fid, '- 评价模型应综合考虑误差大小和稳定性\n');

fclose(fid);

%% 6. 显示结论
fprintf('\n=== 分析结论 ===\n');
fprintf('ResESN箱子窄的原因:\n');
fprintf('1. 供给MAE(%.1f) 和 需求MAE(%.1f) 相对接近\n', resESN_supply_mae, resESN_demand_mae);
fprintf('2. 差值仅%.1f，是所有模型中最小的\n', differences(2));
fprintf('3. 这表明ResESN在供需预测上较为稳定\n');
fprintf('\n但是:\n');
fprintf('- 箱子窄≠效果好，只表示稳定性好\n');
fprintf('- ResESN平均MAE(%.1f)仍高于Deep ET-RC(%.1f)\n', ...
    (supply_maes(2) + demand_maes(2))/2, (supply_maes(4) + demand_maes(4))/2);
fprintf('- Deep ET-RC是综合性能最佳的模型\n');

fprintf('\n结果已保存到: %s\n', results_dir);