%% 经典ESN实验 - 太阳能发电供需预测
% 使用经典ESN与Deep ESN进行对比实验
% 作者: AI Assistant
% 日期: 2025-10-30

clear; clc; close all;

%% 设置路径和参数
fprintf('=== 经典ESN实验开始 ===\n');

% 数据文件路径
data_file = '../../111111/111.mat';

% 结果保存路径
results_dir = 'results/模型预测结果/ESN';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

%% 加载数据
fprintf('正在加载数据...\n');
try
    data = load(data_file);
    
    % 检查数据结构
    if isfield(data, 'client')
        raw_data = data.client;
    elseif isfield(data, 'data')
        raw_data = data.data;
    else
        % 获取第一个变量
        fields = fieldnames(data);
        raw_data = data.(fields{1});
    end
    
    fprintf('数据加载成功，大小: %d x %d\n', size(raw_data));
    
catch ME
    error('数据加载失败: %s', ME.message);
end

%% 数据预处理
fprintf('正在进行数据预处理...\n');

% 提取供给和需求数据（假设第1列是供给，第2列是需求）
if size(raw_data, 2) >= 2
    supply_data = raw_data(:, 1);
    demand_data = raw_data(:, 2);
else
    error('数据维度不足，需要至少2列数据');
end

% 移除异常值和缺失值
supply_data = supply_data(isfinite(supply_data));
demand_data = demand_data(isfinite(demand_data));

% 确保数据长度一致
min_len = min(length(supply_data), length(demand_data));
supply_data = supply_data(1:min_len);
demand_data = demand_data(1:min_len);

fprintf('预处理后数据长度: %d\n', min_len);

%% 数据分割和标准化
% 训练/测试分割比例
train_ratio = 0.8;
train_size = floor(min_len * train_ratio);

% 分割数据
supply_train = supply_data(1:train_size);
supply_test = supply_data(train_size+1:end);
demand_train = demand_data(1:train_size);
demand_test = demand_data(train_size+1:end);

% Z-score标准化
supply_mean = mean(supply_train);
supply_std = std(supply_train);
demand_mean = mean(demand_train);
demand_std = std(demand_train);

% 标准化训练数据
supply_train_norm = (supply_train - supply_mean) / supply_std;
supply_test_norm = (supply_test - supply_mean) / supply_std;
demand_train_norm = (demand_train - demand_mean) / demand_std;
demand_test_norm = (demand_test - demand_mean) / demand_std;

fprintf('数据标准化完成\n');

%% 经典ESN参数设置
fprintf('设置经典ESN参数...\n');

esn_params = struct();
esn_params.inSize = 1;          % 输入维度
esn_params.outSize = 1;         % 输出维度
esn_params.resSize = 100;       % 储备池大小
esn_params.leakingRate = 0.3;   % 泄漏率
esn_params.reg = 1e-8;          % 正则化系数
esn_params.r = 0.9;             % 谱半径

fprintf('ESN参数设置完成:\n');
fprintf('  储备池大小: %d\n', esn_params.resSize);
fprintf('  泄漏率: %.2f\n', esn_params.leakingRate);
fprintf('  谱半径: %.2f\n', esn_params.r);
fprintf('  正则化系数: %.2e\n', esn_params.reg);

%% 供给预测实验
fprintf('\n=== 开始供给预测实验 ===\n');

% 准备供给数据
U_supply = struct();
U_supply.u_train = supply_train_norm(1:end-1);  % 输入: t时刻的值
U_supply.y_train = supply_train_norm(2:end);    % 目标: t+1时刻的值
U_supply.u_test = supply_test_norm(1:end-1);
U_supply.y_test = supply_test_norm(2:end);

% 运行ESN供给预测
tic;
supply_results = ESNnet(U_supply, esn_params);
supply_train_time = toc;

% 反标准化预测结果
supply_pred_train = supply_results.train_pred * supply_std + supply_mean;
supply_pred_test = supply_results.test_pred * supply_std + supply_mean;

% 计算性能指标
supply_true_train = supply_train(2:end);
supply_true_test = supply_test(2:end);

% 确保维度匹配
min_train_len = min(length(supply_true_train), length(supply_pred_train));
min_test_len = min(length(supply_true_test), length(supply_pred_test));

supply_train_rmse = sqrt(mean((supply_true_train(1:min_train_len) - supply_pred_train(1:min_train_len)).^2));
supply_test_rmse = sqrt(mean((supply_true_test(1:min_test_len) - supply_pred_test(1:min_test_len)).^2));
supply_train_mae = mean(abs(supply_true_train(1:min_train_len) - supply_pred_train(1:min_train_len)));
supply_test_mae = mean(abs(supply_true_test(1:min_test_len) - supply_pred_test(1:min_test_len)));

% R²计算
supply_train_r2 = 1 - sum((supply_true_train(1:min_train_len) - supply_pred_train(1:min_train_len)).^2) / ...
                      sum((supply_true_train(1:min_train_len) - mean(supply_true_train(1:min_train_len))).^2);
supply_test_r2 = 1 - sum((supply_true_test(1:min_test_len) - supply_pred_test(1:min_test_len)).^2) / ...
                     sum((supply_true_test(1:min_test_len) - mean(supply_true_test(1:min_test_len))).^2);

fprintf('供给预测结果:\n');
fprintf('  训练集 - RMSE: %.4f, MAE: %.4f, R²: %.4f\n', supply_train_rmse, supply_train_mae, supply_train_r2);
fprintf('  测试集 - RMSE: %.4f, MAE: %.4f, R²: %.4f\n', supply_test_rmse, supply_test_mae, supply_test_r2);
fprintf('  训练时间: %.2f秒\n', supply_train_time);

%% 需求预测实验
fprintf('\n=== 开始需求预测实验 ===\n');

% 准备需求数据
U_demand = struct();
U_demand.u_train = demand_train_norm(1:end-1);  % 输入: t时刻的值
U_demand.y_train = demand_train_norm(2:end);    % 目标: t+1时刻的值
U_demand.u_test = demand_test_norm(1:end-1);
U_demand.y_test = demand_test_norm(2:end);

% 运行ESN需求预测
tic;
demand_results = ESNnet(U_demand, esn_params);
demand_train_time = toc;

% 反标准化预测结果
demand_pred_train = demand_results.train_pred * demand_std + demand_mean;
demand_pred_test = demand_results.test_pred * demand_std + demand_mean;

% 计算性能指标
demand_true_train = demand_train(2:end);
demand_true_test = demand_test(2:end);

% 确保维度匹配
min_train_len = min(length(demand_true_train), length(demand_pred_train));
min_test_len = min(length(demand_true_test), length(demand_pred_test));

demand_train_rmse = sqrt(mean((demand_true_train(1:min_train_len) - demand_pred_train(1:min_train_len)).^2));
demand_test_rmse = sqrt(mean((demand_true_test(1:min_test_len) - demand_pred_test(1:min_test_len)).^2));
demand_train_mae = mean(abs(demand_true_train(1:min_train_len) - demand_pred_train(1:min_train_len)));
demand_test_mae = mean(abs(demand_true_test(1:min_test_len) - demand_pred_test(1:min_test_len)));

% R²计算
demand_train_r2 = 1 - sum((demand_true_train(1:min_train_len) - demand_pred_train(1:min_train_len)).^2) / ...
                      sum((demand_true_train(1:min_train_len) - mean(demand_true_train(1:min_train_len))).^2);
demand_test_r2 = 1 - sum((demand_true_test(1:min_test_len) - demand_pred_test(1:min_test_len)).^2) / ...
                     sum((demand_true_test(1:min_test_len) - mean(demand_true_test(1:min_test_len))).^2);

fprintf('需求预测结果:\n');
fprintf('  训练集 - RMSE: %.4f, MAE: %.4f, R²: %.4f\n', demand_train_rmse, demand_train_mae, demand_train_r2);
fprintf('  测试集 - RMSE: %.4f, MAE: %.4f, R²: %.4f\n', demand_test_rmse, demand_test_mae, demand_test_r2);
fprintf('  训练时间: %.2f秒\n', demand_train_time);

%% 保存结果
fprintf('\n=== 保存实验结果 ===\n');

% 创建结果结构体
classicESN_results = struct();

% 供给预测结果
classicESN_results.supply = struct();
classicESN_results.supply.train_pred = supply_pred_train(1:min_train_len);
classicESN_results.supply.test_pred = supply_pred_test(1:min_test_len);
classicESN_results.supply.train_true = supply_true_train(1:min_train_len);
classicESN_results.supply.test_true = supply_true_test(1:min_test_len);
classicESN_results.supply.train_rmse = supply_train_rmse;
classicESN_results.supply.test_rmse = supply_test_rmse;
classicESN_results.supply.train_mae = supply_train_mae;
classicESN_results.supply.test_mae = supply_test_mae;
classicESN_results.supply.train_r2 = supply_train_r2;
classicESN_results.supply.test_r2 = supply_test_r2;
classicESN_results.supply.train_time = supply_train_time;

% 需求预测结果
classicESN_results.demand = struct();
classicESN_results.demand.train_pred = demand_pred_train(1:min_train_len);
classicESN_results.demand.test_pred = demand_pred_test(1:min_test_len);
classicESN_results.demand.train_true = demand_true_train(1:min_train_len);
classicESN_results.demand.test_true = demand_true_test(1:min_test_len);
classicESN_results.demand.train_rmse = demand_train_rmse;
classicESN_results.demand.test_rmse = demand_test_rmse;
classicESN_results.demand.train_mae = demand_train_mae;
classicESN_results.demand.test_mae = demand_test_mae;
classicESN_results.demand.train_r2 = demand_train_r2;
classicESN_results.demand.test_r2 = demand_test_r2;
classicESN_results.demand.train_time = demand_train_time;

% 模型参数
classicESN_results.params = esn_params;
classicESN_results.data_info = struct();
classicESN_results.data_info.total_samples = min_len;
classicESN_results.data_info.train_samples = train_size;
classicESN_results.data_info.test_samples = min_len - train_size;
classicESN_results.data_info.train_ratio = train_ratio;

% 保存.mat文件
save(fullfile(results_dir, 'classicESN_results.mat'), 'classicESN_results');
fprintf('结果已保存到: %s\n', fullfile(results_dir, 'classicESN_results.mat'));

%% 生成预测对比图
fprintf('\n=== 生成预测对比图 ===\n');

% 创建预测对比图
figure('Position', [100, 100, 1200, 800]);

% 供给预测对比
subplot(2, 2, 1);
plot(supply_true_train(1:min_train_len), 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(supply_pred_train(1:min_train_len), 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('供给预测 - 训练集', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('供给量');
legend('Location', 'best');
grid on;

subplot(2, 2, 2);
plot(supply_true_test(1:min_test_len), 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(supply_pred_test(1:min_test_len), 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('供给预测 - 测试集', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('供给量');
legend('Location', 'best');
grid on;

% 需求预测对比
subplot(2, 2, 3);
plot(demand_true_train(1:min_train_len), 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(demand_pred_train(1:min_train_len), 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('需求预测 - 训练集', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('需求量');
legend('Location', 'best');
grid on;

subplot(2, 2, 4);
plot(demand_true_test(1:min_test_len), 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(demand_pred_test(1:min_test_len), 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('需求预测 - 测试集', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('需求量');
legend('Location', 'best');
grid on;

sgtitle('经典ESN预测结果对比', 'FontSize', 14, 'FontWeight', 'bold');

% 保存图像
saveas(gcf, fullfile(results_dir, 'classicESN_prediction_comparison.png'));
saveas(gcf, fullfile(results_dir, 'classicESN_prediction_comparison.fig'));
fprintf('预测对比图已保存\n');

%% 生成性能对比图
figure('Position', [200, 200, 1000, 600]);

% 性能指标对比
metrics = {'RMSE', 'MAE', 'R²'};
supply_train_metrics = [supply_train_rmse, supply_train_mae, supply_train_r2];
supply_test_metrics = [supply_test_rmse, supply_test_mae, supply_test_r2];
demand_train_metrics = [demand_train_rmse, demand_train_mae, demand_train_r2];
demand_test_metrics = [demand_test_rmse, demand_test_mae, demand_test_r2];

subplot(1, 2, 1);
x = 1:3;
width = 0.35;
bar(x - width/2, supply_train_metrics, width, 'DisplayName', '训练集');
hold on;
bar(x + width/2, supply_test_metrics, width, 'DisplayName', '测试集');
set(gca, 'XTickLabel', metrics);
title('供给预测性能指标', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('指标值');
legend('Location', 'best');
grid on;

subplot(1, 2, 2);
bar(x - width/2, demand_train_metrics, width, 'DisplayName', '训练集');
hold on;
bar(x + width/2, demand_test_metrics, width, 'DisplayName', '测试集');
set(gca, 'XTickLabel', metrics);
title('需求预测性能指标', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('指标值');
legend('Location', 'best');
grid on;

sgtitle('经典ESN性能指标对比', 'FontSize', 14, 'FontWeight', 'bold');

% 保存图像
saveas(gcf, fullfile(results_dir, 'classicESN_performance_comparison.png'));
saveas(gcf, fullfile(results_dir, 'classicESN_performance_comparison.fig'));
fprintf('性能对比图已保存\n');

%% 实验总结
fprintf('\n=== 经典ESN实验完成 ===\n');
fprintf('总训练时间: %.2f秒\n', supply_train_time + demand_train_time);
fprintf('所有结果已保存到: %s\n', results_dir);
fprintf('实验成功完成！\n');