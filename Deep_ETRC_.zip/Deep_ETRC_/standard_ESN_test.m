%% 标准ESN基准测试
% 用于验证数据和流程的正确性，作为残差ESN的对比基准

clear; clc; close all;

fprintf('=== 标准ESN基准测试 ===\n');

%% 1. 数据加载和预处理
fprintf('\n1. 数据加载和预处理...\n');

% 加载数据
data = readtable('merged_data.csv');
fprintf('数据加载完成，共 %d 行数据\n', height(data));

% 提取特征和目标变量
features = data{:, 2:end-2};  % 除了datetime和两个target列
supply_target = data.target_0;    % 供给
demand_target = data.target_1;    % 需求

% 数据标准化
features_norm = normalize(features);
supply_norm = normalize(supply_target);
demand_norm = normalize(demand_target);

% 数据分割 (80%训练，20%测试)
total_len = length(supply_norm);
train_len = round(0.8 * total_len);
test_len = total_len - train_len;

fprintf('训练集长度: %d, 测试集长度: %d\n', train_len, test_len);

%% 2. 标准ESN参数设置
fprintf('\n2. 标准ESN参数设置...\n');

params = struct();
params.inSize = 1;           % 输入维度
params.outSize = 1;          % 输出维度
params.resSize = 100;        % 储备池大小
params.leakingRate = 0.3;    % 泄漏率
params.reg = 1e-6;           % 正则化参数
params.r = 0.8;              % 谱半径

fprintf('储备池大小: %d\n', params.resSize);
fprintf('泄漏率: %.2f\n', params.leakingRate);
fprintf('谱半径: %.2f\n', params.r);
fprintf('正则化系数: %.0e\n', params.reg);

%% 3. 供给序列预测 (标准ESN)
fprintf('\n3. 供给序列预测 (标准ESN)...\n');

% 准备供给数据结构
U_supply = struct();
U_supply.u_train = supply_norm(1:train_len-1);      % 输入: t时刻
U_supply.u_test = supply_norm(train_len:end-1);     % 输入: t时刻
U_supply.y_train = supply_norm(2:train_len);        % 目标: t+1时刻
U_supply.y_test = supply_norm(train_len+1:end);     % 目标: t+1时刻

tic;
supply_result = ESNnet(U_supply, params);
supply_time = toc;
fprintf('供给预测完成，用时: %.2f秒\n', supply_time);

%% 4. 需求序列预测 (标准ESN)
fprintf('\n4. 需求序列预测 (标准ESN)...\n');

% 准备需求数据结构
U_demand = struct();
U_demand.u_train = demand_norm(1:train_len-1);      % 输入: t时刻
U_demand.u_test = demand_norm(train_len:end-1);     % 输入: t时刻
U_demand.y_train = demand_norm(2:train_len);        % 目标: t+1时刻
U_demand.y_test = demand_norm(train_len+1:end);     % 目标: t+1时刻

tic;
demand_result = ESNnet(U_demand, params);
demand_time = toc;
fprintf('需求预测完成，用时: %.2f秒\n', demand_time);

%% 5. 性能指标计算
fprintf('\n5. 性能指标计算...\n');

% 获取测试集长度
test_len_actual = length(supply_result.test_pred);

% 供给预测性能
supply_train_rmse = sqrt(mean((supply_result.train_pred - U_supply.y_train).^2));
supply_test_rmse = sqrt(mean((supply_result.test_pred - U_supply.y_test).^2));
supply_train_mae = mean(abs(supply_result.train_pred - U_supply.y_train));
supply_test_mae = mean(abs(supply_result.test_pred - U_supply.y_test));

% 计算R²
supply_train_r2 = 1 - sum((U_supply.y_train - supply_result.train_pred).^2) / sum((U_supply.y_train - mean(U_supply.y_train)).^2);
supply_test_r2 = 1 - sum((U_supply.y_test - supply_result.test_pred).^2) / sum((U_supply.y_test - mean(U_supply.y_test)).^2);

% 需求预测性能
demand_train_rmse = sqrt(mean((demand_result.train_pred - U_demand.y_train).^2));
demand_test_rmse = sqrt(mean((demand_result.test_pred - U_demand.y_test).^2));
demand_train_mae = mean(abs(demand_result.train_pred - U_demand.y_train));
demand_test_mae = mean(abs(demand_result.test_pred - U_demand.y_test));

% 计算R²
demand_train_r2 = 1 - sum((U_demand.y_train - demand_result.train_pred).^2) / sum((U_demand.y_train - mean(U_demand.y_train)).^2);
demand_test_r2 = 1 - sum((U_demand.y_test - demand_result.test_pred).^2) / sum((U_demand.y_test - mean(U_demand.y_test)).^2);

%% 6. 结果显示
fprintf('\n=== 标准ESN性能结果 ===\n');
fprintf('\n供给预测:\n');
fprintf('  训练集 - RMSE: %.4f, MAE: %.4f, R²: %.4f\n', ...
    supply_train_rmse, supply_train_mae, supply_train_r2);
fprintf('  测试集 - RMSE: %.4f, MAE: %.4f, R²: %.4f\n', ...
    supply_test_rmse, supply_test_mae, supply_test_r2);

fprintf('\n需求预测:\n');
fprintf('  训练集 - RMSE: %.4f, MAE: %.4f, R²: %.4f\n', ...
    demand_train_rmse, demand_train_mae, demand_train_r2);
fprintf('  测试集 - RMSE: %.4f, MAE: %.4f, R²: %.4f\n', ...
    demand_test_rmse, demand_test_mae, demand_test_r2);

%% 7. 简单可视化
fprintf('\n6. 生成对比图...\n');

figure('Position', [100, 100, 1200, 400]);

% 供给预测对比
subplot(1, 2, 1);
plot(1:test_len_actual, U_supply.y_test, 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(1:test_len_actual, supply_result.test_pred, 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('标准ESN - 供给预测对比');
xlabel('时间步');
ylabel('标准化供给量');
legend('Location', 'best');
grid on;

% 需求预测对比
subplot(1, 2, 2);
plot(1:test_len_actual, U_demand.y_test, 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(1:test_len_actual, demand_result.test_pred, 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('标准ESN - 需求预测对比');
xlabel('时间步');
ylabel('标准化需求量');
legend('Location', 'best');
grid on;

% 保存图片
saveas(gcf, 'results/模型预测结果/standard_ESN_comparison.png');
fprintf('对比图已保存\n');

fprintf('\n=== 标准ESN基准测试完成 ===\n');