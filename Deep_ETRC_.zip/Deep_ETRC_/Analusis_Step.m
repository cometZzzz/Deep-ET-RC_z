% STL_DEEP_power_supply_demand_multi_step.m - 使用DeepSTL模型预测t+1到t+5时刻的电力供需关系
% 电力供给预测：使用第2,3,4,5,6,7,9,10,11,12,13,14列预测第14列的未来时刻
% 电力消耗预测：使用第2,3,4,5,6,7,9,10,11,12,13,15列预测第15列的未来时刻
% 供需关系 = 电力消耗 - 电力供给

dbstop if error
try
    % 清空环境
    clear;
    clc;
    close all;

    % 设置随机数种子以保证可重复性
    rng(42);

    %% 参数设置
    % 定义RC层参数
    params_RC.inSize = 12;       % 输入维度（12个特征）
    params_RC.outSize = 1;       % 输出维度
    params_RC.resSize = 200;     % Reservoir大小
    params_RC.leakingRate = 0.8; % 泄漏率
    params_RC.reg = 1e-5;        % 正则化系数
    params_RC.r = 0.99;          % 谱半径 

    % 定义ET层参数
    params_ET.layer1.inSize = 1;        % 输入维度
    params_ET.layer1.outSize = 1;       % 输出维度
    params_ET.layer1.resSize = 100;     % Reservoir大小
    params_ET.layer1.leakingRate = 0.7; % 泄漏率
    params_ET.layer1.reg = 1e-6;        % 正则化系数
    params_ET.layer1.r = 0.99;          % 谱半径

    params_ET.layer2.inSize = 1;
    params_ET.layer2.outSize = 1;
    params_ET.layer2.resSize = 100;
    params_ET.layer2.leakingRate = 0.6;
    params_ET.layer2.reg = 1e-7;
    params_ET.layer2.r = 0.99;

    params_ET.layer3.inSize = 1;
    params_ET.layer3.outSize = 1;
    params_ET.layer3.resSize = 100;
    params_ET.layer3.leakingRate = 0.5;
    params_ET.layer3.reg = 1e-7;
    params_ET.layer3.r = 0.99;

    params_ET.layer4.inSize = 1;
    params_ET.layer4.outSize = 1;
    params_ET.layer4.resSize = 100;
    params_ET.layer4.leakingRate = 0.4;
    params_ET.layer4.reg = 1e-8;
    params_ET.layer4.r = 0.99;

    % 定义STL分解的季节长度
    season_length = 150;  % 季节长度

    %% 数据加载和预处理
    fprintf('加载数据...\n');
    % 读取CSV文件
    data = readmatrix('merged_data.csv');
    
    % 提取特征和标签
    feature_cols = [2,3,4,5,6,7,9,10,11,12,13];  % 共同特征列
    supply_col = 14;  % 供给目标列
    demand_col = 15;  % 消耗目标列
    
    % 划分训练集和测试集
    train_size = 10000;
    test_size = 1000;
    
    % 初始化存储预测结果的数组
    max_horizon = 5;  % 最大预测步长
    supply_preds = cell(max_horizon, 1);
    demand_preds = cell(max_horizon, 1);
    balance_preds = cell(max_horizon, 1);
    supply_actuals = cell(max_horizon, 1);
    demand_actuals = cell(max_horizon, 1);
    balance_actuals = cell(max_horizon, 1);
    
    % 存储性能指标
    performance_metrics = struct();
    
    % 对每个预测步长进行预测
    for h = 1:max_horizon
        fprintf('\n开始预测 t+%d 时刻...\n', h);
        
        % 准备输入特征和目标值
        X = data(5:end-h, :);  % 所有时间步的特征
        y_supply = data(5+h:end, supply_col);      % 未来h个时间步的供给值
        y_demand = data(5+h:end, demand_col);      % 未来h个时间步的消耗值
        
        % 准备供给预测数据
        X_supply = X(:, [feature_cols, supply_col]);
        x_train_supply = X_supply(1:train_size, :);
        y_train_supply = y_supply(1:train_size);
        x_test_supply = X_supply(train_size+1:train_size+test_size, :);
        y_test_supply = y_supply(train_size+1:train_size+test_size);
        
        % 准备消耗预测数据
        X_demand = X(:, [feature_cols, demand_col]);
        x_train_demand = X_demand(1:train_size, :);
        y_train_demand = y_demand(1:train_size);
        x_test_demand = X_demand(train_size+1:train_size+test_size, :);
        y_test_demand = y_demand(train_size+1:train_size+test_size);
        
        % 数据标准化
        % 供给数据标准化
        supply_mean = mean(x_train_supply);
        supply_std = std(x_train_supply);
        supply_std(supply_std == 0) = 1;
        
        x_train_supply_norm = (x_train_supply - supply_mean) ./ supply_std;
        x_test_supply_norm = (x_test_supply - supply_mean) ./ supply_std;
        y_train_supply_norm = (y_train_supply - mean(y_train_supply)) / std(y_train_supply);
        y_test_supply_norm = (y_test_supply - mean(y_train_supply)) / std(y_train_supply);
        
        % 消耗数据标准化
        demand_mean = mean(x_train_demand);
        demand_std = std(x_train_demand);
        demand_std(demand_std == 0) = 1;
        
        x_train_demand_norm = (x_train_demand - demand_mean) ./ demand_std;
        x_test_demand_norm = (x_test_demand - demand_mean) ./ demand_std;
        y_train_demand_norm = (y_train_demand - mean(y_train_demand)) / std(y_train_demand);
        y_test_demand_norm = (y_test_demand - mean(y_train_demand)) / std(y_train_demand);
        
        % 准备数据结构
        U_supply.u_train = x_train_supply_norm;
        U_supply.u_test = x_test_supply_norm;
        U_supply.y_train = y_train_supply_norm;
        U_supply.y_test = y_test_supply_norm;
        
        U_demand.u_train = x_train_demand_norm;
        U_demand.u_test = x_test_demand_norm;
        U_demand.y_train = y_train_demand_norm;
        U_demand.y_test = y_test_demand_norm;

        % 执行预测
        n_layers = 4;  % 使用4层模型
        
        % 1. 电力供给预测
        fprintf('1. 电力供给预测 (t+%d)\n', h);
        tic;
        results_supply = DeepET_RC(n_layers, params_RC, params_ET, U_supply);
        supply_time = toc;
        
        % 2. 电力消耗预测
        fprintf('2. 电力消耗预测 (t+%d)\n', h);
        tic;
        results_demand = DeepET_RC(n_layers, params_RC, params_ET, U_demand);
        demand_time = toc;
        
        % 反标准化预测结果
        supply_pred = results_supply.test_pred * std(y_train_supply) + mean(y_train_supply);
        demand_pred = results_demand.test_pred * std(y_train_demand) + mean(y_train_demand);
        
        % 计算供需关系
        balance_pred = demand_pred - supply_pred;
        balance_actual = y_test_demand - y_test_supply;
        
        % 存储预测结果
        supply_preds{h} = supply_pred;
        demand_preds{h} = demand_pred;
        balance_preds{h} = balance_pred;
        supply_actuals{h} = y_test_supply;
        demand_actuals{h} = y_test_demand;
        balance_actuals{h} = balance_actual;
        
        % 计算性能指标
        performance_metrics(h).supply_mse = mean((supply_pred - y_test_supply).^2);
        performance_metrics(h).supply_rmse = sqrt(performance_metrics(h).supply_mse);
        performance_metrics(h).supply_mae = mean(abs(supply_pred - y_test_supply));
        performance_metrics(h).supply_r2 = 1 - sum((y_test_supply - supply_pred).^2) / sum((y_test_supply - mean(y_test_supply)).^2);
        
        performance_metrics(h).demand_mse = mean((demand_pred - y_test_demand).^2);
        performance_metrics(h).demand_rmse = sqrt(performance_metrics(h).demand_mse);
        performance_metrics(h).demand_mae = mean(abs(demand_pred - y_test_demand));
        performance_metrics(h).demand_r2 = 1 - sum((y_test_demand - demand_pred).^2) / sum((y_test_demand - mean(y_test_demand)).^2);
        
        performance_metrics(h).balance_mse = mean((balance_pred - balance_actual).^2);
        performance_metrics(h).balance_rmse = sqrt(performance_metrics(h).balance_mse);
        performance_metrics(h).balance_mae = mean(abs(balance_pred - balance_actual));
        performance_metrics(h).balance_r2 = 1 - sum((balance_actual - balance_pred).^2) / sum((balance_actual - mean(balance_actual)).^2);
        
        % 输出性能指标
        fprintf('\n性能指标 (t+%d预测)：\n', h);
        fprintf('----------------------------------------\n');
        fprintf('电力供给预测：\n');
        fprintf('MSE: %.6f\n', performance_metrics(h).supply_mse);
        fprintf('RMSE: %.6f\n', performance_metrics(h).supply_rmse);
        fprintf('MAE: %.6f\n', performance_metrics(h).supply_mae);
        fprintf('R²: %.4f\n', performance_metrics(h).supply_r2);
        
        fprintf('\n电力消耗预测：\n');
        fprintf('MSE: %.6f\n', performance_metrics(h).demand_mse);
        fprintf('RMSE: %.6f\n', performance_metrics(h).demand_rmse);
        fprintf('MAE: %.6f\n', performance_metrics(h).demand_mae);
        fprintf('R²: %.4f\n', performance_metrics(h).demand_r2);
        
        fprintf('\n供需关系预测：\n');
        fprintf('MSE: %.6f\n', performance_metrics(h).balance_mse);
        fprintf('RMSE: %.6f\n', performance_metrics(h).balance_rmse);
        fprintf('MAE: %.6f\n', performance_metrics(h).balance_mae);
        fprintf('R²: %.4f\n', performance_metrics(h).balance_r2);
    end
    
    %% Visualization Results
    % Create save directory
    save_dir = 'D:\eqrthquake\太阳能发电供需预测\文档\letax图片素材';
    if ~exist(save_dir, 'dir')
        mkdir(save_dir);
    end
    
    % 1. Multi-step Prediction Results in one figure
    figure('Name', 'Multi-step Prediction Results', 'Position', [100, 100, 1500, 600]);
    
    % Supply predictions
    for h = 1:max_horizon
        subplot(2,5,h);
        % 只显示前150个数据点，避免线条过于密集
        display_length = min(150, length(supply_actuals{h}));
        time_steps = 1:display_length;
        
        plot(time_steps, supply_actuals{h}(1:display_length), 'b-', 'LineWidth', 1.5, 'DisplayName', 'Actual');
        hold on;
        plot(time_steps, supply_preds{h}(1:display_length), 'r--', 'LineWidth', 1.5, 'DisplayName', 'Predicted');
        xlabel('Time Step');
        ylabel('Electricity Supply');
        title(sprintf('Supply (t+%d)', h));
        legend('Location', 'best');
        grid on;
    end
    
    % Demand predictions
    for h = 1:max_horizon
        subplot(2,5,h+5);
        % 只显示前150个数据点，避免线条过于密集
        display_length = min(150, length(demand_actuals{h}));
        time_steps = 1:display_length;
        
        plot(time_steps, demand_actuals{h}(1:display_length), 'b-', 'LineWidth', 1.5, 'DisplayName', 'Actual');
        hold on;
        plot(time_steps, demand_preds{h}(1:display_length), 'r--', 'LineWidth', 1.5, 'DisplayName', 'Predicted');
        xlabel('Time Step');
        ylabel('Electricity Consumption');
        title(sprintf('Consumption (t+%d)', h));
        legend('Location', 'best');
        grid on;
    end
    
    % Save the combined figure
    saveas(gcf, fullfile(save_dir, '多步预测结果对比图.png'));
    
    % 2. Prediction Error vs Horizon
    figure('Name', 'Prediction Error vs Horizon', 'Position', [100, 100, 800, 400]);
    
    % Prepare data
    horizons = 1:max_horizon;
    supply_rmse = [performance_metrics.supply_rmse];
    demand_rmse = [performance_metrics.demand_rmse];
    
    % Plot RMSE vs Horizon
    subplot(1,2,1);
    plot(horizons, supply_rmse, 'o-', 'LineWidth', 1.5);
    xlabel('Prediction Horizon');
    ylabel('RMSE');
    title('Supply Prediction RMSE vs Horizon');
    grid on;
    
    subplot(1,2,2);
    plot(horizons, demand_rmse, 'o-', 'LineWidth', 1.5);
    xlabel('Prediction Horizon');
    ylabel('RMSE');
    title('Demand Prediction RMSE vs Horizon');
    grid on;
    
    % Save the error vs horizon figure
    saveas(gcf, fullfile(save_dir, '预测误差随步长变化图.png'));
    
    % 3. Error Distribution for each horizon
    figure('Name', 'Error Distribution for Each Horizon', 'Position', [100, 100, 1500, 600]);
    
    % Supply error distributions
    for h = 1:max_horizon
        subplot(2,5,h);
        histogram(supply_preds{h} - supply_actuals{h}, 50);
        xlabel('Prediction Error');
        ylabel('Frequency');
        title(sprintf('Supply Error (t+%d)', h));
        grid on;
    end
    
    % Demand error distributions
    for h = 1:max_horizon
        subplot(2,5,h+5);
        histogram(demand_preds{h} - demand_actuals{h}, 50);
        xlabel('Prediction Error');
        ylabel('Frequency');
        title(sprintf('Demand Error (t+%d)', h));
        grid on;
    end
    
    % Save the error distribution figure
    saveas(gcf, fullfile(save_dir, '预测误差分布图.png'));
    
    % 4. Box plots for prediction errors at each horizon (separate figures)
    % Prepare error data for box plots
    supply_errors = cell(max_horizon, 1);
    demand_errors = cell(max_horizon, 1);
    balance_errors = cell(max_horizon, 1);
    
    for h = 1:max_horizon
        supply_errors{h} = supply_preds{h} - supply_actuals{h};
        demand_errors{h} = demand_preds{h} - demand_actuals{h};
        balance_errors{h} = balance_preds{h} - balance_actuals{h};
    end
    
    % Supply error box plot (separate figure)
    figure('Name', 'Supply Prediction Error Box Plot', 'Position', [100, 100, 800, 600]);
    supply_error_matrix = [];
    supply_group_labels = [];
    for h = 1:max_horizon
        supply_error_matrix = [supply_error_matrix; supply_errors{h}];
        supply_group_labels = [supply_group_labels; repmat(h, length(supply_errors{h}), 1)];
    end
    boxplot(supply_error_matrix, supply_group_labels);
    xlabel('预测步长 (t+m)', 'FontSize', 12);
    ylabel('预测误差', 'FontSize', 12);
    title('电力供给预测误差箱线图', 'FontSize', 14, 'FontWeight', 'bold');
    grid on;
    % Save the supply error box plot
    saveas(gcf, fullfile(save_dir, '电力供给预测误差箱线图.png'));
    
    % Demand error box plot (separate figure)
    figure('Name', 'Demand Prediction Error Box Plot', 'Position', [100, 100, 800, 600]);
    demand_error_matrix = [];
    demand_group_labels = [];
    for h = 1:max_horizon
        demand_error_matrix = [demand_error_matrix; demand_errors{h}];
        demand_group_labels = [demand_group_labels; repmat(h, length(demand_errors{h}), 1)];
    end
    boxplot(demand_error_matrix, demand_group_labels);
    xlabel('Prediction step length (t+m)', 'FontSize', 12);
    ylabel('Mean error', 'FontSize', 12);
    title('Consumption Prediction Error', 'FontSize', 14, 'FontWeight', 'bold');
    grid on;
    % Save the demand error box plot
    saveas(gcf, fullfile(save_dir, '电力消耗预测误差箱线图.png'));
    
    % Balance error box plot (separate figure)
    figure('Name', 'Balance Prediction Error Box Plot', 'Position', [100, 100, 800, 600]);
    balance_error_matrix = [];
    balance_group_labels = [];
    for h = 1:max_horizon
        balance_error_matrix = [balance_error_matrix; balance_errors{h}];
        balance_group_labels = [balance_group_labels; repmat(h, length(balance_errors{h}), 1)];
    end
    boxplot(balance_error_matrix, balance_group_labels);
    xlabel('Prediction step length (t+m)', 'FontSize', 12);
    ylabel('Mean error', 'FontSize', 12);
    title('Supply Prediction Error', 'FontSize', 14, 'FontWeight', 'bold');
    grid on;
    % Save the balance error box plot
    saveas(gcf, fullfile(save_dir, '供需关系预测误差箱线图.png'));
    
    % Save prediction results and performance metrics
    save(fullfile(save_dir, '多步预测结果数据.mat'), ...
         'supply_preds', 'demand_preds', 'balance_preds', ...
         'supply_actuals', 'demand_actuals', 'balance_actuals', ...
         'performance_metrics');

catch ME
    fid = fopen('matlab_error.log','w');
    fprintf(fid, '%s', getReport(ME, 'extended'));
    fclose(fid);
end