%% 经典ESN实验 - 太阳能发电供需预测 (更新版)
% 使用经典ESN与Deep ESN进行对比实验
% 适应已预处理的数据格式
% 作者: AI Assistant
% 日期: 2025-10-30

clear; clc; close all;

%% 设置路径和参数
fprintf('=== 经典ESN实验开始 ===\n');

% 数据文件路径
data_file = '../../111111/111.mat';

% 结果保存路径
results_dir = 'results/模型预测结果/ESN';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

%% 加载数据
fprintf('正在加载数据...\n');
try
    data = load(data_file);
    
    % 提取已预处理的数据
    x_train = data.x_train;
    y_train = data.y_train;
    x_test = data.x_test;
    y_test = data.y_test;
    
    fprintf('数据加载成功:\n');
    fprintf('  训练集: x_train %dx%d, y_train %dx%d\n', size(x_train), size(y_train));
    fprintf('  测试集: x_test %dx%d, y_test %dx%d\n', size(x_test), size(y_test));
    
catch ME
    error('数据加载失败: %s', ME.message);
end

%% 数据预处理
fprintf('正在进行数据预处理...\n');

% 移除异常值和缺失值
x_train = x_train(isfinite(x_train));
y_train = y_train(isfinite(y_train));
x_test = x_test(isfinite(x_test));
y_test = y_test(isfinite(y_test));

% 确保数据长度一致
min_train_len = min(length(x_train), length(y_train));
min_test_len = min(length(x_test), length(y_test));

x_train = x_train(1:min_train_len);
y_train = y_train(1:min_train_len);
x_test = x_test(1:min_test_len);
y_test = y_test(1:min_test_len);

fprintf('预处理后数据长度: 训练集 %d, 测试集 %d\n', min_train_len, min_test_len);

%% 数据标准化
% Z-score标准化（基于训练集统计量）
x_mean = mean(x_train);
x_std = std(x_train);
y_mean = mean(y_train);
y_std = std(y_train);

% 标准化数据
x_train_norm = (x_train - x_mean) / x_std;
x_test_norm = (x_test - x_mean) / x_std;
y_train_norm = (y_train - y_mean) / y_std;
y_test_norm = (y_test - y_mean) / y_std;

fprintf('数据标准化完成\n');
fprintf('  输入统计: 均值=%.4f, 标准差=%.4f\n', x_mean, x_std);
fprintf('  输出统计: 均值=%.4f, 标准差=%.4f\n', y_mean, y_std);

%% 经典ESN参数设置
fprintf('\n设置经典ESN参数...\n');

esn_params = struct();
esn_params.inSize = 1;          % 输入维度
esn_params.outSize = 1;         % 输出维度
esn_params.resSize = 100;       % 储备池大小
esn_params.leakingRate = 0.3;   % 泄漏率
esn_params.reg = 1e-8;          % 正则化系数
esn_params.r = 0.9;             % 谱半径

fprintf('ESN参数设置完成:\n');
fprintf('  储备池大小: %d\n', esn_params.resSize);
fprintf('  泄漏率: %.2f\n', esn_params.leakingRate);
fprintf('  谱半径: %.2f\n', esn_params.r);
fprintf('  正则化系数: %.2e\n', esn_params.reg);

%% 时间序列预测实验
fprintf('\n=== 开始时间序列预测实验 ===\n');

% 准备ESN输入数据结构
U = struct();
U.u_train = x_train_norm;
U.y_train = y_train_norm;
U.u_test = x_test_norm;
U.y_test = y_test_norm;

% 运行ESN预测
fprintf('正在训练ESN模型...\n');
tic;
esn_results = ESNnet(U, esn_params);
train_time = toc;

fprintf('ESN训练完成，用时: %.2f秒\n', train_time);

%% 反标准化预测结果
fprintf('正在反标准化预测结果...\n');

% 反标准化
pred_train = esn_results.train_pred * y_std + y_mean;
pred_test = esn_results.test_pred * y_std + y_mean;

% 确保维度匹配
min_train_pred_len = min(length(y_train), length(pred_train));
min_test_pred_len = min(length(y_test), length(pred_test));

%% 计算性能指标
fprintf('正在计算性能指标...\n');

% 训练集性能
train_rmse = sqrt(mean((y_train(1:min_train_pred_len) - pred_train(1:min_train_pred_len)).^2));
train_mae = mean(abs(y_train(1:min_train_pred_len) - pred_train(1:min_train_pred_len)));
train_r2 = 1 - sum((y_train(1:min_train_pred_len) - pred_train(1:min_train_pred_len)).^2) / ...
               sum((y_train(1:min_train_pred_len) - mean(y_train(1:min_train_pred_len))).^2);

% 测试集性能
test_rmse = sqrt(mean((y_test(1:min_test_pred_len) - pred_test(1:min_test_pred_len)).^2));
test_mae = mean(abs(y_test(1:min_test_pred_len) - pred_test(1:min_test_pred_len)));
test_r2 = 1 - sum((y_test(1:min_test_pred_len) - pred_test(1:min_test_pred_len)).^2) / ...
              sum((y_test(1:min_test_pred_len) - mean(y_test(1:min_test_pred_len))).^2);

fprintf('\n=== 经典ESN预测结果 ===\n');
fprintf('训练集性能:\n');
fprintf('  RMSE: %.4f\n', train_rmse);
fprintf('  MAE:  %.4f\n', train_mae);
fprintf('  R²:   %.4f\n', train_r2);
fprintf('\n测试集性能:\n');
fprintf('  RMSE: %.4f\n', test_rmse);
fprintf('  MAE:  %.4f\n', test_mae);
fprintf('  R²:   %.4f\n', test_r2);
fprintf('\n训练时间: %.2f秒\n', train_time);

%% 保存结果
fprintf('\n=== 保存实验结果 ===\n');

% 创建结果结构体
classicESN_results = struct();

% 预测结果
classicESN_results.train_pred = pred_train(1:min_train_pred_len);
classicESN_results.test_pred = pred_test(1:min_test_pred_len);
classicESN_results.train_true = y_train(1:min_train_pred_len);
classicESN_results.test_true = y_test(1:min_test_pred_len);

% 性能指标
classicESN_results.train_rmse = train_rmse;
classicESN_results.test_rmse = test_rmse;
classicESN_results.train_mae = train_mae;
classicESN_results.test_mae = test_mae;
classicESN_results.train_r2 = train_r2;
classicESN_results.test_r2 = test_r2;
classicESN_results.train_time = train_time;

% 模型参数和数据信息
classicESN_results.params = esn_params;
classicESN_results.data_info = struct();
classicESN_results.data_info.train_samples = min_train_len;
classicESN_results.data_info.test_samples = min_test_len;
classicESN_results.data_info.x_stats = struct('mean', x_mean, 'std', x_std);
classicESN_results.data_info.y_stats = struct('mean', y_mean, 'std', y_std);

% 原始ESN输出
classicESN_results.esn_output = esn_results;

% 保存.mat文件
save(fullfile(results_dir, 'classicESN_results.mat'), 'classicESN_results');
fprintf('结果已保存到: %s\n', fullfile(results_dir, 'classicESN_results.mat'));

%% 生成预测对比图
fprintf('\n=== 生成预测对比图 ===\n');

% 创建预测对比图
figure('Position', [100, 100, 1200, 800]);

% 训练集预测对比
subplot(2, 2, 1);
plot_len = min(500, min_train_pred_len);  % 只显示前500个点以便观察
plot(1:plot_len, y_train(1:plot_len), 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(1:plot_len, pred_train(1:plot_len), 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('训练集预测对比 (前500点)', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('数值');
legend('Location', 'best');
grid on;

% 测试集预测对比
subplot(2, 2, 2);
plot_len = min(200, min_test_pred_len);  % 只显示前200个点
plot(1:plot_len, y_test(1:plot_len), 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(1:plot_len, pred_test(1:plot_len), 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('测试集预测对比 (前200点)', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('数值');
legend('Location', 'best');
grid on;

% 散点图 - 训练集
subplot(2, 2, 3);
scatter(y_train(1:min_train_pred_len), pred_train(1:min_train_pred_len), 20, 'b', 'filled');
hold on;
min_val = min([y_train(1:min_train_pred_len); pred_train(1:min_train_pred_len)]);
max_val = max([y_train(1:min_train_pred_len); pred_train(1:min_train_pred_len)]);
plot([min_val, max_val], [min_val, max_val], 'r--', 'LineWidth', 2);
title(sprintf('训练集散点图 (R² = %.4f)', train_r2), 'FontSize', 12, 'FontWeight', 'bold');
xlabel('真实值');
ylabel('预测值');
grid on;
axis equal;

% 散点图 - 测试集
subplot(2, 2, 4);
scatter(y_test(1:min_test_pred_len), pred_test(1:min_test_pred_len), 20, 'g', 'filled');
hold on;
min_val = min([y_test(1:min_test_pred_len); pred_test(1:min_test_pred_len)]);
max_val = max([y_test(1:min_test_pred_len); pred_test(1:min_test_pred_len)]);
plot([min_val, max_val], [min_val, max_val], 'r--', 'LineWidth', 2);
title(sprintf('测试集散点图 (R² = %.4f)', test_r2), 'FontSize', 12, 'FontWeight', 'bold');
xlabel('真实值');
ylabel('预测值');
grid on;
axis equal;

sgtitle('经典ESN预测结果对比', 'FontSize', 14, 'FontWeight', 'bold');

% 保存图像
saveas(gcf, fullfile(results_dir, 'classicESN_prediction_comparison.png'));
saveas(gcf, fullfile(results_dir, 'classicESN_prediction_comparison.fig'));
fprintf('预测对比图已保存\n');

%% 生成性能指标图
figure('Position', [200, 200, 1000, 400]);

% 性能指标对比
metrics = {'RMSE', 'MAE', 'R²'};
train_metrics = [train_rmse, train_mae, train_r2];
test_metrics = [test_rmse, test_mae, test_r2];

x = 1:3;
width = 0.35;
bar(x - width/2, train_metrics, width, 'DisplayName', '训练集', 'FaceColor', [0.2, 0.6, 0.8]);
hold on;
bar(x + width/2, test_metrics, width, 'DisplayName', '测试集', 'FaceColor', [0.8, 0.4, 0.2]);

set(gca, 'XTickLabel', metrics);
title('经典ESN性能指标对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('指标值');
legend('Location', 'best');
grid on;

% 在柱状图上添加数值标签
for i = 1:3
    text(i - width/2, train_metrics(i) + 0.01, sprintf('%.3f', train_metrics(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 10);
    text(i + width/2, test_metrics(i) + 0.01, sprintf('%.3f', test_metrics(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 10);
end

% 保存图像
saveas(gcf, fullfile(results_dir, 'classicESN_performance_comparison.png'));
saveas(gcf, fullfile(results_dir, 'classicESN_performance_comparison.fig'));
fprintf('性能对比图已保存\n');

%% 生成误差分析图
figure('Position', [300, 300, 1000, 600]);

% 训练集误差分析
subplot(2, 2, 1);
train_errors = y_train(1:min_train_pred_len) - pred_train(1:min_train_pred_len);
histogram(train_errors, 50, 'FaceColor', [0.2, 0.6, 0.8], 'EdgeColor', 'none');
title('训练集误差分布', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('误差');
ylabel('频次');
grid on;

% 测试集误差分析
subplot(2, 2, 2);
test_errors = y_test(1:min_test_pred_len) - pred_test(1:min_test_pred_len);
histogram(test_errors, 50, 'FaceColor', [0.8, 0.4, 0.2], 'EdgeColor', 'none');
title('测试集误差分布', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('误差');
ylabel('频次');
grid on;

% 训练集误差时间序列
subplot(2, 2, 3);
plot_len = min(500, length(train_errors));
plot(1:plot_len, train_errors(1:plot_len), 'b-', 'LineWidth', 1);
title('训练集误差时间序列 (前500点)', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('误差');
grid on;

% 测试集误差时间序列
subplot(2, 2, 4);
plot_len = min(200, length(test_errors));
plot(1:plot_len, test_errors(1:plot_len), 'r-', 'LineWidth', 1);
title('测试集误差时间序列 (前200点)', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('误差');
grid on;

sgtitle('经典ESN误差分析', 'FontSize', 14, 'FontWeight', 'bold');

% 保存图像
saveas(gcf, fullfile(results_dir, 'classicESN_error_analysis.png'));
saveas(gcf, fullfile(results_dir, 'classicESN_error_analysis.fig'));
fprintf('误差分析图已保存\n');

%% 实验总结
fprintf('\n=== 经典ESN实验完成 ===\n');
fprintf('实验总结:\n');
fprintf('  数据集大小: 训练集 %d, 测试集 %d\n', min_train_len, min_test_len);
fprintf('  模型参数: 储备池大小 %d, 谱半径 %.2f, 泄漏率 %.2f\n', ...
        esn_params.resSize, esn_params.r, esn_params.leakingRate);
fprintf('  训练时间: %.2f秒\n', train_time);
fprintf('  最终性能: 测试集RMSE=%.4f, MAE=%.4f, R²=%.4f\n', test_rmse, test_mae, test_r2);
fprintf('所有结果已保存到: %s\n', results_dir);
fprintf('实验成功完成！\n');