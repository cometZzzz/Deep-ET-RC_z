function stl_main()
%% STL_MAIN - STL Decomposition and Visualization
% This function performs STL (Seasonal and Trend decomposition using Loess) 
% decomposition on electricity supply and demand data and visualizes the results.
%
% The function decomposes time series into:
% - Trend component
% - Seasonal component  
% - Remainder (residual) component

%% ======================== HYPERPARAMETERS ========================
% STL decomposition parameters
SEASONAL_PERIOD = 24;           % Daily cycle (24 hours)
SEASONAL_WINDOW = 'periodic';   % Seasonal window parameter
TREND_WINDOW = [];              % Trend window (auto-determined if empty)
ROBUST = true;                  % Use robust STL decomposition

% Data parameters
DATA_FILE = 'D:\eqrthquake\太阳能发电供需预测\代码\Deep_ER-RC_exp\merged_data.csv';
OUTPUT_DIR = 'D:\eqrthquake\太阳能发电供需预测\代码\STL-DeepETRC_分析\Deep_ETRC_EXP\results';

% Visualization parameters
FIGURE_SIZE = [100, 100, 1200, 800];  % [x, y, width, height]
FONT_SIZE = 12;
LINE_WIDTH = 1.5;

%% ======================== DATA LOADING ========================
fprintf('Loading data from: %s\n', DATA_FILE);

% Load the dataset
data = readtable(DATA_FILE);

% Ensure datetime column is in datetime format
if ~isdatetime(data.datetime)
    data.datetime = datetime(data.datetime);
end

% Extract supply and demand data
supply_data = data.target_0;
demand_data = data.target_1;
time_vector = data.datetime;

fprintf('Data loaded successfully. Total records: %d\n', height(data));
fprintf('Time range: %s to %s\n', datestr(min(time_vector)), datestr(max(time_vector)));

%% ======================== STL DECOMPOSITION ========================
fprintf('Performing STL decomposition...\n');

% Perform STL decomposition for supply data
fprintf('Decomposing supply data...\n');
[supply_trend, supply_seasonal, supply_remainder] = perform_stl_decomposition(...
    supply_data, SEASONAL_PERIOD, SEASONAL_WINDOW, TREND_WINDOW, ROBUST);

% Perform STL decomposition for demand data
fprintf('Decomposing demand data...\n');
[demand_trend, demand_seasonal, demand_remainder] = perform_stl_decomposition(...
    demand_data, SEASONAL_PERIOD, SEASONAL_WINDOW, TREND_WINDOW, ROBUST);

fprintf('STL decomposition completed successfully.\n');

%% ======================== VISUALIZATION ========================
fprintf('Creating visualizations...\n');

% Create supply decomposition visualization
create_stl_visualization(time_vector, supply_data, supply_trend, ...
    supply_seasonal, supply_remainder, 'Supply', FIGURE_SIZE, FONT_SIZE, LINE_WIDTH);

% Save supply figure
if ~exist(OUTPUT_DIR, 'dir')
    mkdir(OUTPUT_DIR);
end
supply_filename = fullfile(OUTPUT_DIR, 'stl_decomposition_supply.png');
saveas(gcf, supply_filename);
fprintf('Supply decomposition saved: %s\n', supply_filename);

% Create demand decomposition visualization
create_stl_visualization(time_vector, demand_data, demand_trend, ...
    demand_seasonal, demand_remainder, 'Demand', FIGURE_SIZE, FONT_SIZE, LINE_WIDTH);

% Save demand figure
demand_filename = fullfile(OUTPUT_DIR, 'stl_decomposition_demand.png');
saveas(gcf, demand_filename);
fprintf('Demand decomposition saved: %s\n', demand_filename);

%% ======================== SUMMARY STATISTICS ========================
fprintf('\n======================== DECOMPOSITION SUMMARY ========================\n');
fprintf('Supply Data:\n');
print_decomposition_stats('Supply', supply_data, supply_trend, supply_seasonal, supply_remainder);

fprintf('\nDemand Data:\n');
print_decomposition_stats('Demand', demand_data, demand_trend, demand_seasonal, demand_remainder);

fprintf('\nSTL decomposition analysis completed successfully!\n');
fprintf('Results saved to: %s\n', OUTPUT_DIR);

end

%% ======================== HELPER FUNCTIONS ========================

function [trend, seasonal, remainder] = perform_stl_decomposition(data, period, seasonal_window, trend_window, robust)
    % Perform STL decomposition using existing STL function
    
    % Remove NaN values
    valid_idx = ~isnan(data);
    clean_data = data(valid_idx);
    
    if length(clean_data) < 2 * period
        error('Insufficient data for STL decomposition. Need at least %d points.', 2 * period);
    end
    
    % Create U structure for STL function
    U_temp.u_train = clean_data;
    U_temp.u_test = [];
    U_temp.y_train = [];
    U_temp.y_test = [];
    
    % Call existing STL function
    U_decomposed = STL(U_temp, period);
    
    % Extract decomposed components
    seasonal_clean = U_decomposed.u_train(:, 1, 1);  % Seasonal component
    trend_clean = U_decomposed.u_train(:, 1, 2);     % Trend component
    remainder_clean = U_decomposed.u_train(:, 1, 3); % Remainder component
    
    % Initialize output arrays with NaN
    trend = NaN(size(data));
    seasonal = NaN(size(data));
    remainder = NaN(size(data));
    
    % Fill in the decomposed values
    trend(valid_idx) = trend_clean;
    seasonal(valid_idx) = seasonal_clean;
    remainder(valid_idx) = remainder_clean;
end

function create_stl_visualization(time_vector, original_data, trend, seasonal, remainder, data_type, fig_size, font_size, line_width)
    % Create STL decomposition visualization
    
    figure('Position', fig_size);
    
    % Original data
    subplot(4, 1, 1);
    plot(time_vector, original_data, 'b-', 'LineWidth', line_width);
    title(sprintf('Original %s Data', data_type), 'FontSize', font_size + 2, 'FontWeight', 'bold');
    ylabel(sprintf('%s Value', data_type), 'FontSize', font_size);
    grid on;
    set_axis_format(gca, font_size);
    
    % Trend component
    subplot(4, 1, 2);
    plot(time_vector, trend, 'r-', 'LineWidth', line_width);
    title('Trend Component', 'FontSize', font_size + 2, 'FontWeight', 'bold');
    ylabel('Trend Value', 'FontSize', font_size);
    grid on;
    set_axis_format(gca, font_size);
    
    % Seasonal component
    subplot(4, 1, 3);
    plot(time_vector, seasonal, 'g-', 'LineWidth', line_width);
    title('Seasonal Component', 'FontSize', font_size + 2, 'FontWeight', 'bold');
    ylabel('Seasonal Value', 'FontSize', font_size);
    grid on;
    set_axis_format(gca, font_size);
    
    % Remainder component
    subplot(4, 1, 4);
    plot(time_vector, remainder, 'm-', 'LineWidth', line_width);
    title('Remainder Component', 'FontSize', font_size + 2, 'FontWeight', 'bold');
    ylabel('Remainder Value', 'FontSize', font_size);
    xlabel('Time', 'FontSize', font_size);
    grid on;
    set_axis_format(gca, font_size);
    
    % Overall title
    sgtitle(sprintf('STL Decomposition - %s Data', data_type), 'FontSize', font_size + 4, 'FontWeight', 'bold');
end

function set_axis_format(ax, font_size)
    % Set axis formatting to avoid scientific notation and use English labels
    
    set(ax, 'FontSize', font_size);
    
    % Format y-axis to avoid scientific notation
    ax.YAxis.Exponent = 0;
    ytickformat(ax, '%.2f');
    
    % Format x-axis for time
    if isdatetime(ax.XLim)
        ax.XAxis.TickLabelFormat = 'MM/dd/yyyy';
    end
    
    % Set tick direction
    set(ax, 'TickDir', 'out');
    
    % Ensure no scientific notation
    set(ax, 'YTickMode', 'auto');
    set(ax, 'XTickMode', 'auto');
end

function print_decomposition_stats(data_name, original, trend, seasonal, remainder)
    % Print statistics for decomposition components
    
    fprintf('  Original %s - Mean: %.4f, Std: %.4f, Range: [%.4f, %.4f]\n', ...
        data_name, nanmean(original), nanstd(original), nanmin(original), nanmax(original));
    
    fprintf('  Trend - Mean: %.4f, Std: %.4f, Range: [%.4f, %.4f]\n', ...
        nanmean(trend), nanstd(trend), nanmin(trend), nanmax(trend));
    
    fprintf('  Seasonal - Mean: %.4f, Std: %.4f, Range: [%.4f, %.4f]\n', ...
        nanmean(seasonal), nanstd(seasonal), nanmin(seasonal), nanmax(seasonal));
    
    fprintf('  Remainder - Mean: %.4f, Std: %.4f, Range: [%.4f, %.4f]\n', ...
        nanmean(remainder), nanstd(remainder), nanmin(remainder), nanmax(remainder));
    
    % Calculate variance explained by each component
    total_var = nanvar(original);
    trend_var = nanvar(trend);
    seasonal_var = nanvar(seasonal);
    remainder_var = nanvar(remainder);
    
    fprintf('  Variance Explained - Trend: %.2f%%, Seasonal: %.2f%%, Remainder: %.2f%%\n', ...
        (trend_var/total_var)*100, (seasonal_var/total_var)*100, (remainder_var/total_var)*100);
end