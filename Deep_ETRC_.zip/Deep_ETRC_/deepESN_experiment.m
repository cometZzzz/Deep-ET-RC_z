%% Deep ESN实验 - 太阳能发电供需预测
% 使用Deep Echo State Network进行供给和需求序列预测
% 作者: AI Assistant
% 日期: 2024

clear; clc; close all;

%% 添加DeepESN路径
addpath('../../DeepESN/DeepESN');

%% 数据加载和预处理
fprintf('=== Deep ESN 太阳能发电供需预测实验 ===\n');
fprintf('正在加载数据...\n');

% 加载数据
data = readtable('merged_data.csv');
supply_data = data.target_0;  % 供给数据
demand_data = data.target_1;  % 需求数据

% 移除NaN值
valid_indices = ~isnan(supply_data) & ~isnan(demand_data);
supply_data = supply_data(valid_indices);
demand_data = demand_data(valid_indices);

% 数据标准化
supply_mean = mean(supply_data);
supply_std = std(supply_data);
demand_mean = mean(demand_data);
demand_std = std(demand_data);

supply_normalized = (supply_data - supply_mean) / supply_std;
demand_normalized = (demand_data - demand_mean) / demand_std;

fprintf('数据加载完成。供给数据长度: %d, 需求数据长度: %d\n', ...
    length(supply_data), length(demand_data));

%% 数据分割
train_ratio = 0.7;
train_len = floor(length(supply_data) * train_ratio);
test_len = length(supply_data) - train_len;

% 供给数据分割
supply_train = supply_normalized(1:train_len);
supply_test = supply_normalized(train_len+1:end);

% 需求数据分割
demand_train = demand_normalized(1:train_len);
demand_test = demand_normalized(train_len+1:end);

fprintf('训练集长度: %d, 测试集长度: %d\n', train_len, test_len);

%% Deep ESN参数设置
fprintf('\n正在设置Deep ESN参数...\n');

% Deep ESN超参数
Nr = 50;           % 每层储备池大小
Nl = 3;            % 储备池层数
Nu = 1;            % 输入维度
Ny = 1;            % 输出维度
spectral_radius = 0.9;     % 谱半径
input_scaling = 1.0;       % 输入缩放
inter_scaling = 0.5;       % 层间连接缩放
leaking_rate = 0.3;        % 泄漏率
washout = 100;             % 冲洗期
readout_regularization = 1e-6;  % 正则化参数

fprintf('Deep ESN参数:\n');
fprintf('  储备池层数: %d\n', Nl);
fprintf('  每层储备池大小: %d\n', Nr);
fprintf('  谱半径: %.2f\n', spectral_radius);
fprintf('  泄漏率: %.2f\n', leaking_rate);
fprintf('  正则化参数: %.0e\n', readout_regularization);

%% 供给序列预测
fprintf('\n=== 供给序列预测 ===\n');

% 创建Deep ESN模型
supply_deepesn = DeepESN();
supply_deepesn.Nr = Nr;
supply_deepesn.Nu = Nu;
supply_deepesn.Ny = Ny;
supply_deepesn.Nl = Nl;
supply_deepesn.spectral_radius = spectral_radius;
supply_deepesn.input_scaling = input_scaling;
supply_deepesn.inter_scaling = inter_scaling;
supply_deepesn.leaking_rate = leaking_rate;
supply_deepesn.washout = washout;
supply_deepesn.readout_regularization = readout_regularization;

% 初始化Deep ESN
supply_deepesn.initialize();

% 准备输入输出数据
supply_input = supply_train(1:end-1)';  % 输入: t时刻的值
supply_target = supply_train(2:end)';   % 目标: t+1时刻的值

% 训练索引和测试索引
training_indices = 1:(length(supply_input)-test_len);
test_indices = (length(supply_input)-test_len+1):length(supply_input);

% 扩展测试数据
supply_full_input = [supply_train(1:end-1); supply_test(1:end-1)]';
supply_full_target = [supply_train(2:end); supply_test(2:end)]';

fprintf('开始训练供给预测模型...\n');
tic;
[supply_train_pred, supply_test_pred] = supply_deepesn.train_test(...
    supply_full_input, supply_full_target, training_indices, test_indices);
supply_train_time = toc;
fprintf('供给模型训练完成，用时: %.2f秒\n', supply_train_time);

%% 需求序列预测
fprintf('\n=== 需求序列预测 ===\n');

% 创建Deep ESN模型
demand_deepesn = DeepESN();
demand_deepesn.Nr = Nr;
demand_deepesn.Nu = Nu;
demand_deepesn.Ny = Ny;
demand_deepesn.Nl = Nl;
demand_deepesn.spectral_radius = spectral_radius;
demand_deepesn.input_scaling = input_scaling;
demand_deepesn.inter_scaling = inter_scaling;
demand_deepesn.leaking_rate = leaking_rate;
demand_deepesn.washout = washout;
demand_deepesn.readout_regularization = readout_regularization;

% 初始化Deep ESN
demand_deepesn.initialize();

% 准备输入输出数据
demand_input = demand_train(1:end-1)';
demand_target = demand_train(2:end)';

% 扩展测试数据
demand_full_input = [demand_train(1:end-1); demand_test(1:end-1)]';
demand_full_target = [demand_train(2:end); demand_test(2:end)]';

fprintf('开始训练需求预测模型...\n');
tic;
[demand_train_pred, demand_test_pred] = demand_deepesn.train_test(...
    demand_full_input, demand_full_target, training_indices, test_indices);
demand_train_time = toc;
fprintf('需求模型训练完成，用时: %.2f秒\n', demand_train_time);

%% 反标准化预测结果
supply_train_pred_denorm = supply_train_pred * supply_std + supply_mean;
supply_test_pred_denorm = supply_test_pred * supply_std + supply_mean;
demand_train_pred_denorm = demand_train_pred * demand_std + demand_mean;
demand_test_pred_denorm = demand_test_pred * demand_std + demand_mean;

% 真实值（用于计算性能指标）
supply_train_true = supply_data(2:train_len);
supply_test_true = supply_data(train_len+1:end-1);
demand_train_true = demand_data(2:train_len);
demand_test_true = demand_data(train_len+1:end-1);

%% 性能评估
fprintf('\n=== 性能评估 ===\n');

% 供给预测性能
supply_train_rmse = sqrt(mean((supply_train_pred_denorm - supply_train_true).^2));
supply_train_mae = mean(abs(supply_train_pred_denorm - supply_train_true));
supply_train_r2 = 1 - sum((supply_train_true - supply_train_pred_denorm).^2) / ...
                   sum((supply_train_true - mean(supply_train_true)).^2);

supply_test_rmse = sqrt(mean((supply_test_pred_denorm - supply_test_true).^2));
supply_test_mae = mean(abs(supply_test_pred_denorm - supply_test_true));
supply_test_r2 = 1 - sum((supply_test_true - supply_test_pred_denorm).^2) / ...
                  sum((supply_test_true - mean(supply_test_true)).^2);

% 需求预测性能
demand_train_rmse = sqrt(mean((demand_train_pred_denorm - demand_train_true).^2));
demand_train_mae = mean(abs(demand_train_pred_denorm - demand_train_true));
demand_train_r2 = 1 - sum((demand_train_true - demand_train_pred_denorm).^2) / ...
                   sum((demand_train_true - mean(demand_train_true)).^2);

demand_test_rmse = sqrt(mean((demand_test_pred_denorm - demand_test_true).^2));
demand_test_mae = mean(abs(demand_test_pred_denorm - demand_test_true));
demand_test_r2 = 1 - sum((demand_test_true - demand_test_pred_denorm).^2) / ...
                  sum((demand_test_true - mean(demand_test_true)).^2);

% 显示结果
fprintf('供给预测结果:\n');
fprintf('  训练集 - RMSE: %.3f, MAE: %.3f, R²: %.4f\n', ...
    supply_train_rmse, supply_train_mae, supply_train_r2);
fprintf('  测试集 - RMSE: %.3f, MAE: %.3f, R²: %.4f\n', ...
    supply_test_rmse, supply_test_mae, supply_test_r2);

fprintf('\n需求预测结果:\n');
fprintf('  训练集 - RMSE: %.3f, MAE: %.3f, R²: %.4f\n', ...
    demand_train_rmse, demand_train_mae, demand_train_r2);
fprintf('  测试集 - RMSE: %.3f, MAE: %.3f, R²: %.4f\n', ...
    demand_test_rmse, demand_test_mae, demand_test_r2);

%% 保存结果
fprintf('\n正在保存结果...\n');

% 创建结果结构体
deepESN_results = struct();
deepESN_results.parameters = struct(...
    'Nr', Nr, 'Nl', Nl, 'spectral_radius', spectral_radius, ...
    'input_scaling', input_scaling, 'inter_scaling', inter_scaling, ...
    'leaking_rate', leaking_rate, 'washout', washout, ...
    'readout_regularization', readout_regularization);

deepESN_results.supply = struct(...
    'train_pred', supply_train_pred_denorm, 'test_pred', supply_test_pred_denorm, ...
    'train_true', supply_train_true, 'test_true', supply_test_true, ...
    'train_rmse', supply_train_rmse, 'train_mae', supply_train_mae, 'train_r2', supply_train_r2, ...
    'test_rmse', supply_test_rmse, 'test_mae', supply_test_mae, 'test_r2', supply_test_r2, ...
    'train_time', supply_train_time);

deepESN_results.demand = struct(...
    'train_pred', demand_train_pred_denorm, 'test_pred', demand_test_pred_denorm, ...
    'train_true', demand_train_true, 'test_true', demand_test_true, ...
    'train_rmse', demand_train_rmse, 'train_mae', demand_train_mae, 'train_r2', demand_train_r2, ...
    'test_rmse', demand_test_rmse, 'test_mae', demand_test_mae, 'test_r2', demand_test_r2, ...
    'train_time', demand_train_time);

% 保存到文件
save('deepESN_results.mat', 'deepESN_results');
fprintf('结果已保存到 deepESN_results.mat\n');

%% 可视化
fprintf('\n正在生成可视化图表...\n');

figure('Position', [100, 100, 1200, 800]);

% 供给预测对比
subplot(2, 2, 1);
plot(1:length(supply_train_true), supply_train_true, 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(1:length(supply_train_pred_denorm), supply_train_pred_denorm, 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('Deep ESN - 供给预测 (训练集)', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('供给量');
legend('Location', 'best');
grid on;

subplot(2, 2, 2);
plot(1:length(supply_test_true), supply_test_true, 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(1:length(supply_test_pred_denorm), supply_test_pred_denorm, 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title(sprintf('Deep ESN - 供给预测 (测试集) R²=%.4f', supply_test_r2), 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('供给量');
legend('Location', 'best');
grid on;

% 需求预测对比
subplot(2, 2, 3);
plot(1:length(demand_train_true), demand_train_true, 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(1:length(demand_train_pred_denorm), demand_train_pred_denorm, 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title('Deep ESN - 需求预测 (训练集)', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('需求量');
legend('Location', 'best');
grid on;

subplot(2, 2, 4);
plot(1:length(demand_test_true), demand_test_true, 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
hold on;
plot(1:length(demand_test_pred_denorm), demand_test_pred_denorm, 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
title(sprintf('Deep ESN - 需求预测 (测试集) R²=%.4f', demand_test_r2), 'FontSize', 12, 'FontWeight', 'bold');
xlabel('时间步');
ylabel('需求量');
legend('Location', 'best');
grid on;

% 保存图像
saveas(gcf, 'deepESN_prediction_comparison.png');
fprintf('预测对比图已保存到 deepESN_prediction_comparison.png\n');

%% 性能对比图
figure('Position', [200, 200, 1000, 600]);

% 性能指标对比
metrics = {'RMSE', 'MAE', 'R²'};
supply_train_metrics = [supply_train_rmse, supply_train_mae, supply_train_r2];
supply_test_metrics = [supply_test_rmse, supply_test_mae, supply_test_r2];
demand_train_metrics = [demand_train_rmse, demand_train_mae, demand_train_r2];
demand_test_metrics = [demand_test_rmse, demand_test_mae, demand_test_r2];

for i = 1:3
    subplot(1, 3, i);
    x = categorical({'供给-训练', '供给-测试', '需求-训练', '需求-测试'});
    y = [supply_train_metrics(i), supply_test_metrics(i), ...
         demand_train_metrics(i), demand_test_metrics(i)];
    bar(x, y, 'FaceColor', [0.2, 0.6, 0.8]);
    title(sprintf('Deep ESN - %s 对比', metrics{i}), 'FontSize', 12, 'FontWeight', 'bold');
    ylabel(metrics{i});
    grid on;
    
    % 添加数值标签
    for j = 1:length(y)
        text(j, y(j) + max(y)*0.02, sprintf('%.3f', y(j)), ...
            'HorizontalAlignment', 'center', 'FontSize', 10);
    end
end

% 保存性能对比图
saveas(gcf, 'deepESN_performance_comparison.png');
fprintf('性能对比图已保存到 deepESN_performance_comparison.png\n');

%% 总结
fprintf('\n=== Deep ESN 实验总结 ===\n');
fprintf('模型配置: %d层Deep ESN，每层%d个神经元\n', Nl, Nr);
fprintf('总训练时间: %.2f秒\n', supply_train_time + demand_train_time);
fprintf('\n最终测试集性能:\n');
fprintf('供给预测: RMSE=%.3f, MAE=%.3f, R²=%.4f\n', ...
    supply_test_rmse, supply_test_mae, supply_test_r2);
fprintf('需求预测: RMSE=%.3f, MAE=%.3f, R²=%.4f\n', ...
    demand_test_rmse, demand_test_mae, demand_test_r2);
fprintf('\nDeep ESN实验完成！\n');