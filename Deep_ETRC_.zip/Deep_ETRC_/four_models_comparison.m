%% 四模型对比分析脚本 - 太阳能发电供需预测
% 对比模型: Deep ET-RC (STL), ResESN, Deep ESN, LSTM
% 排除经典ESN模型

clear; clc; close all;

%% 配置参数
models = {'Deep ET-RC (STL)', 'ResESN', 'Deep ESN', 'LSTM'};
output_dir = '对比图';

% 确保输出目录存在
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

fprintf('=== 四模型性能对比分析 ===\n');
fprintf('对比模型: %s\n', strjoin(models, ', '));
fprintf('输出目录: %s\n', output_dir);

%% 1. 加载各模型结果
fprintf('\n1. 加载模型预测结果...\n');

% 初始化结果存储
model_results = struct();
model_performance = struct();

try
    %% 1.1 Deep ET-RC (STL) 结果
    fprintf('加载 Deep ET-RC (STL) 结果...\n');
    deepetrc_file = 'results/performance_metrics.csv';
    if exist(deepetrc_file, 'file')
        deepetrc_data = readtable(deepetrc_file);
        model_results.deep_etrc.supply_mae = deepetrc_data.supply_mae;
        model_results.deep_etrc.supply_rmse = deepetrc_data.supply_rmse;
        model_results.deep_etrc.supply_mse = deepetrc_data.supply_mse;
        model_results.deep_etrc.demand_mae = deepetrc_data.demand_mae;
        model_results.deep_etrc.demand_rmse = deepetrc_data.demand_rmse;
        model_results.deep_etrc.demand_mse = deepetrc_data.demand_mse;
        fprintf('  Deep ET-RC (STL) 结果加载成功\n');
    else
        error('Deep ET-RC结果文件不存在: %s', deepetrc_file);
    end
    
    %% 1.2 ResESN 结果
    fprintf('加载 ResESN 结果...\n');
    resESN_file = '../results/模型预测结果/ResESN/resESN_performance.csv';
    if exist(resESN_file, 'file')
        resESN_data = readtable(resESN_file);
        model_results.resESN.supply_mae = resESN_data.supply_test_mae;
        model_results.resESN.supply_rmse = resESN_data.supply_test_rmse;
        model_results.resESN.supply_mse = resESN_data.supply_test_mse;
        model_results.resESN.demand_mae = resESN_data.demand_test_mae;
        model_results.resESN.demand_rmse = resESN_data.demand_test_rmse;
        model_results.resESN.demand_mse = resESN_data.demand_test_mse;
        fprintf('  ResESN 结果加载成功\n');
    else
        error('ResESN结果文件不存在: %s', resESN_file);
    end
    
    %% 1.3 Deep ESN 结果
    fprintf('加载 Deep ESN 结果...\n');
    deepESN_file = '../results/模型预测结果/DeepESN/deepESN_performance.csv';
    if exist(deepESN_file, 'file')
        deepESN_data = readtable(deepESN_file);
        model_results.deepESN.supply_mae = deepESN_data.supply_test_mae;
        model_results.deepESN.supply_rmse = deepESN_data.supply_test_rmse;
        model_results.deepESN.supply_mse = deepESN_data.supply_test_mse;
        model_results.deepESN.demand_mae = deepESN_data.demand_test_mae;
        model_results.deepESN.demand_rmse = deepESN_data.demand_test_rmse;
        model_results.deepESN.demand_mse = deepESN_data.demand_test_mse;
        fprintf('  Deep ESN 结果加载成功\n');
    else
        error('Deep ESN结果文件不存在: %s', deepESN_file);
    end
    
    %% 1.4 LSTM 结果
    fprintf('加载 LSTM 结果...\n');
    lstm_file = '../results/模型预测结果/LSTM/robust_lstm_performance.csv';
    if exist(lstm_file, 'file')
        lstm_data = readtable(lstm_file);
        model_results.lstm.supply_mae = lstm_data.supply_mae;
        model_results.lstm.supply_rmse = lstm_data.supply_rmse;
        model_results.lstm.supply_mse = lstm_data.supply_mse;
        model_results.lstm.demand_mae = lstm_data.demand_mae;
        model_results.lstm.demand_rmse = lstm_data.demand_rmse;
        model_results.lstm.demand_mse = lstm_data.demand_mse;
        fprintf('  LSTM 结果加载成功\n');
    else
        error('LSTM结果文件不存在: %s', lstm_file);
    end
    
catch ME
    fprintf('错误: %s\n', ME.message);
    return;
end

%% 2. 计算性能指标统计
fprintf('\n2. 计算性能指标统计...\n');

% 提取各模型的MAE、RMSE、MSE数据
supply_mae_data = [
    mean(model_results.deep_etrc.supply_mae), ...
    mean(model_results.resESN.supply_mae), ...
    mean(model_results.deepESN.supply_mae), ...
    mean(model_results.lstm.supply_mae)
];

demand_mae_data = [
    mean(model_results.deep_etrc.demand_mae), ...
    mean(model_results.resESN.demand_mae), ...
    mean(model_results.deepESN.demand_mae), ...
    mean(model_results.lstm.demand_mae)
];

supply_rmse_data = [
    mean(model_results.deep_etrc.supply_rmse), ...
    mean(model_results.resESN.supply_rmse), ...
    mean(model_results.deepESN.supply_rmse), ...
    mean(model_results.lstm.supply_rmse)
];

demand_rmse_data = [
    mean(model_results.deep_etrc.demand_rmse), ...
    mean(model_results.resESN.demand_rmse), ...
    mean(model_results.deepESN.demand_rmse), ...
    mean(model_results.lstm.demand_rmse)
];

supply_mse_data = [
    mean(model_results.deep_etrc.supply_mse), ...
    mean(model_results.resESN.supply_mse), ...
    mean(model_results.deepESN.supply_mse), ...
    mean(model_results.lstm.supply_mse)
];

demand_mse_data = [
    mean(model_results.deep_etrc.demand_mse), ...
    mean(model_results.resESN.demand_mse), ...
    mean(model_results.deepESN.demand_mse), ...
    mean(model_results.lstm.demand_mse)
];

%% 3. 创建性能对比表
fprintf('\n3. 创建性能对比表...\n');

performance_table = table();
performance_table.Model = models';
performance_table.Supply_MAE = supply_mae_data';
performance_table.Supply_RMSE = supply_rmse_data';
performance_table.Supply_MSE = supply_mse_data';
performance_table.Demand_MAE = demand_mae_data';
performance_table.Demand_RMSE = demand_rmse_data';
performance_table.Demand_MSE = demand_mse_data';

% 保存性能对比表
performance_file = fullfile(output_dir, 'four_models_performance_comparison.csv');
writetable(performance_table, performance_file);
fprintf('性能对比表已保存: %s\n', performance_file);

%% 4. 绘制箱线图
fprintf('\n4. 绘制性能对比箱线图...\n');

% 4.1 供给预测对比箱线图
figure('Position', [100, 100, 1400, 1000]);

% MAE对比
subplot(2, 3, 1);
supply_mae_box_data = [
    model_results.deep_etrc.supply_mae, ...
    model_results.resESN.supply_mae, ...
    model_results.deepESN.supply_mae, ...
    model_results.lstm.supply_mae
];
boxplot(supply_mae_box_data, 'Labels', models);
title('供给预测 - MAE对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MAE', 'FontSize', 12);
grid on;
xtickangle(45);

% RMSE对比
subplot(2, 3, 2);
supply_rmse_box_data = [
    model_results.deep_etrc.supply_rmse, ...
    model_results.resESN.supply_rmse, ...
    model_results.deepESN.supply_rmse, ...
    model_results.lstm.supply_rmse
];
boxplot(supply_rmse_box_data, 'Labels', models);
title('供给预测 - RMSE对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('RMSE', 'FontSize', 12);
grid on;
xtickangle(45);

% MSE对比
subplot(2, 3, 3);
supply_mse_box_data = [
    model_results.deep_etrc.supply_mse, ...
    model_results.resESN.supply_mse, ...
    model_results.deepESN.supply_mse, ...
    model_results.lstm.supply_mse
];
boxplot(supply_mse_box_data, 'Labels', models);
title('供给预测 - MSE对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MSE', 'FontSize', 12);
grid on;
xtickangle(45);

% 需求预测对比箱线图
% MAE对比
subplot(2, 3, 4);
demand_mae_box_data = [
    model_results.deep_etrc.demand_mae, ...
    model_results.resESN.demand_mae, ...
    model_results.deepESN.demand_mae, ...
    model_results.lstm.demand_mae
];
boxplot(demand_mae_box_data, 'Labels', models);
title('需求预测 - MAE对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MAE', 'FontSize', 12);
grid on;
xtickangle(45);

% RMSE对比
subplot(2, 3, 5);
demand_rmse_box_data = [
    model_results.deep_etrc.demand_rmse, ...
    model_results.resESN.demand_rmse, ...
    model_results.deepESN.demand_rmse, ...
    model_results.lstm.demand_rmse
];
boxplot(demand_rmse_box_data, 'Labels', models);
title('需求预测 - RMSE对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('RMSE', 'FontSize', 12);
grid on;
xtickangle(45);

% MSE对比
subplot(2, 3, 6);
demand_mse_box_data = [
    model_results.deep_etrc.demand_mse, ...
    model_results.resESN.demand_mse, ...
    model_results.deepESN.demand_mse, ...
    model_results.lstm.demand_mse
];
boxplot(demand_mse_box_data, 'Labels', models);
title('需求预测 - MSE对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MSE', 'FontSize', 12);
grid on;
xtickangle(45);

sgtitle('四模型性能对比 - 箱线图', 'FontSize', 16, 'FontWeight', 'bold');

% 保存综合对比图
comprehensive_fig_file = fullfile(output_dir, 'four_models_comprehensive_comparison.png');
saveas(gcf, comprehensive_fig_file);
fprintf('综合对比图已保存: %s\n', comprehensive_fig_file);

%% 5. 单独的供给和需求预测对比图
fprintf('\n5. 生成单独的供给和需求预测对比图...\n');

% 5.1 供给预测对比
figure('Position', [200, 200, 1200, 400]);
subplot(1, 3, 1);
boxplot(supply_mae_box_data, 'Labels', models);
title('供给预测 MAE', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MAE', 'FontSize', 12);
grid on;
xtickangle(45);

subplot(1, 3, 2);
boxplot(supply_rmse_box_data, 'Labels', models);
title('供给预测 RMSE', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('RMSE', 'FontSize', 12);
grid on;
xtickangle(45);

subplot(1, 3, 3);
boxplot(supply_mse_box_data, 'Labels', models);
title('供给预测 MSE', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MSE', 'FontSize', 12);
grid on;
xtickangle(45);

sgtitle('供给预测性能对比', 'FontSize', 16, 'FontWeight', 'bold');
supply_fig_file = fullfile(output_dir, 'four_models_supply_prediction_comparison.png');
saveas(gcf, supply_fig_file);
fprintf('供给预测对比图已保存: %s\n', supply_fig_file);

% 5.2 需求预测对比
figure('Position', [300, 300, 1200, 400]);
subplot(1, 3, 1);
boxplot(demand_mae_box_data, 'Labels', models);
title('需求预测 MAE', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MAE', 'FontSize', 12);
grid on;
xtickangle(45);

subplot(1, 3, 2);
boxplot(demand_rmse_box_data, 'Labels', models);
title('需求预测 RMSE', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('RMSE', 'FontSize', 12);
grid on;
xtickangle(45);

subplot(1, 3, 3);
boxplot(demand_mse_box_data, 'Labels', models);
title('需求预测 MSE', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MSE', 'FontSize', 12);
grid on;
xtickangle(45);

sgtitle('需求预测性能对比', 'FontSize', 16, 'FontWeight', 'bold');
demand_fig_file = fullfile(output_dir, 'four_models_demand_prediction_comparison.png');
saveas(gcf, demand_fig_file);
fprintf('需求预测对比图已保存: %s\n', demand_fig_file);

%% 6. 生成分析报告
fprintf('\n6. 生成分析报告...\n');

report_file = fullfile(output_dir, 'four_models_analysis_report.txt');
fid = fopen(report_file, 'w');

fprintf(fid, '四模型性能对比分析报告\n');
fprintf(fid, '======================\n\n');
fprintf(fid, '对比模型: %s\n\n', strjoin(models, ', '));

fprintf(fid, '性能指标汇总:\n');
fprintf(fid, '------------\n\n');

fprintf(fid, '供给预测性能 (MAE):\n');
for i = 1:length(models)
    fprintf(fid, '  %s: %.4f\n', models{i}, supply_mae_data(i));
end

fprintf(fid, '\n需求预测性能 (MAE):\n');
for i = 1:length(models)
    fprintf(fid, '  %s: %.4f\n', models{i}, demand_mae_data(i));
end

% 找出最佳模型
[~, best_supply_idx] = min(supply_mae_data);
[~, best_demand_idx] = min(demand_mae_data);

fprintf(fid, '\n最佳模型 (基于MAE):\n');
fprintf(fid, '  供给预测: %s (MAE: %.4f)\n', models{best_supply_idx}, supply_mae_data(best_supply_idx));
fprintf(fid, '  需求预测: %s (MAE: %.4f)\n', models{best_demand_idx}, demand_mae_data(best_demand_idx));

fprintf(fid, '\n主要观察:\n');
fprintf(fid, '--------\n');
fprintf(fid, '1. Deep ET-RC (STL) 在修复后的表现\n');
fprintf(fid, '2. ResESN 的稳定性表现\n');
fprintf(fid, '3. Deep ESN 的深度网络优势\n');
fprintf(fid, '4. LSTM 的时序建模能力\n');

fclose(fid);
fprintf('分析报告已保存: %s\n', report_file);

%% 7. 保存结果数据
fprintf('\n7. 保存结果数据...\n');

results_file = fullfile(output_dir, 'four_models_analysis_results.mat');
save(results_file, 'model_results', 'performance_table', 'models', ...
     'supply_mae_data', 'demand_mae_data', 'supply_rmse_data', 'demand_rmse_data', ...
     'supply_mse_data', 'demand_mse_data');
fprintf('结果数据已保存: %s\n', results_file);

%% 8. 显示结果摘要
fprintf('\n=== 四模型对比分析完成 ===\n');
fprintf('生成的文件:\n');
fprintf('  - 性能对比表: %s\n', performance_file);
fprintf('  - 综合对比图: %s\n', comprehensive_fig_file);
fprintf('  - 供给预测对比图: %s\n', supply_fig_file);
fprintf('  - 需求预测对比图: %s\n', demand_fig_file);
fprintf('  - 分析报告: %s\n', report_file);
fprintf('  - 结果数据: %s\n', results_file);

fprintf('\n关键发现:\n');
fprintf('  最佳供给预测模型: %s (MAE: %.4f)\n', models{best_supply_idx}, supply_mae_data(best_supply_idx));
fprintf('  最佳需求预测模型: %s (MAE: %.4f)\n', models{best_demand_idx}, demand_mae_data(best_demand_idx));

fprintf('\n四模型对比分析已完成！\n');