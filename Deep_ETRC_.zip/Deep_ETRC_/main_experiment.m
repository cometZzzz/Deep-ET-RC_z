%% Deep ET-RC 太阳能发电供需预测实验主脚本
% 作者: AI Assistant
% 日期: 2024
% 描述: 使用Deep ET-RC模型进行多步预测的纯净版实验框架

clear; clc; close all;

%% ========== 实验配置参数 ==========
% STL分解配置
STL_CONFIG = struct();
STL_CONFIG.enable = true;           % STL分解开关 (true/false)
STL_CONFIG.season_length = 150;     % 季节长度
STL_CONFIG.trend_window = 301;      % 趋势窗口大小 (奇数)
STL_CONFIG.seasonal_window = 151;   % 季节窗口大小 (奇数)
STL_CONFIG.robust = true;           % 是否使用鲁棒STL

% 数据配置
DATA_CONFIG = struct();
DATA_CONFIG.data_file = 'merged_data.csv';
DATA_CONFIG.feature_cols = [1,2,3,4,5,6,8,9,10,11,12];  % 共同特征列（排除时间列后的索引）
DATA_CONFIG.supply_col = 13;        % 供给目标列（target_0）
DATA_CONFIG.demand_col = 14;        % 消耗目标列（target_1）
DATA_CONFIG.train_start = '2021-10-01 00:00:00';  % 训练集开始时间
DATA_CONFIG.train_end = '2022-10-01 23:00:00';    % 训练集结束时间
DATA_CONFIG.test_start = '2022-10-02 00:00:00';   % 测试集开始时间
DATA_CONFIG.test_end = '2023-06-01 23:00:00';     % 测试集结束时间
DATA_CONFIG.max_horizon = 5;        % 最大预测步长

% Deep ET-RC模型配置
MODEL_CONFIG = struct();
MODEL_CONFIG.n_layers = 4;          % 总层数 (1个RC层 + 3个ET层)

% RC层参数
MODEL_CONFIG.RC = struct();
MODEL_CONFIG.RC.inSize = 14;        % 输入维度 (11个气象特征 + 3个STL分量 = 14维输入)
MODEL_CONFIG.RC.outSize = 1;        % 输出维度
MODEL_CONFIG.RC.resSize = 200;      % 储备池大小
MODEL_CONFIG.RC.leakingRate = 0.8;  % 泄漏率
MODEL_CONFIG.RC.reg = 1e-5;         % 正则化系数
MODEL_CONFIG.RC.r = 0.99;           % 谱半径

% ET层参数 (每层可独立配置)
MODEL_CONFIG.ET = struct();
% ET层1
MODEL_CONFIG.ET.layer1 = struct();
MODEL_CONFIG.ET.layer1.inSize = 1;
MODEL_CONFIG.ET.layer1.outSize = 1;
MODEL_CONFIG.ET.layer1.resSize = 100;
MODEL_CONFIG.ET.layer1.leakingRate = 0.7;
MODEL_CONFIG.ET.layer1.reg = 1e-6;
MODEL_CONFIG.ET.layer1.r = 0.99;

% ET层2
MODEL_CONFIG.ET.layer2 = struct();
MODEL_CONFIG.ET.layer2.inSize = 1;
MODEL_CONFIG.ET.layer2.outSize = 1;
MODEL_CONFIG.ET.layer2.resSize = 100;
MODEL_CONFIG.ET.layer2.leakingRate = 0.6;
MODEL_CONFIG.ET.layer2.reg = 1e-7;
MODEL_CONFIG.ET.layer2.r = 0.99;

% ET层3
MODEL_CONFIG.ET.layer3 = struct();
MODEL_CONFIG.ET.layer3.inSize = 1;
MODEL_CONFIG.ET.layer3.outSize = 1;
MODEL_CONFIG.ET.layer3.resSize = 100;
MODEL_CONFIG.ET.layer3.leakingRate = 0.5;
MODEL_CONFIG.ET.layer3.reg = 1e-7;
MODEL_CONFIG.ET.layer3.r = 0.99;

% 实验配置
EXPERIMENT_CONFIG = struct();
EXPERIMENT_CONFIG.random_seed = 42;         % 随机种子
EXPERIMENT_CONFIG.save_results = true;      % 是否保存结果
EXPERIMENT_CONFIG.save_figures = true;      % 是否保存图片
EXPERIMENT_CONFIG.results_dir = 'results\模型预测结果';  % 结果保存目录
EXPERIMENT_CONFIG.verbose = true;           % 是否显示详细信息

%% ========== 实验执行 ==========
fprintf('=== Deep ET-RC 太阳能发电供需预测实验 ===\n');
fprintf('STL分解: %s\n', char(string(STL_CONFIG.enable)));
fprintf('预测步长: 1-%d\n', DATA_CONFIG.max_horizon);
fprintf('模型层数: %d\n', MODEL_CONFIG.n_layers);
fprintf('==========================================\n\n');

% 设置随机种子
rng(EXPERIMENT_CONFIG.random_seed);

% 创建结果保存目录
if EXPERIMENT_CONFIG.save_results && ~exist(EXPERIMENT_CONFIG.results_dir, 'dir')
    mkdir(EXPERIMENT_CONFIG.results_dir);
end

try
    % 执行实验
    results = run_deep_etrc_experiment(DATA_CONFIG, MODEL_CONFIG, STL_CONFIG, EXPERIMENT_CONFIG);
    
    % 显示总结
    fprintf('\n=== 实验完成 ===\n');
    fprintf('总耗时: %.2f 秒\n', results.total_time);
    fprintf('平均供给RMSE: %.6f\n', mean([results.performance_metrics.supply_rmse]));
    fprintf('平均消耗RMSE: %.6f\n', mean([results.performance_metrics.demand_rmse]));
    fprintf('平均供需关系RMSE: %.6f\n', mean([results.performance_metrics.balance_rmse]));
    
    if EXPERIMENT_CONFIG.save_results
        fprintf('结果已保存到: %s\n', EXPERIMENT_CONFIG.results_dir);
    end
    
catch ME
    fprintf('实验执行出错: %s\n', ME.message);
    fprintf('错误位置: %s (第%d行)\n', ME.stack(1).name, ME.stack(1).line);
    
    % 保存错误日志
    error_log_file = fullfile(EXPERIMENT_CONFIG.results_dir, 'error_log.txt');
    fid = fopen(error_log_file, 'w');
    fprintf(fid, '%s', getReport(ME, 'extended'));
    fclose(fid);
    fprintf('错误日志已保存到: %s\n', error_log_file);
end

fprintf('\n实验脚本执行完毕。\n');