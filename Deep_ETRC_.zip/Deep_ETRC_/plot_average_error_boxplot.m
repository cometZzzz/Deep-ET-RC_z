%% 四模型平均误差箱线图绘制脚本
% 绘制LSTM、ResESN、DeepESN、Deep ET-RC四个模型的平均误差箱线图
% 作者: AI Assistant
% 日期: 2024年10月

clear; clc; close all;

%% 1. 数据准备
fprintf('=== 四模型平均误差箱线图分析 ===\n');
fprintf('正在准备数据...\n');

% 模型名称
model_names = {'LSTM', 'ResESN', 'DeepESN', 'Deep ET-RC'};

% 根据收集到的数据定义各模型的MAE和RMSE值
% LSTM数据
lstm_supply_mae = 1790.254;
lstm_demand_mae = 3516.014;
lstm_supply_rmse = 5038.229;
lstm_demand_rmse = 4298.825;

% ResESN数据 (测试集)
resESN_supply_mae = 963.713211220977;
resESN_demand_mae = 755.83277844897;
resESN_supply_rmse = 1631.05544155936;
resESN_demand_rmse = 1899.19901201051;

% DeepESN数据 (从对比表获取)
deepESN_supply_mae = 2947.30063792049;
deepESN_demand_mae = 559.707061264671;
deepESN_supply_rmse = 9478.13165167698;
deepESN_demand_rmse = 923.666953670108;

% Deep ET-RC数据 (STL版本)
deepETRC_supply_mae = 43.9046978443561;
deepETRC_demand_mae = 619.175591658494;
deepETRC_supply_rmse = 148.909706077974;
deepETRC_demand_rmse = 954.612296969655;

%% 2. 计算平均误差
fprintf('计算各模型平均误差...\n');

% MAE平均值
mae_averages = [
    (lstm_supply_mae + lstm_demand_mae) / 2;        % LSTM
    (resESN_supply_mae + resESN_demand_mae) / 2;    % ResESN
    (deepESN_supply_mae + deepESN_demand_mae) / 2;  % DeepESN
    (deepETRC_supply_mae + deepETRC_demand_mae) / 2 % Deep ET-RC
];

% RMSE平均值
rmse_averages = [
    (lstm_supply_rmse + lstm_demand_rmse) / 2;        % LSTM
    (resESN_supply_rmse + resESN_demand_rmse) / 2;    % ResESN
    (deepESN_supply_rmse + deepESN_demand_rmse) / 2;  % DeepESN
    (deepETRC_supply_rmse + deepETRC_demand_rmse) / 2 % Deep ET-RC
];

% 显示计算结果
fprintf('\n各模型平均误差:\n');
for i = 1:length(model_names)
    fprintf('%s: MAE=%.2f, RMSE=%.2f\n', model_names{i}, mae_averages(i), rmse_averages(i));
end

%% 3. 创建箱线图数据
% 为了创建箱线图，我们需要为每个模型创建数据点
% 这里使用供给和需求的误差值作为数据点

% MAE数据矩阵 (每列代表一个模型)
mae_data = [
    lstm_supply_mae, resESN_supply_mae, deepESN_supply_mae, deepETRC_supply_mae;
    lstm_demand_mae, resESN_demand_mae, deepESN_demand_mae, deepETRC_demand_mae
];

% RMSE数据矩阵
rmse_data = [
    lstm_supply_rmse, resESN_supply_rmse, deepESN_supply_rmse, deepETRC_supply_rmse;
    lstm_demand_rmse, resESN_demand_rmse, deepESN_demand_rmse, deepETRC_demand_rmse
];

%% 4. 绘制MAE箱线图
fprintf('\n正在绘制MAE箱线图...\n');

figure('Position', [100, 100, 1200, 800]);

% MAE箱线图
subplot(2, 2, 1);
boxplot(mae_data, 'Labels', model_names);
title('各模型MAE箱线图', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MAE值', 'FontSize', 12);
xlabel('模型', 'FontSize', 12);
grid on;
set(gca, 'FontSize', 10);

% 添加数值标注
for i = 1:length(model_names)
    text(i, max(mae_data(:, i)) + 100, sprintf('%.1f', mae_averages(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 9, 'FontWeight', 'bold');
end

%% 5. 绘制RMSE箱线图
subplot(2, 2, 2);
boxplot(rmse_data, 'Labels', model_names);
title('各模型RMSE箱线图', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('RMSE值', 'FontSize', 12);
xlabel('模型', 'FontSize', 12);
grid on;
set(gca, 'FontSize', 10);

% 添加数值标注
for i = 1:length(model_names)
    text(i, max(rmse_data(:, i)) + 200, sprintf('%.1f', rmse_averages(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 9, 'FontWeight', 'bold');
end

%% 6. 绘制平均误差对比柱状图
subplot(2, 2, 3);
bar_data = [mae_averages, rmse_averages];
bar_handle = bar(bar_data);
title('各模型平均误差对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('误差值', 'FontSize', 12);
xlabel('模型', 'FontSize', 12);
legend({'平均MAE', '平均RMSE'}, 'Location', 'northeast');
set(gca, 'XTickLabel', model_names);
grid on;
set(gca, 'FontSize', 10);

% 添加数值标注
for i = 1:length(model_names)
    text(i-0.15, mae_averages(i) + max(mae_averages)*0.02, sprintf('%.1f', mae_averages(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 8);
    text(i+0.15, rmse_averages(i) + max(rmse_averages)*0.02, sprintf('%.1f', rmse_averages(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 8);
end

%% 7. 绘制供给vs需求误差对比
subplot(2, 2, 4);
supply_mae = [lstm_supply_mae, resESN_supply_mae, deepESN_supply_mae, deepETRC_supply_mae];
demand_mae = [lstm_demand_mae, resESN_demand_mae, deepESN_demand_mae, deepETRC_demand_mae];

scatter_data = [supply_mae; demand_mae];
bar_handle2 = bar(scatter_data');
title('供给vs需求MAE对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MAE值', 'FontSize', 12);
xlabel('模型', 'FontSize', 12);
legend({'供给MAE', '需求MAE'}, 'Location', 'northeast');
set(gca, 'XTickLabel', model_names);
grid on;
set(gca, 'FontSize', 10);

%% 8. 调整整体布局
sgtitle('四模型平均误差箱线图分析', 'FontSize', 16, 'FontWeight', 'bold');

%% 9. 保存结果
fprintf('\n正在保存结果...\n');

% 创建结果目录
results_dir = 'results/average_error_boxplot';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

% 保存图片
saveas(gcf, fullfile(results_dir, 'four_models_average_error_boxplot.png'));
saveas(gcf, fullfile(results_dir, 'four_models_average_error_boxplot.fig'));

% 保存数据表
comparison_table = table(model_names', mae_averages, rmse_averages, ...
    'VariableNames', {'Model', 'Average_MAE', 'Average_RMSE'});

% 添加详细数据
detailed_table = table(model_names', ...
    [lstm_supply_mae; resESN_supply_mae; deepESN_supply_mae; deepETRC_supply_mae], ...
    [lstm_demand_mae; resESN_demand_mae; deepESN_demand_mae; deepETRC_demand_mae], ...
    mae_averages, ...
    [lstm_supply_rmse; resESN_supply_rmse; deepESN_supply_rmse; deepETRC_supply_rmse], ...
    [lstm_demand_rmse; resESN_demand_rmse; deepESN_demand_rmse; deepETRC_demand_rmse], ...
    rmse_averages, ...
    'VariableNames', {'Model', 'Supply_MAE', 'Demand_MAE', 'Average_MAE', ...
                      'Supply_RMSE', 'Demand_RMSE', 'Average_RMSE'});

writetable(comparison_table, fullfile(results_dir, 'models_average_error_summary.csv'));
writetable(detailed_table, fullfile(results_dir, 'models_detailed_error_comparison.csv'));

%% 10. 生成分析报告
fprintf('生成分析报告...\n');

report_file = fullfile(results_dir, 'average_error_boxplot_analysis_report.txt');
fid = fopen(report_file, 'w');

fprintf(fid, '=== 四模型平均误差箱线图分析报告 ===\n');
fprintf(fid, '生成时间: %s\n\n', datestr(now));

fprintf(fid, '1. 参与对比的模型:\n');
for i = 1:length(model_names)
    fprintf(fid, '   %d. %s\n', i, model_names{i});
end

fprintf(fid, '\n2. 性能指标对比 (MAE):\n');
for i = 1:length(model_names)
    fprintf(fid, '   %s: 供给=%.2f, 需求=%.2f, 平均=%.2f\n', ...
        model_names{i}, mae_data(1,i), mae_data(2,i), mae_averages(i));
end

fprintf(fid, '\n3. 性能指标对比 (RMSE):\n');
for i = 1:length(model_names)
    fprintf(fid, '   %s: 供给=%.2f, 需求=%.2f, 平均=%.2f\n', ...
        model_names{i}, rmse_data(1,i), rmse_data(2,i), rmse_averages(i));
end

fprintf(fid, '\n4. 关键发现:\n');
[~, best_mae_idx] = min(mae_averages);
[~, best_rmse_idx] = min(rmse_averages);
fprintf(fid, '   - MAE最佳模型: %s (%.2f)\n', model_names{best_mae_idx}, mae_averages(best_mae_idx));
fprintf(fid, '   - RMSE最佳模型: %s (%.2f)\n', model_names{best_rmse_idx}, rmse_averages(best_rmse_idx));

fprintf(fid, '\n5. 模型排名 (按平均MAE):\n');
[sorted_mae, mae_rank] = sort(mae_averages);
for i = 1:length(model_names)
    fprintf(fid, '   %d. %s: %.2f\n', i, model_names{mae_rank(i)}, sorted_mae(i));
end

fprintf(fid, '\n6. 生成的文件:\n');
fprintf(fid, '   - four_models_average_error_boxplot.png/fig: 箱线图\n');
fprintf(fid, '   - models_average_error_summary.csv: 平均误差汇总\n');
fprintf(fid, '   - models_detailed_error_comparison.csv: 详细对比表\n');
fprintf(fid, '   - average_error_boxplot_analysis_report.txt: 本分析报告\n');

fclose(fid);

%% 11. 显示完成信息
fprintf('\n=== 分析完成 ===\n');
fprintf('结果已保存到: %s\n', results_dir);
fprintf('生成的文件:\n');
fprintf('  - 箱线图: four_models_average_error_boxplot.png\n');
fprintf('  - 汇总表: models_average_error_summary.csv\n');
fprintf('  - 详细表: models_detailed_error_comparison.csv\n');
fprintf('  - 分析报告: average_error_boxplot_analysis_report.txt\n');

% 显示最终结果
fprintf('\n最终排名 (按平均MAE):\n');
for i = 1:length(model_names)
    fprintf('  %d. %s: %.2f\n', i, model_names{mae_rank(i)}, sorted_mae(i));
end

fprintf('\n脚本执行完成！\n');