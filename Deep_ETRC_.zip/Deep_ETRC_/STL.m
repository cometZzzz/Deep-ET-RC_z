function U = STL(U_, season_length)
% STL - Seasonal-Trend decomposition 
% 对输入数据进行季节性-趋势分解，仅处理特征（X），不处理维度（y）
%
% 输入参数:
%   U_: 输入数据结构体，包含:
%       U_.u_train - 训练输入
%       U_.u_test - 测试输入
%       U_.y_train - 训练目标
%       U_.y_test - 测试目标
%   season_length - [可选] 季节周期长度，默认为24
%
% 输出参数:
%   U: 包含分解后数据的结构体，与输入结构相同，但u_train和u_test被分解为三维结构
%      (季节性、趋势性和残差)

% 检查可选参数
if nargin < 2
    season_length = 24; % 默认季节长度
end

% 复制输入结构体
U = U_;

% 处理训练数据
if ~isempty(U_.u_train)
    train_size = size(U_.u_train, 1);
    train_dim = size(U_.u_train, 2);
    
    % 初始化分解后的训练数据结构
    U.u_train = zeros(train_size, train_dim, 3); % 第三维：1=季节性，2=趋势性，3=残差
    
    % 对每个特征进行分解
    for dim = 1:train_dim
        % 获取当前特征数据
        current_data = U_.u_train(:, dim);
        
        % 检查数据长度是否足够进行分解
        if length(current_data) < season_length * 2
            warning('训练数据长度不足，无法进行分解。使用原始数据。');
            U.u_train(:, dim, 1) = zeros(train_size, 1); % 季节性分量为0
            U.u_train(:, dim, 2) = current_data; % 所有数据放入趋势分量
            U.u_train(:, dim, 3) = zeros(train_size, 1); % 残差分量为0
        else
            % 使用自定义方法进行分解
            [trend, seasonal, remainder] = custom_decompose(current_data, season_length);
            
            % 将分解结果存储到U结构体中
            U.u_train(:, dim, 1) = seasonal; % 季节性分量
            U.u_train(:, dim, 2) = trend;    % 趋势分量
            U.u_train(:, dim, 3) = remainder; % 残差分量
        end
    end
end

% 处理测试数据
if ~isempty(U_.u_test)
    test_size = size(U_.u_test, 1);
    test_dim = size(U_.u_test, 2);
    
    % 初始化分解后的测试数据结构
    U.u_test = zeros(test_size, test_dim, 3); % 第三维：1=季节性，2=趋势性，3=残差
    
    % 对每个特征进行分解
    for dim = 1:test_dim
        % 获取当前特征数据
        current_data = U_.u_test(:, dim);
        
        % 检查数据长度是否足够进行分解
        if length(current_data) < season_length * 2
            warning('测试数据长度不足，无法进行分解。使用原始数据。');
            U.u_test(:, dim, 1) = zeros(test_size, 1); % 季节性分量为0
            U.u_test(:, dim, 2) = current_data; % 所有数据放入趋势分量
            U.u_test(:, dim, 3) = zeros(test_size, 1); % 残差分量为0
        else
            % 使用自定义方法进行分解
            [trend, seasonal, remainder] = custom_decompose(current_data, season_length);
            
            % 将分解结果存储到U结构体中
            U.u_test(:, dim, 1) = seasonal; % 季节性分量
            U.u_test(:, dim, 2) = trend;    % 趋势分量
            U.u_test(:, dim, 3) = remainder; % 残差分量
        end
    end
end

% 保持y_train和y_test不变，因为只对特征进行分解，不对目标变量进行分解
end

function [trend, seasonal, remainder] = custom_decompose(data, season_length)
    % 1. 初始化
    n = length(data);
    trend = zeros(n, 1);
    seasonal = zeros(n, 1);
    remainder = zeros(n, 1);
    
    % 处理无效值
    data_cleaned = data;
    invalid_idx = isnan(data) | isinf(data);
    if any(invalid_idx)
        data_mean = mean(data(~invalid_idx));
        data_cleaned(invalid_idx) = data_mean;
    end
    
    % 2. 提取趋势 - 使用移动平均
    if n >= season_length * 2
        k = floor(season_length / 2) * 2 + 1; % 确保k是奇数
        trend_filter = ones(k, 1) / k;
        trend_padded = [data_cleaned(1)*ones(k-1,1); data_cleaned; data_cleaned(end)*ones(k-1,1)];
        trend_filtered = conv(trend_padded, trend_filter, 'valid');
        
        % 确保长度匹配
        if length(trend_filtered) >= n
            trend = trend_filtered(1:n);
        else
            trend(1:length(trend_filtered)) = trend_filtered;
            trend(length(trend_filtered)+1:end) = trend_filtered(end);
        end
    else
        % 数据太短，使用简单线性趋势
        x = (1:n)';
        coeffs = polyfit(x, data_cleaned, 1);
        trend = polyval(coeffs, x);
    end
    
    % 处理趋势中的无效值
    trend_invalid = isnan(trend) | isinf(trend);
    if any(trend_invalid)
        if sum(~trend_invalid) > 0
            valid_trend_mean = mean(trend(~trend_invalid));
            trend(trend_invalid) = valid_trend_mean;
        else
            trend = zeros(size(trend));
        end
    end
    
    % 3. 提取季节性 - 使用季节平均
    % 去除趋势
    detrended = data_cleaned - trend;
    
    % 如果数据长度足够长，提取季节性成分
    if n >= 2 * season_length
        % 创建季节性索引
        season_idx = mod(0:n-1, season_length)' + 1;
        
        % 对每个季节位置计算平均值
        seasonal_means = zeros(season_length, 1);
        for i = 1:season_length
            pos_values = detrended(season_idx == i);
            if ~isempty(pos_values)
                seasonal_means(i) = mean(pos_values, 'omitnan');
            end
        end
        
        % 确保季节成分和为零
        seasonal_means = seasonal_means - mean(seasonal_means, 'omitnan');
        
        % 构建完整的季节性成分
        seasonal = seasonal_means(season_idx);
    end
    
    % 处理季节性成分中的无效值
    seasonal_invalid = isnan(seasonal) | isinf(seasonal);
    if any(seasonal_invalid)
        seasonal(seasonal_invalid) = 0;
    end
    
    % 4. 计算余项
    remainder = data - trend - seasonal;
    
    % 处理余项中的无效值
    remainder_invalid = isnan(remainder) | isinf(remainder);
    if any(remainder_invalid)
        remainder(remainder_invalid) = 0;
    end
end
