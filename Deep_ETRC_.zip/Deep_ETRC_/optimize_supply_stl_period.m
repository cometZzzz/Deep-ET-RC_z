% 脚本用途：对“供给（Supply）”数据进行STL分解周期窗口候选 [12,24,48,72,168,336] 的批量评估与可视化，输出期刊风格图与分析说明
% 简介：统一学术排版（tiledlayout、紧凑留白、300DPI），文件名包含参数但图内不显示参数；英文标题保留 Times New Roman
function optimize_supply_stl_period()
    % STL周期窗口优化脚本 - 专门优化供给数据
    % 测试不同的周期参数，生成结果图并分析最佳参数
    
    fprintf('=== 供给数据STL周期窗口优化 ===\n');
    
    % 超参数设置
    data_file = 'D:\eqrthquake\太阳能发电供需预测\代码\Deep_ER-RC_exp\merged_data.csv';
    output_dir = 'results\stl_optimization';
    
    % 确保输出目录存在
    if ~exist(output_dir, 'dir')
        mkdir(output_dir);
    end
    
    % 测试的周期窗口参数（小时为单位）
    % 考虑太阳能发电的特性：日周期(24h)、周周期(168h)、半月(336h)等
    period_candidates = [12, 24, 48, 72, 168, 336];
    
    % 图表设置
    fig_width = 1200;
    fig_height = 900;
    dpi = 300;
    
    % 加载和预处理数据
    fprintf('加载数据...\n');
    data = readtable(data_file);

    % 统一目标列命名，避免混淆（14列为供给，15列为消耗）
    if any(strcmp(data.Properties.VariableNames, 'target_0')) && any(strcmp(data.Properties.VariableNames, 'target_1'))
        data = renamevars(data, {'target_0','target_1'}, {'supply','demand'});
    end
    
    % 转换日期时间
    data.datetime = datetime(data.datetime, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
    
    % 筛选时间范围：2021/10/1 到 2022/10/1
    start_date = datetime(2021, 10, 1);
    end_date = datetime(2022, 10, 1);
    filtered_data = data(data.datetime >= start_date & data.datetime < end_date, :);
    
    fprintf('数据加载完成。筛选记录数: %d\n', height(filtered_data));
    fprintf('时间范围: %s 到 %s\n', datestr(start_date), datestr(end_date));
    
    % 提取供给数据
    supply_data = filtered_data.supply;  % 供给数据（原target_0）
    time_vector = filtered_data.datetime;
    
    % 存储分析结果
    analysis_results = struct();
    
    % 对每个周期参数进行STL分解
    for i = 1:length(period_candidates)
        period = period_candidates(i);
        fprintf('\n--- 测试周期窗口: %d 小时 ---\n', period);
        
        % 执行STL分解
        [trend, seasonal, remainder] = perform_stl_decomposition(supply_data, period);
        
        % 计算分析指标
        metrics = calculate_stl_metrics(supply_data, trend, seasonal, remainder);
        
        % 存储结果
        analysis_results(i).period = period;
        analysis_results(i).trend = trend;
        analysis_results(i).seasonal = seasonal;
        analysis_results(i).remainder = remainder;
        analysis_results(i).metrics = metrics;
        
        % 生成并保存可视化图表
        filename = sprintf('supply_stl_period_%dh.png', period);
        create_stl_comparison_plot(time_vector, supply_data, trend, seasonal, remainder, ...
                                 period, output_dir, filename, fig_width, fig_height, dpi);
        
        % 打印分析结果
        print_stl_analysis(period, metrics);

        % 保存本周期的分析解释到文本文件（参数仅在文件名中体现）
        analysis_path = fullfile(output_dir, sprintf('supply_stl_period_%dh_analysis.txt', period));
        fid = fopen(analysis_path, 'w');
        if fid ~= -1
            fprintf(fid, '分析对象: 供给(Supply)\n');
            fprintf(fid, '周期窗口: %dh\n', period);
            fprintf(fid, '时间范围: %s 到 %s\n', datestr(min(time_vector)), datestr(max(time_vector)));
            fprintf(fid, '\n[评估指标]\n');
            fprintf(fid, '原始数据 - 均值: %.2f, 标准差: %.2f\n', metrics.original_mean, metrics.original_std);
            fprintf(fid, '趋势组件 - 方差解释: %.2f%%\n', metrics.trend_var_explained);
            fprintf(fid, '季节组件 - 方差解释: %.2f%%\n', metrics.seasonal_var_explained);
            fprintf(fid, '残差组件 - 方差解释: %.2f%%\n', metrics.remainder_var_explained);
            fprintf(fid, '季节性强度: %.3f\n', metrics.seasonal_strength);
            fprintf(fid, '趋势强度: %.3f\n', metrics.trend_strength);
            fprintf(fid, '残差平滑度: %.2f\n', metrics.remainder_smoothness);
            fprintf(fid, '重构误差: %.4f\n', metrics.reconstruction_error);
            
            % 简要建议（根据指标构造综合评分）
            score = metrics.seasonal_strength * 0.5 + metrics.trend_strength * 0.3 + (1/(1+metrics.remainder_smoothness)) * 0.2;
            fprintf(fid, '\n[综合评价]\n');
            fprintf(fid, '综合评分: %.3f\n', score);
            if score > 0.7
                fprintf(fid, '建议: 强烈推荐该周期，季节性与趋势表现稳定，残差较平稳。\n');
            elseif score > 0.5
                fprintf(fid, '建议: 推荐该周期，整体表现良好，可用于后续建模。\n');
            elseif score > 0.3
                fprintf(fid, '建议: 可考虑该周期，需结合业务场景进一步验证。\n');
            else
                fprintf(fid, '建议: 不推荐该周期，残差或解释度指标不理想。\n');
            end
            fclose(fid);
            fprintf('分析解释已保存: %s\n', analysis_path);
        else
            fprintf('警告: 无法写入分析解释文件: %s\n', analysis_path);
        end
    end
    
    % 生成对比分析报告
    generate_comparison_report(analysis_results, output_dir);
    
    fprintf('\n=== STL周期窗口优化完成 ===\n');
    fprintf('所有结果图表已保存到: %s\n', output_dir);
    fprintf('请查看生成的图表和分析报告来选择最佳周期参数。\n');
end

function [trend, seasonal, remainder] = perform_stl_decomposition(data, period)
    % 执行STL分解 - 使用简化的高性能分解函数
    try
        [trend, seasonal, remainder] = stl_decompose_simple(data, period);
    catch ME
        fprintf('STL分解失败 (周期=%d): %s\n', period, ME.message);
        % 如果失败，返回简单的分解
        trend = movmean(data, min(period, length(data)/4));
        seasonal = zeros(size(data));
        remainder = data - trend;
    end
end

function metrics = calculate_stl_metrics(original, trend, seasonal, remainder)
    % 计算STL分解的评估指标
    
    % 基本统计
    metrics.original_mean = mean(original);
    metrics.original_std = std(original);
    metrics.original_range = [min(original), max(original)];
    
    metrics.trend_mean = mean(trend);
    metrics.trend_std = std(trend);
    metrics.trend_range = [min(trend), max(trend)];
    
    metrics.seasonal_mean = mean(seasonal);
    metrics.seasonal_std = std(seasonal);
    metrics.seasonal_range = [min(seasonal), max(seasonal)];
    
    metrics.remainder_mean = mean(remainder);
    metrics.remainder_std = std(remainder);
    metrics.remainder_range = [min(remainder), max(remainder)];
    
    % 方差解释比例
    total_var = var(original);
    metrics.trend_var_explained = var(trend) / total_var * 100;
    metrics.seasonal_var_explained = var(seasonal) / total_var * 100;
    metrics.remainder_var_explained = var(remainder) / total_var * 100;
    
    % 季节性强度指标
    metrics.seasonal_strength = var(seasonal) / (var(seasonal) + var(remainder));
    
    % 趋势强度指标
    metrics.trend_strength = var(trend) / (var(trend) + var(remainder));
    
    % 残差的平滑度（越小越好）
    metrics.remainder_smoothness = mean(abs(diff(remainder)));
    
    % 重构误差
    reconstructed = trend + seasonal + remainder;
    metrics.reconstruction_error = mean(abs(original - reconstructed));
end

function create_stl_comparison_plot(time_vector, original, trend, seasonal, remainder, period, output_dir, filename, fig_width, fig_height, dpi)
    % 创建期刊风格STL分解对比图（tiledlayout、紧凑留白、300DPI）
    
    % 学术配色 - 统一蓝色主题
    colors = struct();
    colors.base = [0.2, 0.4, 0.8];
    colors.grid = [0.9, 0.9, 0.9];
    
    % 创建图形
    fig = figure('Position', [100, 100, fig_width, fig_height], 'Color', 'white', 'PaperPositionMode', 'auto');
    tl = tiledlayout(fig,4,1,'TileSpacing','compact','Padding','compact');
    sgtitle(tl,'STL Decomposition - Supply Data','FontSize',13,'FontWeight','bold','FontName','Times New Roman');
    
    % 原始数据
    ax1 = nexttile(tl,1);
    plot(ax1, time_vector, original, 'Color', colors.base, 'LineWidth', 1.2);
    title(ax1,'Original Supply Data','FontSize',11,'FontWeight','bold','FontName','Times New Roman');
    ylabel(ax1,'Supply (kWh)','FontSize',10,'FontName','Times New Roman');
    grid(ax1,'on'); grid(ax1,'minor'); box(ax1,'on'); set(ax1,'GridColor',colors.grid,'MinorGridColor',colors.grid,'FontSize',9,'FontName','Times New Roman');
    
    % 趋势
    ax2 = nexttile(tl,2);
    plot(ax2, time_vector, trend, 'Color', colors.base, 'LineWidth', 1.5);
    title(ax2,'Trend Component','FontSize',11,'FontWeight','bold','FontName','Times New Roman');
    ylabel(ax2,'Trend (kWh)','FontSize',10,'FontName','Times New Roman');
    grid(ax2,'on'); grid(ax2,'minor'); box(ax2,'on'); set(ax2,'GridColor',colors.grid,'MinorGridColor',colors.grid,'FontSize',9,'FontName','Times New Roman');
    
    % 季节性
    ax3 = nexttile(tl,3);
    plot(ax3, time_vector, seasonal, 'Color', colors.base, 'LineWidth', 1.2);
    title(ax3,'Seasonal Component','FontSize',11,'FontWeight','bold','FontName','Times New Roman');
    ylabel(ax3,'Seasonal (kWh)','FontSize',10,'FontName','Times New Roman');
    grid(ax3,'on'); grid(ax3,'minor'); box(ax3,'on'); set(ax3,'GridColor',colors.grid,'MinorGridColor',colors.grid,'FontSize',9,'FontName','Times New Roman');
    
    % 残差
    ax4 = nexttile(tl,4);
    plot(ax4, time_vector, remainder, 'Color', colors.base, 'LineWidth', 1.0);
    title(ax4,'Remainder Component','FontSize',11,'FontWeight','bold','FontName','Times New Roman');
    ylabel(ax4,'Remainder (kWh)','FontSize',10,'FontName','Times New Roman');
    xlabel(ax4,'Time','FontSize',10,'FontName','Times New Roman');
    grid(ax4,'on'); grid(ax4,'minor'); box(ax4,'on'); set(ax4,'GridColor',colors.grid,'MinorGridColor',colors.grid,'FontSize',9,'FontName','Times New Roman');
    
    % 同步x轴并仅底部显示刻度标签
    linkaxes([ax1,ax2,ax3,ax4],'x');
    set(ax1,'XTickLabel',[]); set(ax2,'XTickLabel',[]); set(ax3,'XTickLabel',[]);
    xtickangle(ax4,45);
    try
        startT = time_vector(1); endT = time_vector(end);
        month_ticks = startT:calmonths(1):endT;
        set(ax4,'XTick',month_ticks);
        ax4.XTickLabel = cellstr(datestr(month_ticks,'mmm yyyy'));
    catch
        % 兼容非datetime
    end
    
    % 保存图形
    output_path = fullfile(output_dir, filename);
    print(fig, output_path, '-dpng', sprintf('-r%d', dpi));
    fprintf('图表已保存: %s\n', output_path);
end

function print_stl_analysis(period, metrics)
    % 打印STL分析结果
    fprintf('周期 %d 小时 - 分析结果:\n', period);
    fprintf('  原始数据 - 均值: %.2f, 标准差: %.2f\n', metrics.original_mean, metrics.original_std);
    fprintf('  趋势组件 - 方差解释: %.2f%%\n', metrics.trend_var_explained);
    fprintf('  季节组件 - 方差解释: %.2f%%\n', metrics.seasonal_var_explained);
    fprintf('  残差组件 - 方差解释: %.2f%%\n', metrics.remainder_var_explained);
    fprintf('  季节性强度: %.3f\n', metrics.seasonal_strength);
    fprintf('  趋势强度: %.3f\n', metrics.trend_strength);
    fprintf('  残差平滑度: %.2f\n', metrics.remainder_smoothness);
    fprintf('  重构误差: %.4f\n', metrics.reconstruction_error);
end

function generate_comparison_report(analysis_results, output_dir)
    % 生成对比分析报告
    fprintf('\n=== STL周期窗口对比分析报告 ===\n');
    
    % 创建对比表格
    periods = [analysis_results.period];
    trend_var = [analysis_results.metrics];
    trend_var = [trend_var.trend_var_explained];
    seasonal_var = [analysis_results.metrics];
    seasonal_var = [seasonal_var.seasonal_var_explained];
    remainder_var = [analysis_results.metrics];
    remainder_var = [remainder_var.remainder_var_explained];
    seasonal_strength = [analysis_results.metrics];
    seasonal_strength = [seasonal_strength.seasonal_strength];
    trend_strength = [analysis_results.metrics];
    trend_strength = [trend_strength.trend_strength];
    remainder_smoothness = [analysis_results.metrics];
    remainder_smoothness = [remainder_smoothness.remainder_smoothness];
    
    % 打印对比表格
    fprintf('\n周期(h) | 趋势解释%% | 季节解释%% | 残差解释%% | 季节强度 | 趋势强度 | 残差平滑度\n');
    fprintf('--------|----------|----------|----------|----------|----------|----------\n');
    for i = 1:length(periods)
        fprintf('%7d | %8.2f | %8.2f | %8.2f | %8.3f | %8.3f | %9.2f\n', ...
                periods(i), trend_var(i), seasonal_var(i), remainder_var(i), ...
                seasonal_strength(i), trend_strength(i), remainder_smoothness(i));
    end
    
    % 推荐最佳参数
    fprintf('\n=== 参数推荐分析 ===\n');
    
    % 找到季节性强度最高的参数
    [max_seasonal_strength, max_seasonal_idx] = max(seasonal_strength);
    fprintf('最强季节性: %d小时 (季节强度: %.3f)\n', periods(max_seasonal_idx), max_seasonal_strength);
    
    % 找到残差最平滑的参数
    [min_remainder_smoothness, min_remainder_idx] = min(remainder_smoothness);
    fprintf('最平滑残差: %d小时 (平滑度: %.2f)\n', periods(min_remainder_idx), min_remainder_smoothness);
    
    % 找到季节性解释方差最高的参数
    [max_seasonal_var, max_seasonal_var_idx] = max(seasonal_var);
    fprintf('最强季节解释: %d小时 (解释方差: %.2f%%)\n', periods(max_seasonal_var_idx), max_seasonal_var);
    
    % 综合评分（季节性强度 + 季节解释方差 - 残差平滑度的标准化）
    normalized_seasonal = (seasonal_strength - min(seasonal_strength)) / (max(seasonal_strength) - min(seasonal_strength));
    normalized_seasonal_var = (seasonal_var - min(seasonal_var)) / (max(seasonal_var) - min(seasonal_var));
    normalized_smoothness = 1 - (remainder_smoothness - min(remainder_smoothness)) / (max(remainder_smoothness) - min(remainder_smoothness));
    
    composite_score = normalized_seasonal + normalized_seasonal_var + normalized_smoothness;
    [max_score, best_idx] = max(composite_score);
    
    fprintf('\n*** 推荐最佳周期参数: %d小时 ***\n', periods(best_idx));
    fprintf('综合评分: %.3f (季节性强度: %.3f, 季节解释: %.2f%%, 残差平滑度: %.2f)\n', ...
            max_score, seasonal_strength(best_idx), seasonal_var(best_idx), remainder_smoothness(best_idx));
end