%% 稳定版LSTM对比实验 - 太阳能发电供需预测
% 作者: AI Assistant
% 日期: 2024
% 描述: 使用稳定的LSTM模型进行单步预测，与Deep ET-RC模型对比

clear; clc; close all;

%% 实验配置
fprintf('=== 稳定版LSTM对比实验开始 ===\n');
fprintf('时间: %s\n', datestr(now));

% 数据配置
data_file = 'merged_data.csv';
train_start = '2021-10-01 00:00:00';
train_end = '2022-10-01 23:00:00';
test_start = '2022-10-02 00:00:00';
test_end = '2023-06-01 23:00:00';

% 保守的LSTM配置
lstm_config = struct();
lstm_config.hidden_units = 16;          % 更少的隐藏单元
lstm_config.sequence_length = 3;        % 更短的序列长度
lstm_config.learning_rate = 0.001;      % 更小的学习率
lstm_config.max_epochs = 10;            % 更少的训练轮数
lstm_config.mini_batch_size = 128;      % 更大的批次大小

% 结果保存配置
results_dir = 'results\模型预测结果\LSTM';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

%% 数据加载和预处理
fprintf('\n--- 数据加载和预处理 ---\n');

% 读取CSV数据
fprintf('正在读取数据文件: %s\n', data_file);
data_table = readtable(data_file);
fprintf('数据维度: %d行 x %d列\n', size(data_table, 1), size(data_table, 2));

% 转换时间列
data_table.datetime = datetime(data_table.datetime, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');

% 时间范围过滤
train_start_dt = datetime(train_start, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
train_end_dt = datetime(train_end, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
test_start_dt = datetime(test_start, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
test_end_dt = datetime(test_end, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');

% 分割训练和测试数据
train_mask = (data_table.datetime >= train_start_dt) & (data_table.datetime <= train_end_dt);
test_mask = (data_table.datetime >= test_start_dt) & (data_table.datetime <= test_end_dt);

train_data_table = data_table(train_mask, :);
test_data_table = data_table(test_mask, :);

fprintf('训练集时间范围: %s 到 %s (%d条记录)\n', ...
    datestr(train_start_dt), datestr(train_end_dt), sum(train_mask));
fprintf('测试集时间范围: %s 到 %s (%d条记录)\n', ...
    datestr(test_start_dt), datestr(test_end_dt), sum(test_mask));

% 提取特征和目标变量（排除时间列）
train_data = table2array(train_data_table(:, 2:end));  % 排除datetime列
test_data = table2array(test_data_table(:, 2:end));

% 分离特征和目标
X_train = train_data(:, 1:end-2);  % 前12列为特征
y_supply_train = train_data(:, end-1);  % target_0 (供给)
y_demand_train = train_data(:, end);    % target_1 (消耗)

X_test = test_data(:, 1:end-2);
y_supply_test = test_data(:, end-1);
y_demand_test = test_data(:, end);

fprintf('特征维度: %d\n', size(X_train, 2));
fprintf('训练样本数: %d\n', size(X_train, 1));
fprintf('测试样本数: %d\n', size(X_test, 1));

%% 数据清理和稳定化
fprintf('\n--- 数据清理和稳定化 ---\n');

% 检查并处理异常值
fprintf('检查数据中的异常值...\n');

% 移除NaN和Inf值
valid_train_idx = ~any(isnan(X_train), 2) & ~any(isinf(X_train), 2) & ...
                  ~isnan(y_supply_train) & ~isinf(y_supply_train) & ...
                  ~isnan(y_demand_train) & ~isinf(y_demand_train);

valid_test_idx = ~any(isnan(X_test), 2) & ~any(isinf(X_test), 2) & ...
                 ~isnan(y_supply_test) & ~isinf(y_supply_test) & ...
                 ~isnan(y_demand_test) & ~isinf(y_demand_test);

X_train = X_train(valid_train_idx, :);
y_supply_train = y_supply_train(valid_train_idx);
y_demand_train = y_demand_train(valid_train_idx);

X_test = X_test(valid_test_idx, :);
y_supply_test = y_supply_test(valid_test_idx);
y_demand_test = y_demand_test(valid_test_idx);

fprintf('清理后训练样本数: %d\n', size(X_train, 1));
fprintf('清理后测试样本数: %d\n', size(X_test, 1));

% 使用稳健的标准化方法
fprintf('使用稳健标准化...\n');

% 计算中位数和MAD（中位数绝对偏差）进行稳健标准化
X_median = median(X_train);
X_mad = mad(X_train, 1);
X_mad(X_mad == 0) = 1; % 防止除零

y_supply_median = median(y_supply_train);
y_supply_mad = mad(y_supply_train, 1);
if y_supply_mad == 0
    y_supply_mad = 1;
end

y_demand_median = median(y_demand_train);
y_demand_mad = mad(y_demand_train, 1);
if y_demand_mad == 0
    y_demand_mad = 1;
end

% 稳健标准化
X_train_norm = (X_train - X_median) ./ X_mad;
X_test_norm = (X_test - X_median) ./ X_mad;

y_supply_train_norm = (y_supply_train - y_supply_median) / y_supply_mad;
y_demand_train_norm = (y_demand_train - y_demand_median) / y_demand_mad;

% 限制标准化后的值在合理范围内
X_train_norm = max(-5, min(5, X_train_norm));
X_test_norm = max(-5, min(5, X_test_norm));
y_supply_train_norm = max(-5, min(5, y_supply_train_norm));
y_demand_train_norm = max(-5, min(5, y_demand_train_norm));

fprintf('稳健标准化完成\n');

%% 准备LSTM序列数据
fprintf('\n--- 准备LSTM序列数据 ---\n');

seq_len = lstm_config.sequence_length;
n_features = size(X_train_norm, 2);

% 创建训练序列
n_train_seq = size(X_train_norm, 1) - seq_len;
X_train_seq = zeros(n_train_seq, seq_len, n_features);
y_supply_train_seq = zeros(n_train_seq, 1);
y_demand_train_seq = zeros(n_train_seq, 1);

for i = 1:n_train_seq
    X_train_seq(i, :, :) = X_train_norm(i:i+seq_len-1, :);
    y_supply_train_seq(i) = y_supply_train_norm(i + seq_len);
    y_demand_train_seq(i) = y_demand_train_norm(i + seq_len);
end

% 创建测试序列
n_test_seq = size(X_test_norm, 1) - seq_len;
X_test_seq = zeros(n_test_seq, seq_len, n_features);

for i = 1:n_test_seq
    X_test_seq(i, :, :) = X_test_norm(i:i+seq_len-1, :);
end

fprintf('序列数据准备完成\n');
fprintf('训练序列数: %d\n', n_train_seq);
fprintf('测试序列数: %d\n', n_test_seq);

%% 转换为cell格式
fprintf('\n--- 转换数据格式 ---\n');

X_train_cell = cell(n_train_seq, 1);
X_test_cell = cell(n_test_seq, 1);

for i = 1:n_train_seq
    X_train_cell{i} = squeeze(X_train_seq(i, :, :))';
end

for i = 1:n_test_seq
    X_test_cell{i} = squeeze(X_test_seq(i, :, :))';
end

fprintf('数据格式转换完成\n');

%% 定义稳定的LSTM网络
fprintf('\n--- 定义LSTM网络结构 ---\n');

layers = [
    sequenceInputLayer(n_features, 'Name', 'input')
    lstmLayer(lstm_config.hidden_units, 'OutputMode', 'last', 'Name', 'lstm1')
    dropoutLayer(0.2, 'Name', 'dropout')
    fullyConnectedLayer(1, 'Name', 'fc')
    regressionLayer('Name', 'output')
];

% 稳定的训练选项
options = trainingOptions('adam', ...
    'MaxEpochs', lstm_config.max_epochs, ...
    'MiniBatchSize', lstm_config.mini_batch_size, ...
    'InitialLearnRate', lstm_config.learning_rate, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.9, ...
    'LearnRateDropPeriod', 3, ...
    'GradientThreshold', 1, ...
    'Verbose', false, ...
    'Plots', 'none', ...
    'ValidationFrequency', 50);

fprintf('网络结构定义完成\n');

%% 训练LSTM模型
fprintf('\n--- 训练LSTM模型 ---\n');

% 训练供给预测模型
fprintf('训练供给预测LSTM模型...\n');
tic;
try
    lstm_supply_net = trainNetwork(X_train_cell, y_supply_train_seq, layers, options);
    supply_train_time = toc;
    fprintf('供给模型训练完成，用时: %.2f秒\n', supply_train_time);
    supply_train_success = true;
catch ME
    fprintf('供给模型训练失败: %s\n', ME.message);
    supply_train_success = false;
end

% 训练消耗预测模型
fprintf('训练消耗预测LSTM模型...\n');
tic;
try
    lstm_demand_net = trainNetwork(X_train_cell, y_demand_train_seq, layers, options);
    demand_train_time = toc;
    fprintf('消耗模型训练完成，用时: %.2f秒\n', demand_train_time);
    demand_train_success = true;
catch ME
    fprintf('消耗模型训练失败: %s\n', ME.message);
    demand_train_success = false;
end

%% 模型预测和评估
if supply_train_success && demand_train_success
    fprintf('\n--- 模型预测 ---\n');
    
    % 供给预测
    y_supply_pred_norm = predict(lstm_supply_net, X_test_cell);
    y_supply_pred = y_supply_pred_norm * y_supply_mad + y_supply_median;
    y_supply_actual = y_supply_test((seq_len+1):end);
    
    % 消耗预测
    y_demand_pred_norm = predict(lstm_demand_net, X_test_cell);
    y_demand_pred = y_demand_pred_norm * y_demand_mad + y_demand_median;
    y_demand_actual = y_demand_test((seq_len+1):end);
    
    fprintf('预测完成\n');
    
    %% 计算性能指标
    fprintf('\n--- 计算性能指标 ---\n');
    
    % 供给预测性能
    supply_mse = mean((y_supply_pred - y_supply_actual).^2);
    supply_rmse = sqrt(supply_mse);
    supply_mae = mean(abs(y_supply_pred - y_supply_actual));
    supply_r2 = 1 - sum((y_supply_actual - y_supply_pred).^2) / sum((y_supply_actual - mean(y_supply_actual)).^2);
    
    % 消耗预测性能
    demand_mse = mean((y_demand_pred - y_demand_actual).^2);
    demand_rmse = sqrt(demand_mse);
    demand_mae = mean(abs(y_demand_pred - y_demand_actual));
    demand_r2 = 1 - sum((y_demand_actual - y_demand_pred).^2) / sum((y_demand_actual - mean(y_demand_actual)).^2);
    
    % 供需关系预测性能
    balance_pred = y_supply_pred - y_demand_pred;
    balance_actual = y_supply_actual - y_demand_actual;
    balance_mse = mean((balance_pred - balance_actual).^2);
    balance_rmse = sqrt(balance_mse);
    balance_mae = mean(abs(balance_pred - balance_actual));
    balance_r2 = 1 - sum((balance_actual - balance_pred).^2) / sum((balance_actual - mean(balance_actual)).^2);
    
    % 显示结果
    fprintf('\n=== 稳定LSTM模型性能结果 ===\n');
    fprintf('供给预测:\n');
    fprintf('  RMSE: %.2f\n', supply_rmse);
    fprintf('  MAE:  %.2f\n', supply_mae);
    fprintf('  R²:   %.4f\n', supply_r2);
    
    fprintf('\n消耗预测:\n');
    fprintf('  RMSE: %.2f\n', demand_rmse);
    fprintf('  MAE:  %.2f\n', demand_mae);
    fprintf('  R²:   %.4f\n', demand_r2);
    
    fprintf('\n供需关系预测:\n');
    fprintf('  RMSE: %.2f\n', balance_rmse);
    fprintf('  MAE:  %.2f\n', balance_mae);
    fprintf('  R²:   %.4f\n', balance_r2);
    
    %% 保存结果
    fprintf('\n--- 保存结果 ---\n');
    
    % 保存预测结果矩阵
    results = struct();
    results.y_supply_pred = y_supply_pred;
    results.y_supply_actual = y_supply_actual;
    results.y_demand_pred = y_demand_pred;
    results.y_demand_actual = y_demand_actual;
    results.balance_pred = balance_pred;
    results.balance_actual = balance_actual;
    
    % 保存性能指标
    results.performance = struct();
    results.performance.supply_rmse = supply_rmse;
    results.performance.supply_mae = supply_mae;
    results.performance.supply_r2 = supply_r2;
    results.performance.demand_rmse = demand_rmse;
    results.performance.demand_mae = demand_mae;
    results.performance.demand_r2 = demand_r2;
    results.performance.balance_rmse = balance_rmse;
    results.performance.balance_mae = balance_mae;
    results.performance.balance_r2 = balance_r2;
    
    % 保存配置信息
    results.config = lstm_config;
    results.data_config = struct('train_start', train_start, 'train_end', train_end, ...
                                'test_start', test_start, 'test_end', test_end);
    
    % 保存到.mat文件
    save(fullfile(results_dir, 'robust_lstm_results.mat'), 'results');
    
    % 保存到CSV文件
    performance_table = table(supply_rmse, supply_mae, supply_r2, ...
                             demand_rmse, demand_mae, demand_r2, ...
                             balance_rmse, balance_mae, balance_r2, ...
                             'VariableNames', {'Supply_RMSE', 'Supply_MAE', 'Supply_R2', ...
                                              'Demand_RMSE', 'Demand_MAE', 'Demand_R2', ...
                                              'Balance_RMSE', 'Balance_MAE', 'Balance_R2'});
    writetable(performance_table, fullfile(results_dir, 'robust_lstm_performance.csv'));
    
    % 保存预测结果到CSV
    prediction_table = table(y_supply_actual, y_supply_pred, y_demand_actual, y_demand_pred, ...
                            balance_actual, balance_pred, ...
                            'VariableNames', {'Supply_Actual', 'Supply_Pred', 'Demand_Actual', ...
                                             'Demand_Pred', 'Balance_Actual', 'Balance_Pred'});
    writetable(prediction_table, fullfile(results_dir, 'robust_lstm_predictions.csv'));
    
    fprintf('结果已保存到: %s\n', results_dir);
    
    %% 绘制预测vs真实图
    fprintf('\n--- 生成可视化图表 ---\n');
    
    % 创建时间轴（用于绘图）
    time_axis = 1:length(y_supply_actual);
    
    % 预测对比图
    figure('Position', [100, 100, 1200, 400]);
    
    subplot(1,3,1);
    plot(time_axis, y_supply_actual, 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
    hold on;
    plot(time_axis, y_supply_pred, 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
    xlabel('时间步');
    ylabel('供给量');
    title(sprintf('稳定LSTM供给预测 (RMSE=%.2f, MAE=%.2f)', supply_rmse, supply_mae));
    legend('Location', 'best');
    grid on;
    
    subplot(1,3,2);
    plot(time_axis, y_demand_actual, 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
    hold on;
    plot(time_axis, y_demand_pred, 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
    xlabel('时间步');
    ylabel('消耗量');
    title(sprintf('稳定LSTM消耗预测 (RMSE=%.2f, MAE=%.2f)', demand_rmse, demand_mae));
    legend('Location', 'best');
    grid on;
    
    subplot(1,3,3);
    plot(time_axis, balance_actual, 'b-', 'LineWidth', 1.5, 'DisplayName', '真实值');
    hold on;
    plot(time_axis, balance_pred, 'r--', 'LineWidth', 1.5, 'DisplayName', '预测值');
    xlabel('时间步');
    ylabel('供需差值');
    title(sprintf('稳定LSTM供需关系预测 (RMSE=%.2f, MAE=%.2f)', balance_rmse, balance_mae));
    legend('Location', 'best');
    grid on;
    
    % 保存图片
    saveas(gcf, fullfile(results_dir, 'robust_lstm_prediction_comparison.png'));
    saveas(gcf, fullfile(results_dir, 'robust_lstm_prediction_comparison.fig'));
    
    % 散点图对比
    figure('Position', [100, 600, 1200, 400]);
    
    subplot(1,3,1);
    scatter(y_supply_actual, y_supply_pred, 'filled');
    hold on;
    plot([min(y_supply_actual), max(y_supply_actual)], [min(y_supply_actual), max(y_supply_actual)], 'r--', 'LineWidth', 2);
    xlabel('真实供给量');
    ylabel('预测供给量');
    title(sprintf('供给预测散点图 (R²=%.4f)', supply_r2));
    grid on;
    
    subplot(1,3,2);
    scatter(y_demand_actual, y_demand_pred, 'filled');
    hold on;
    plot([min(y_demand_actual), max(y_demand_actual)], [min(y_demand_actual), max(y_demand_actual)], 'r--', 'LineWidth', 2);
    xlabel('真实消耗量');
    ylabel('预测消耗量');
    title(sprintf('消耗预测散点图 (R²=%.4f)', demand_r2));
    grid on;
    
    subplot(1,3,3);
    scatter(balance_actual, balance_pred, 'filled');
    hold on;
    plot([min(balance_actual), max(balance_actual)], [min(balance_actual), max(balance_actual)], 'r--', 'LineWidth', 2);
    xlabel('真实供需差值');
    ylabel('预测供需差值');
    title(sprintf('供需关系散点图 (R²=%.4f)', balance_r2));
    grid on;
    
    % 保存散点图
    saveas(gcf, fullfile(results_dir, 'robust_lstm_scatter_plots.png'));
    saveas(gcf, fullfile(results_dir, 'robust_lstm_scatter_plots.fig'));
    
    fprintf('可视化图表已保存\n');
    
else
    fprintf('\n模型训练失败，无法进行预测和评估\n');
end

fprintf('\n=== 稳定LSTM对比实验完成 ===\n');