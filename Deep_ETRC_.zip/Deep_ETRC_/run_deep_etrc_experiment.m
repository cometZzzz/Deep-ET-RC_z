function results = run_deep_etrc_experiment(data_config, model_config, stl_config, experiment_config)
%% run_deep_etrc_experiment - Deep ET-RC实验执行函数
% 整合数据加载、STL分解、模型训练和结果保存的完整实验流程
%
% 输入参数:
%   data_config       - 数据配置结构体
%   model_config      - 模型配置结构体
%   stl_config        - STL配置结构体
%   experiment_config - 实验配置结构体
%
% 输出:
%   results - 实验结果结构体

    fprintf('=== 开始Deep ET-RC实验 ===\n');
    experiment_start_time = tic;
    
    %% 1. 数据加载和预处理
    fprintf('\n1. 数据加载和预处理...\n');
    
    % 读取数据
    if ~exist(data_config.data_file, 'file')
        error('数据文件不存在: %s', data_config.data_file);
    end
    
    % 读取CSV文件，包含时间列
    data_table = readtable(data_config.data_file);
    fprintf('数据加载完成，数据形状: %d x %d\n', size(data_table, 1), size(data_table, 2));
    
    % 转换时间列
    data_table.datetime = datetime(data_table.datetime, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
    
    % 根据时间范围分割数据
    train_start = datetime(data_config.train_start, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
    train_end = datetime(data_config.train_end, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
    test_start = datetime(data_config.test_start, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
    test_end = datetime(data_config.test_end, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
    
    % 筛选训练和测试数据
    train_mask = data_table.datetime >= train_start & data_table.datetime <= train_end;
    test_mask = data_table.datetime >= test_start & data_table.datetime <= test_end;
    
    train_data = data_table(train_mask, :);
    test_data = data_table(test_mask, :);
    
    fprintf('训练集时间范围: %s 到 %s (%d 条记录)\n', ...
            datestr(train_start), datestr(train_end), sum(train_mask));
    fprintf('测试集时间范围: %s 到 %s (%d 条记录)\n', ...
            datestr(test_start), datestr(test_end), sum(test_mask));
    
    % 将表格转换为数值矩阵（排除时间列）
    data = [table2array(train_data(:, 2:end)); table2array(test_data(:, 2:end))];
    train_size = size(train_data, 1);
    test_size = size(test_data, 1);
    
    % 提取特征和标签
    feature_cols = data_config.feature_cols;
    supply_col = data_config.supply_col;
    demand_col = data_config.demand_col;
    
    % 初始化结果存储
    max_horizon = data_config.max_horizon;
    supply_predictions = cell(max_horizon, 1);
    demand_predictions = cell(max_horizon, 1);
    balance_predictions = cell(max_horizon, 1);
    supply_actuals = cell(max_horizon, 1);
    demand_actuals = cell(max_horizon, 1);
    balance_actuals = cell(max_horizon, 1);
    performance_metrics = struct('supply_mse', {}, 'supply_rmse', {}, 'supply_mae', {}, 'supply_r2', {}, ...
                                'demand_mse', {}, 'demand_rmse', {}, 'demand_mae', {}, 'demand_r2', {}, ...
                                'balance_mse', {}, 'balance_rmse', {}, 'balance_mae', {}, 'balance_r2', {});
    
    %% 2. 多步预测循环
    fprintf('\n2. 开始多步预测...\n');
    
    for h = 1:max_horizon
        fprintf('\n--- 预测步长 t+%d ---\n', h);
        step_start_time = tic;
        
        % 准备当前步长的数据（包含STL分解）
        [U_supply, U_demand, y_test_supply, y_test_demand] = prepare_horizon_data(...
            data, feature_cols, supply_col, demand_col, h, train_size, test_size);
        
        % 训练供给预测模型
        fprintf('训练供给预测模型...\n');
        supply_results = DeepET_RC(model_config.n_layers, model_config.RC, ...
                                   model_config.ET, U_supply);
        
        % 训练消耗预测模型
        fprintf('训练消耗预测模型...\n');
        demand_results = DeepET_RC(model_config.n_layers, model_config.RC, ...
                                   model_config.ET, U_demand);
        
        % 反标准化预测结果
        [supply_pred_denorm, demand_pred_denorm] = denormalize_predictions(...
            supply_results, demand_results, U_supply, U_demand);
        
        % 计算供需关系
        balance_pred = demand_pred_denorm - supply_pred_denorm;
        balance_actual = y_test_demand - y_test_supply;
        
        % 存储预测结果
        supply_predictions{h} = supply_pred_denorm;
        demand_predictions{h} = demand_pred_denorm;
        balance_predictions{h} = balance_pred;
        supply_actuals{h} = y_test_supply;
        demand_actuals{h} = y_test_demand;
        balance_actuals{h} = balance_actual;
        
        % 计算性能指标
        performance_metrics(h) = calculate_performance_metrics(...
            supply_pred_denorm, demand_pred_denorm, balance_pred, ...
            y_test_supply, y_test_demand, balance_actual);
        
        % 显示当前步长结果
        step_time = toc(step_start_time);
        display_step_results(h, performance_metrics(h), step_time);
    end
    
    %% 3. 结果可视化和保存
    fprintf('\n3. 生成结果可视化...\n');
    
    if experiment_config.save_figures
        visualization_results = generate_visualizations(...
            supply_predictions, demand_predictions, balance_predictions, ...
            supply_actuals, demand_actuals, balance_actuals, ...
            performance_metrics, experiment_config.results_dir);
    end
    
    %% 4. 保存实验结果
    if experiment_config.save_results
        fprintf('保存实验结果...\n');
        save_experiment_results(supply_predictions, demand_predictions, ...
            balance_predictions, supply_actuals, demand_actuals, ...
            balance_actuals, performance_metrics, data_config, ...
            model_config, stl_config, experiment_config);
    end
    
    %% 5. 整理输出结果
    total_time = toc(experiment_start_time);
    
    results = struct();
    results.supply_predictions = supply_predictions;
    results.demand_predictions = demand_predictions;
    results.balance_predictions = balance_predictions;
    results.supply_actuals = supply_actuals;
    results.demand_actuals = demand_actuals;
    results.balance_actuals = balance_actuals;
    results.performance_metrics = performance_metrics;
    results.total_time = total_time;
    results.config = struct('data', data_config, 'model', model_config, ...
                           'stl', stl_config, 'experiment', experiment_config);
    
    fprintf('\n=== 实验完成 ===\n');
    fprintf('总耗时: %.2f 秒\n', total_time);
end

function [U_supply, U_demand, y_test_supply, y_test_demand] = prepare_horizon_data(...
    data, feature_cols, supply_col, demand_col, horizon, train_size, test_size)
%% 准备指定预测步长的数据

    % 准备输入特征和目标值
    X = data(5:end-horizon, :);
    y_supply = data(5+horizon:end, supply_col);
    y_demand = data(5+horizon:end, demand_col);
    
    % 确保数据长度足够
    available_data_length = size(X, 1);
    max_test_size = available_data_length - train_size;
    actual_test_size = min(test_size, max_test_size);
    
    fprintf('可用数据长度: %d, 训练集大小: %d, 请求测试集大小: %d, 实际测试集大小: %d\n', ...
            available_data_length, train_size, test_size, actual_test_size);
    
    % 对供给和需求数据进行STL分解
    supply_data_for_stl = data(5:end-horizon, supply_col);
    demand_data_for_stl = data(5:end-horizon, demand_col);
    
    % 执行STL分解
    [supply_trend, supply_seasonal, supply_remainder] = stl_decompose_1d(supply_data_for_stl, 24);
    [demand_trend, demand_seasonal, demand_remainder] = stl_decompose_1d(demand_data_for_stl, 24);
    
    % 准备供给预测数据 - 气象特征 + 供给STL分量
    X_supply = [X(:, feature_cols), supply_trend, supply_seasonal, supply_remainder];
    
    x_train_supply = X_supply(1:train_size, :);
    y_train_supply = y_supply(1:train_size);
    x_test_supply = X_supply(train_size+1:train_size+actual_test_size, :);
    y_test_supply = y_supply(train_size+1:train_size+actual_test_size);
    
    % 准备消耗预测数据 - 气象特征 + 需求STL分量
    X_demand = [X(:, feature_cols), demand_trend, demand_seasonal, demand_remainder];
    x_train_demand = X_demand(1:train_size, :);
    y_train_demand = y_demand(1:train_size);
    x_test_demand = X_demand(train_size+1:train_size+actual_test_size, :);
    y_test_demand = y_demand(train_size+1:train_size+actual_test_size);
    
    % 数据标准化
    [x_train_supply_norm, x_test_supply_norm, supply_stats] = normalize_data(x_train_supply, x_test_supply);
    [y_train_supply_norm, y_test_supply_norm, ~] = normalize_data(y_train_supply, y_test_supply);
    
    [x_train_demand_norm, x_test_demand_norm, demand_stats] = normalize_data(x_train_demand, x_test_demand);
    [y_train_demand_norm, y_test_demand_norm, ~] = normalize_data(y_train_demand, y_test_demand);
    
    % 构建数据结构
    U_supply = struct();
    U_supply.u_train = x_train_supply_norm;
    U_supply.u_test = x_test_supply_norm;
    U_supply.y_train = y_train_supply_norm;
    U_supply.y_test = y_test_supply_norm;
    U_supply.stats = supply_stats;
    U_supply.y_stats = struct('mean', mean(y_train_supply), 'std', std(y_train_supply));
    
    U_demand = struct();
    U_demand.u_train = x_train_demand_norm;
    U_demand.u_test = x_test_demand_norm;
    U_demand.y_train = y_train_demand_norm;
    U_demand.y_test = y_test_demand_norm;
    U_demand.stats = demand_stats;
    U_demand.y_stats = struct('mean', mean(y_train_demand), 'std', std(y_train_demand));
end

function [data_norm_train, data_norm_test, stats] = normalize_data(data_train, data_test)
%% 数据标准化函数

    stats = struct();
    stats.mean = mean(data_train, 1);
    stats.std = std(data_train, 1);
    stats.std(stats.std == 0) = 1;  % 避免除零
    
    data_norm_train = (data_train - stats.mean) ./ stats.std;
    data_norm_test = (data_test - stats.mean) ./ stats.std;
end

function U_reshaped = reshape_stl_data(U_stl)
%% 重新整理STL分解后的数据
    
    U_reshaped = U_stl;
    
    if size(U_stl.u_train, 3) == 3
        % STL分解后的数据是3维的，需要重新整理为2维
        [n_train, n_feat, n_comp] = size(U_stl.u_train);
        U_reshaped.u_train = reshape(U_stl.u_train, n_train, n_feat * n_comp);
        
        [n_test, ~, ~] = size(U_stl.u_test);
        U_reshaped.u_test = reshape(U_stl.u_test, n_test, n_feat * n_comp);
    end
end

function [supply_pred_denorm, demand_pred_denorm] = denormalize_predictions(...
    supply_results, demand_results, U_supply, U_demand)
%% 反标准化预测结果

    supply_pred_denorm = supply_results.test_pred * U_supply.y_stats.std + U_supply.y_stats.mean;
    demand_pred_denorm = demand_results.test_pred * U_demand.y_stats.std + U_demand.y_stats.mean;
end

function metrics = calculate_performance_metrics(supply_pred, demand_pred, balance_pred, ...
    supply_actual, demand_actual, balance_actual)
%% 计算性能指标

    metrics = struct();
    
    % 供给预测指标
    metrics.supply_mse = mean((supply_pred - supply_actual).^2);
    metrics.supply_rmse = sqrt(metrics.supply_mse);
    metrics.supply_mae = mean(abs(supply_pred - supply_actual));
    metrics.supply_r2 = calculate_r2(supply_actual, supply_pred);
    
    % 消耗预测指标
    metrics.demand_mse = mean((demand_pred - demand_actual).^2);
    metrics.demand_rmse = sqrt(metrics.demand_mse);
    metrics.demand_mae = mean(abs(demand_pred - demand_actual));
    metrics.demand_r2 = calculate_r2(demand_actual, demand_pred);
    
    % 供需关系指标
    metrics.balance_mse = mean((balance_pred - balance_actual).^2);
    metrics.balance_rmse = sqrt(metrics.balance_mse);
    metrics.balance_mae = mean(abs(balance_pred - balance_actual));
    metrics.balance_r2 = calculate_r2(balance_actual, balance_pred);
end

function r2 = calculate_r2(y_true, y_pred)
%% 计算R²系数

    ss_res = sum((y_true - y_pred).^2);
    ss_tot = sum((y_true - mean(y_true)).^2);
    
    if ss_tot == 0
        r2 = 1;  % 完美预测
    else
        r2 = 1 - ss_res / ss_tot;
    end
end

function display_step_results(horizon, metrics, step_time)
%% 显示当前步长的结果

    fprintf('预测步长 t+%d 完成 (耗时: %.2f秒)\n', horizon, step_time);
    fprintf('  供给预测 - RMSE: %.6f, MAE: %.6f, R²: %.4f\n', ...
            metrics.supply_rmse, metrics.supply_mae, metrics.supply_r2);
    fprintf('  消耗预测 - RMSE: %.6f, MAE: %.6f, R²: %.4f\n', ...
            metrics.demand_rmse, metrics.demand_mae, metrics.demand_r2);
    fprintf('  供需关系 - RMSE: %.6f, MAE: %.6f, R²: %.4f\n', ...
            metrics.balance_rmse, metrics.balance_mae, metrics.balance_r2);
end

function save_experiment_results(supply_preds, demand_preds, balance_preds, ...
    supply_actuals, demand_actuals, balance_actuals, performance_metrics, ...
    data_config, model_config, stl_config, experiment_config)
%% 保存实验结果

    results_file = fullfile(experiment_config.results_dir, 'experiment_results.mat');
    
    save(results_file, 'supply_preds', 'demand_preds', 'balance_preds', ...
         'supply_actuals', 'demand_actuals', 'balance_actuals', ...
         'performance_metrics', 'data_config', 'model_config', ...
         'stl_config', 'experiment_config');
    
    fprintf('实验结果已保存到: %s\n', results_file);
    
    % 保存性能指标到CSV
    metrics_table = struct2table(performance_metrics);
    metrics_file = fullfile(experiment_config.results_dir, 'performance_metrics.csv');
    writetable(metrics_table, metrics_file);
    
    fprintf('性能指标已保存到: %s\n', metrics_file);
end