function output = ESNnet(U, params)
%% ESNnet - 回声状态网络 (Echo State Network)
% 优化版本，支持多维特征输入和鲁棒性处理
%
% 输入参数:
%   U      - 数据结构体，包含:
%            U.u_train: 训练输入 (时间步 x 输入维度)
%            U.u_test:  测试输入 (时间步 x 输入维度)
%            U.y_train: 训练目标 (时间步 x 输出维度)
%            U.y_test:  测试目标 (时间步 x 输出维度)
%   params - 超参数结构体，包含:
%            params.inSize:      输入节点数
%            params.outSize:     输出节点数
%            params.resSize:     储备池节点数
%            params.leakingRate: 泄漏率
%            params.reg:         正则化系数
%            params.r:           谱半径
%
% 输出:
%   output - 结果结构体，包含:
%            output.train_pred: 训练集预测
%            output.test_pred:  测试集预测
%            output.train_mse:  训练集MSE
%            output.test_mse:   测试集MSE

    %% 参数验证和提取
    if ~isstruct(U) || ~all(isfield(U, {'u_train', 'u_test', 'y_train', 'y_test'}))
        error('ESNnet: U必须包含u_train, u_test, y_train, y_test字段');
    end
    
    if ~isstruct(params)
        error('ESNnet: params必须是结构体');
    end
    
    % 提取数据
    u_train = double(U.u_train);
    u_test = double(U.u_test);
    y_train = double(U.y_train);
    y_test = double(U.y_test);
    
    % 提取超参数
    inSize = params.inSize;
    outSize = params.outSize;
    resSize = params.resSize;
    leakingRate = params.leakingRate;
    reg = params.reg;
    r = params.r;
    
    %% 数据预处理
    % 处理异常值
    u_train(~isfinite(u_train)) = 0;
    u_test(~isfinite(u_test)) = 0;
    y_train(~isfinite(y_train)) = 0;
    y_test(~isfinite(y_test)) = 0;
    
    % 获取数据长度
    trainLen = size(u_train, 1);
    testLen = size(u_test, 1);
    
    % 确保输入维度匹配
    if size(u_train, 2) ~= inSize
        warning('ESNnet: 输入维度不匹配，调整inSize从%d到%d', inSize, size(u_train, 2));
        inSize = size(u_train, 2);
    end
    
    % 确保输出维度匹配
    if size(y_train, 2) ~= outSize && length(y_train) == trainLen
        % y_train是列向量，转换为行向量
        if size(y_train, 1) == trainLen && size(y_train, 2) == 1
            y_train = y_train';
            outSize = 1;
        end
    end
    
    %% 初始化网络权重
    % 输入权重矩阵 (储备池大小 x (1+输入维度))
    Win = (rand(resSize, 1+inSize) - 0.5) * 0.5;
    
    % 储备池权重矩阵 (稀疏连接以提高稳定性)
    W = sprand(resSize, resSize, 0.1) - 0.5;
    
    % 设置谱半径
    try
        opt.disp = 0;
        rhoW = abs(eigs(W, 1, 'LM', opt));
        if rhoW > 0
            W = W * (r / rhoW);
        end
    catch
        % 如果特征值计算失败，使用简单缩放
        max_val = max(abs(W(:)));
        if max_val > 0
            W = W * r / max_val;
        end
    end
    
    %% 收集储备池状态 (训练阶段)
    X = zeros(1+inSize+resSize, trainLen);
    x = zeros(resSize, 1);  % 储备池内部状态
    
    for t = 1:trainLen
        % 获取当前时间步的输入
        if size(u_train, 2) == 1
            u_t = u_train(t);
        else
            u_t = u_train(t, :)';
        end
        
        % 更新储备池状态
        x = (1-leakingRate) * x + leakingRate * tanh(Win*[1; u_t] + W*x);
        
        % 存储扩展状态向量 [偏置; 输入; 储备池状态]
        X(:, t) = [1; u_t; x];
    end
    
    %% 计算输出权重
    % 准备目标矩阵
    if size(y_train, 1) == 1
        Yt = y_train;  % 已经是行向量
    else
        Yt = y_train'; % 转置为行向量
    end
    
    % 使用Tikhonov正则化计算输出权重
    try
        % 方法1: 直接求解正规方程
        A = X*X' + reg*eye(1+inSize+resSize);
        B = X*Yt';
        Wout = (A \ B)';
    catch
        try
            % 方法2: 使用伪逆
            A = X*X' + reg*eye(1+inSize+resSize);
            Wout = Yt * X' * pinv(A);
        catch
            % 方法3: 最简单的伪逆
            warning('ESNnet: 使用简单伪逆计算输出权重');
            Wout = Yt * pinv(X);
        end
    end
    
    % 检查输出权重
    if any(~isfinite(Wout(:)))
        warning('ESNnet: 输出权重包含异常值，将被替换');
        Wout(~isfinite(Wout)) = 0;
    end
    
    %% 计算训练集预测
    train_pred_matrix = Wout * X;
    if size(train_pred_matrix, 1) == 1
        train_pred = train_pred_matrix';
    else
        train_pred = train_pred_matrix';
    end
    
    % 处理训练预测中的异常值
    train_pred(~isfinite(train_pred)) = 0;
    
    %% 测试阶段预测
    test_pred = zeros(testLen, outSize);
    x = zeros(resSize, 1);  % 重置储备池状态
    
    for t = 1:testLen
        % 获取当前时间步的输入
        if size(u_test, 2) == 1
            u_t = u_test(t);
        else
            u_t = u_test(t, :)';
        end
        
        % 更新储备池状态
        x = (1-leakingRate) * x + leakingRate * tanh(Win*[1; u_t] + W*x);
        
        % 计算输出
        input_vec = [1; u_t; x];
        y = Wout * input_vec;
        
        if length(y) == 1
            test_pred(t, 1) = y;
        else
            test_pred(t, :) = y';
        end
    end
    
    % 处理测试预测中的异常值
    test_pred(~isfinite(test_pred)) = 0;
    
    % 确保输出维度正确
    if size(test_pred, 2) == 1 && outSize == 1
        test_pred = test_pred(:, 1);
    end
    
    if size(train_pred, 2) == 1 && outSize == 1
        train_pred = train_pred(:, 1);
    end
    
    %% 计算性能指标
    % 确保目标和预测维度匹配
    if size(y_train, 1) == trainLen && size(y_train, 2) == 1
        y_train_vec = y_train;
    elseif size(y_train, 2) == trainLen && size(y_train, 1) == 1
        y_train_vec = y_train';
    else
        y_train_vec = y_train(:, 1);  % 取第一列
    end
    
    if size(y_test, 1) == testLen && size(y_test, 2) == 1
        y_test_vec = y_test;
    elseif size(y_test, 2) == testLen && size(y_test, 1) == 1
        y_test_vec = y_test';
    else
        y_test_vec = y_test(:, 1);  % 取第一列
    end
    
    % 维度匹配
    min_train_len = min(length(y_train_vec), length(train_pred));
    min_test_len = min(length(y_test_vec), length(test_pred));
    
    train_mse = mean((y_train_vec(1:min_train_len) - train_pred(1:min_train_len)).^2);
    test_mse = mean((y_test_vec(1:min_test_len) - test_pred(1:min_test_len)).^2);
    
    %% 输出结果
    output = struct();
    output.train_pred = train_pred;
    output.test_pred = test_pred;
    output.train_mse = train_mse;
    output.test_mse = test_mse;
    output.Wout = Wout;
    output.Win = Win;
    output.W = W;
    
end