%% 分离STL参数的Deep ET-RC预测实验
% 供给使用STL周期336小时，消耗使用STL周期168小时
% 只进行t+1预测以验证STL参数对预测效果的影响
% 作者: AI Assistant
% 日期: 2024

clear; clc; close all;

fprintf('=== 分离STL参数的Deep ET-RC预测实验 ===\n');
fprintf('供给STL周期: 336小时 (14天)\n');
fprintf('消耗STL周期: 168小时 (7天)\n');
fprintf('预测步长: t+1\n');
fprintf('==========================================\n\n');

%% 1. 数据配置
DATA_CONFIG = struct();
DATA_CONFIG.file_path = 'merged_data.csv';
DATA_CONFIG.feature_cols = [2,3,4,5,6,7,9,10,11,12,13]; % 排除第1列（datetime）和第8列（snowfall）
DATA_CONFIG.target_supply_col = 14; % target_0 (供给)
DATA_CONFIG.target_demand_col = 15; % target_1 (消耗)
DATA_CONFIG.train_ratio = 0.6;

%% 2. STL配置 - 分离参数
STL_CONFIG = struct();
STL_CONFIG.supply_period = 336;  % 供给：14天周期
STL_CONFIG.demand_period = 168;  % 消耗：7天周期
STL_CONFIG.enable = true;

%% 3. 模型配置
MODEL_CONFIG = struct();
% 输入维度将在运行时动态确定
MODEL_CONFIG.RC.resSize = 300;
MODEL_CONFIG.RC.a = 0.3;
MODEL_CONFIG.RC.rho = 0.99;
MODEL_CONFIG.RC.leaky = 1;
MODEL_CONFIG.RC.connectivity = 0.1;
MODEL_CONFIG.RC.input_scaling = 1;
MODEL_CONFIG.RC.bias_scaling = 0;
MODEL_CONFIG.layers = 4;

%% 4. 加载和预处理数据
fprintf('1. 数据加载和预处理...\n');
try
    data = readtable(DATA_CONFIG.file_path);
    fprintf('数据加载完成，数据形状: %d x %d\n', size(data, 1), size(data, 2));
    
    % 提取特征和目标
    features = table2array(data(:, DATA_CONFIG.feature_cols));
    supply_target = table2array(data(:, DATA_CONFIG.target_supply_col));
    demand_target = table2array(data(:, DATA_CONFIG.target_demand_col));
    
    % 移除包含NaN值的行
    valid_idx = ~any(isnan([features, supply_target, demand_target]), 2);
    features = features(valid_idx, :);
    supply_target = supply_target(valid_idx);
    demand_target = demand_target(valid_idx);
    
    % 确保数据长度足够进行STL分解
    min_length = max(STL_CONFIG.supply_period * 2, STL_CONFIG.demand_period * 2);
    if length(supply_target) < min_length
        error('数据长度不足，需要至少 %d 个数据点', min_length);
    end
    
    fprintf('移除NaN后有效数据点数: %d\n', length(supply_target));
    
    % 数据分割
    n_total = size(features, 1);
    n_train = floor(n_total * DATA_CONFIG.train_ratio);
    
    train_features = features(1:n_train, :);
    test_features = features(n_train+1:end, :);
    
    train_supply = supply_target(1:n_train);
    test_supply = supply_target(n_train+1:end);
    
    train_demand = demand_target(1:n_train);
    test_demand = demand_target(n_train+1:end);
    
    fprintf('训练集大小: %d, 测试集大小: %d\n', n_train, length(test_supply));
    
catch ME
    fprintf('数据加载错误: %s\n', ME.message);
    return;
end

%% 5. 供给预测 - 使用STL周期336
fprintf('\n2. 供给预测 (STL周期: 336小时)...\n');

try
    % STL分解供给数据
    fprintf('   执行供给STL分解...\n');
    supply_stl = perform_stl_decomposition(train_supply, test_supply, STL_CONFIG.supply_period);
    
    % 准备供给预测的输入特征
    supply_train_input = [train_features, supply_stl.train_trend, supply_stl.train_seasonal, supply_stl.train_remainder];
    supply_test_input = [test_features, supply_stl.test_trend, supply_stl.test_seasonal, supply_stl.test_remainder];
    
    % 数据归一化
    [supply_train_input_norm, supply_input_params] = normalize_data(supply_train_input);
    [supply_test_input_norm, ~] = normalize_data(supply_test_input, supply_input_params);
    [train_supply_norm, supply_target_params] = normalize_data(train_supply);
    [test_supply_norm, ~] = normalize_data(test_supply, supply_target_params);
    
    % 训练供给预测模型
    fprintf('   训练供给预测模型...\n');
    supply_model = train_deep_etrc_model(supply_train_input_norm, train_supply_norm, MODEL_CONFIG);
    
    % 供给预测
    fprintf('   执行供给预测...\n');
    supply_predictions_norm = predict_with_model(supply_model, supply_test_input_norm);
    supply_predictions = denormalize_data(supply_predictions_norm, supply_target_params);
    
    % 计算供给预测误差
    supply_rmse = sqrt(mean((supply_predictions - test_supply).^2));
    supply_mae = mean(abs(supply_predictions - test_supply));
    supply_r2 = 1 - sum((test_supply - supply_predictions).^2) / sum((test_supply - mean(test_supply)).^2);
    
    fprintf('   供给预测结果:\n');
    fprintf('   RMSE: %.4f\n', supply_rmse);
    fprintf('   MAE: %.4f\n', supply_mae);
    fprintf('   R²: %.4f\n', supply_r2);
    
catch ME
    fprintf('供给预测错误: %s\n', ME.message);
    supply_predictions = [];
    supply_rmse = NaN; supply_mae = NaN; supply_r2 = NaN;
end

%% 6. 消耗预测 - 使用STL周期168
fprintf('\n3. 消耗预测 (STL周期: 168小时)...\n');

try
    % STL分解消耗数据
    fprintf('   执行消耗STL分解...\n');
    demand_stl = perform_stl_decomposition(train_demand, test_demand, STL_CONFIG.demand_period);
    
    % 准备消耗预测的输入特征
    demand_train_input = [train_features, demand_stl.train_trend, demand_stl.train_seasonal, demand_stl.train_remainder];
    demand_test_input = [test_features, demand_stl.test_trend, demand_stl.test_seasonal, demand_stl.test_remainder];
    
    % 数据归一化
    [demand_train_input_norm, demand_input_params] = normalize_data(demand_train_input);
    [demand_test_input_norm, ~] = normalize_data(demand_test_input, demand_input_params);
    [train_demand_norm, demand_target_params] = normalize_data(train_demand);
    [test_demand_norm, ~] = normalize_data(test_demand, demand_target_params);
    
    % 训练消耗预测模型
    fprintf('   训练消耗预测模型...\n');
    demand_model = train_deep_etrc_model(demand_train_input_norm, train_demand_norm, MODEL_CONFIG);
    
    % 消耗预测
    fprintf('   执行消耗预测...\n');
    demand_predictions_norm = predict_with_model(demand_model, demand_test_input_norm);
    demand_predictions = denormalize_data(demand_predictions_norm, demand_target_params);
    
    % 计算消耗预测误差
    demand_rmse = sqrt(mean((demand_predictions - test_demand).^2));
    demand_mae = mean(abs(demand_predictions - test_demand));
    demand_r2 = 1 - sum((test_demand - demand_predictions).^2) / sum((test_demand - mean(test_demand)).^2);
    
    fprintf('   消耗预测结果:\n');
    fprintf('   RMSE: %.4f\n', demand_rmse);
    fprintf('   MAE: %.4f\n', demand_mae);
    fprintf('   R²: %.4f\n', demand_r2);
    
catch ME
    fprintf('消耗预测错误: %s\n', ME.message);
    demand_predictions = [];
    demand_rmse = NaN; demand_mae = NaN; demand_r2 = NaN;
end

%% 7. 结果可视化和保存
fprintf('\n4. 结果可视化和保存...\n');

% 创建结果目录
results_dir = 'results/separate_stl_results';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

% 绘制预测结果对比图
if ~isempty(supply_predictions) && ~isempty(demand_predictions)
    figure('Position', [100, 100, 1400, 800]);
    
    % 供给预测对比
    subplot(2, 1, 1);
    plot_length = min(500, length(test_supply)); % 只显示前500个点
    plot(1:plot_length, test_supply(1:plot_length), 'b-', 'LineWidth', 1.5, 'DisplayName', '实际供给');
    hold on;
    plot(1:plot_length, supply_predictions(1:plot_length), 'r--', 'LineWidth', 1.5, 'DisplayName', '预测供给');
    title(sprintf('供给预测对比 (STL周期: 336h) - RMSE: %.2f, MAE: %.2f, R²: %.3f', ...
        supply_rmse, supply_mae, supply_r2), 'FontSize', 12, 'FontWeight', 'bold');
    xlabel('时间步');
    ylabel('供给量');
    legend('Location', 'best');
    grid on;
    
    % 消耗预测对比
    subplot(2, 1, 2);
    plot(1:plot_length, test_demand(1:plot_length), 'b-', 'LineWidth', 1.5, 'DisplayName', '实际消耗');
    hold on;
    plot(1:plot_length, demand_predictions(1:plot_length), 'g--', 'LineWidth', 1.5, 'DisplayName', '预测消耗');
    title(sprintf('消耗预测对比 (STL周期: 168h) - RMSE: %.2f, MAE: %.2f, R²: %.3f', ...
        demand_rmse, demand_mae, demand_r2), 'FontSize', 12, 'FontWeight', 'bold');
    xlabel('时间步');
    ylabel('消耗量');
    legend('Location', 'best');
    grid on;
    
    sgtitle('分离STL参数的Deep ET-RC预测结果', 'FontSize', 14, 'FontWeight', 'bold');
    
    % 保存图形
    saveas(gcf, fullfile(results_dir, 'separate_stl_prediction_comparison.fig'));
    saveas(gcf, fullfile(results_dir, 'separate_stl_prediction_comparison.png'));
end

% 保存性能指标
performance_table = table(...
    {'Supply'; 'Demand'}, ...
    [supply_rmse; demand_rmse], ...
    [supply_mae; demand_mae], ...
    [supply_r2; demand_r2], ...
    [336; 168], ...
    'VariableNames', {'Target', 'RMSE', 'MAE', 'R_squared', 'STL_Period'});

writetable(performance_table, fullfile(results_dir, 'separate_stl_performance.csv'));

% 保存预测结果
if ~isempty(supply_predictions) && ~isempty(demand_predictions)
    predictions_table = table(...
        (1:length(test_supply))', ...
        test_supply, supply_predictions, ...
        test_demand, demand_predictions, ...
        'VariableNames', {'TimeStep', 'Actual_Supply', 'Predicted_Supply', ...
                         'Actual_Demand', 'Predicted_Demand'});
    
    writetable(predictions_table, fullfile(results_dir, 'separate_stl_predictions.csv'));
end

% 保存MATLAB数据
save(fullfile(results_dir, 'separate_stl_results.mat'), ...
    'supply_predictions', 'demand_predictions', 'test_supply', 'test_demand', ...
    'supply_rmse', 'supply_mae', 'supply_r2', ...
    'demand_rmse', 'demand_mae', 'demand_r2', ...
    'STL_CONFIG', 'MODEL_CONFIG');

fprintf('\n=== 分离STL参数实验完成 ===\n');
fprintf('结果已保存到: %s\n', results_dir);
fprintf('供给预测 (STL=336h): RMSE=%.2f, MAE=%.2f, R²=%.3f\n', supply_rmse, supply_mae, supply_r2);
fprintf('消耗预测 (STL=168h): RMSE=%.2f, MAE=%.2f, R²=%.3f\n', demand_rmse, demand_mae, demand_r2);

%% 辅助函数

function stl_result = perform_stl_decomposition(train_data, test_data, period)
    % 执行STL分解
    try
        % 对训练数据进行STL分解
        if length(train_data) < 2 * period
            % 数据长度不足，使用简化分解
            fprintf('     警告: 训练数据长度不足，使用简化STL分解\n');
            stl_result.train_trend = train_data * 0.7;
            stl_result.train_seasonal = sin(2*pi*(1:length(train_data))'/period) * std(train_data) * 0.2;
            stl_result.train_remainder = train_data - stl_result.train_trend - stl_result.train_seasonal;
        else
            % 使用MATLAB的STL分解
            [train_trend, train_seasonal, train_remainder] = stl_decompose_simple(train_data, period);
            stl_result.train_trend = train_trend;
            stl_result.train_seasonal = train_seasonal;
            stl_result.train_remainder = train_remainder;
        end
        
        % 对测试数据进行STL分解
        if length(test_data) < 2 * period
            fprintf('     警告: 测试数据长度不足，使用简化STL分解\n');
            stl_result.test_trend = test_data * 0.7;
            stl_result.test_seasonal = sin(2*pi*(1:length(test_data))'/period) * std(test_data) * 0.2;
            stl_result.test_remainder = test_data - stl_result.test_trend - stl_result.test_seasonal;
        else
            [test_trend, test_seasonal, test_remainder] = stl_decompose_simple(test_data, period);
            stl_result.test_trend = test_trend;
            stl_result.test_seasonal = test_seasonal;
            stl_result.test_remainder = test_remainder;
        end
        
    catch ME
        fprintf('     STL分解失败，使用默认分解: %s\n', ME.message);
        % 默认分解
        stl_result.train_trend = train_data * 0.7;
        stl_result.train_seasonal = zeros(size(train_data));
        stl_result.train_remainder = train_data * 0.3;
        
        stl_result.test_trend = test_data * 0.7;
        stl_result.test_seasonal = zeros(size(test_data));
        stl_result.test_remainder = test_data * 0.3;
    end
end

function [data_norm, params] = normalize_data(data, params)
    % 数据归一化
    if nargin < 2
        params.mean = mean(data, 1);
        params.std = std(data, 1);
        params.std(params.std == 0) = 1; % 避免除零
    end
    
    data_norm = (data - params.mean) ./ params.std;
end

function data_denorm = denormalize_data(data_norm, params)
    % 数据反归一化
    data_denorm = data_norm .* params.std + params.mean;
end

function model = train_deep_etrc_model(input_data, target_data, config)
    % 训练Deep ET-RC模型
    try
        % 准备数据结构体
        U = struct();
        U.u_train = input_data;
        U.u_test = input_data;  % 这里暂时使用训练数据，实际预测时会替换
        U.y_train = target_data;
        U.y_test = target_data; % 这里暂时使用训练数据，实际预测时会替换
        
        % 准备RC层参数
        params_RC = struct();
        params_RC.inSize = size(input_data, 2);
        params_RC.outSize = 1;  % 输出维度
        params_RC.resSize = config.RC.resSize;
        params_RC.a = config.RC.a;
        params_RC.rho = config.RC.rho;
        params_RC.leaky = config.RC.leaky;
        params_RC.leakingRate = config.RC.leaky;  % ESNnet使用leakingRate
        params_RC.connectivity = config.RC.connectivity;
        params_RC.input_scaling = config.RC.input_scaling;
        params_RC.bias_scaling = config.RC.bias_scaling;
        params_RC.reg = 1e-8;  % 正则化参数
        params_RC.r = config.RC.rho;  % 谱半径
        
        % 准备ET层参数
        params_ET = struct();
        params_ET.inSize = size(input_data, 2);
        params_ET.outSize = 1;  % 输出维度
        params_ET.resSize = config.RC.resSize;
        params_ET.a = config.RC.a;
        params_ET.rho = config.RC.rho;
        params_ET.leaky = config.RC.leaky;
        params_ET.leakingRate = config.RC.leaky;  % ESNnet使用leakingRate
        params_ET.connectivity = config.RC.connectivity;
        params_ET.input_scaling = config.RC.input_scaling;
        params_ET.bias_scaling = config.RC.bias_scaling;
        params_ET.reg = 1e-8;  % 正则化参数
        params_ET.r = config.RC.rho;  % 谱半径
        
        % 调用DeepET_RC函数
        model = DeepET_RC(config.layers, params_RC, params_ET, U);
        
    catch ME
        fprintf('     模型训练失败: %s\n', ME.message);
        model = [];
    end
end

function predictions = predict_with_model(model, input_data)
    % 使用模型进行预测
    try
        if ~isempty(model) && isfield(model, 'test_pred')
            % DeepET_RC模型已经包含预测结果
            predictions = model.test_pred;
            
            % 如果预测结果长度与输入不匹配，进行调整
            if length(predictions) ~= size(input_data, 1)
                if length(predictions) > size(input_data, 1)
                    predictions = predictions(1:size(input_data, 1));
                else
                    % 如果预测结果太短，用最后一个值填充
                    predictions = [predictions; repmat(predictions(end), size(input_data, 1) - length(predictions), 1)];
                end
            end
        else
            predictions = [];
        end
    catch ME
        fprintf('     预测失败: %s\n', ME.message);
        predictions = [];
    end
end