function [trend, seasonal, remainder] = stl_decompose_simple(data, season_length)
    % 简化的STL分解函数 - 优化性能
    % 
    % 输入参数:
    %   data - 一维时间序列数据
    %   season_length - 季节周期长度
    %
    % 输出参数:
    %   trend - 趋势组件
    %   seasonal - 季节性组件
    %   remainder - 残差组件
    
    % 检查输入数据
    if length(data) < season_length * 2
        warning('数据长度不足，无法进行有效的STL分解');
        trend = movmean(data, min(season_length, length(data)/4));
        seasonal = zeros(size(data));
        remainder = data - trend;
        return;
    end
    
    % 使用简化的STL分解算法
    [trend, seasonal, remainder] = simple_stl_decompose(data, season_length);
end

function [trend, seasonal, remainder] = simple_stl_decompose(data, season_length)
    % 简化的STL分解算法 - 快速版本
    
    % 参数设置
    max_iterations = 5; % 减少迭代次数
    tolerance = 1e-4;   % 放宽收敛条件
    
    % 初始化
    n = length(data);
    trend = zeros(size(data));
    seasonal = zeros(size(data));
    remainder = data;
    
    % 迭代分解
    for iter = 1:max_iterations
        prev_seasonal = seasonal;
        
        % 步骤1: 季节性分解 - 简化版本
        seasonal = extract_seasonal_simple(data - trend, season_length);
        
        % 步骤2: 趋势分解 - 简化版本
        deseasonalized = data - seasonal;
        trend = extract_trend_simple(deseasonalized, season_length);
        
        % 步骤3: 计算残差
        remainder = data - trend - seasonal;
        
        % 检查收敛
        if iter > 1
            seasonal_change = mean(abs(seasonal - prev_seasonal));
            if seasonal_change < tolerance
                break;
            end
        end
    end
    
    % 确保分量和等于原始数据
    reconstruction_error = data - (trend + seasonal + remainder);
    if max(abs(reconstruction_error)) > 1e-8
        remainder = remainder + reconstruction_error;
    end
end

function seasonal = extract_seasonal_simple(data, season_length)
    % 提取季节性组件 - 简化版本
    
    n = length(data);
    seasonal = zeros(size(data));
    
    % 计算每个季节位置的平均值
    for i = 1:season_length
        % 找到所有相同季节位置的数据点
        indices = i:season_length:n;
        if length(indices) > 1
            % 使用均值而不是中位数，速度更快
            seasonal_value = mean(data(indices));
            seasonal(indices) = seasonal_value;
        else
            seasonal(indices) = data(indices);
        end
    end
    
    % 简单的季节性平滑 - 只对长周期进行
    if season_length > 24
        seasonal = simple_smooth_seasonal(seasonal, season_length);
    end
    
    % 去除季节性组件的趋势（确保季节性组件的均值为0）
    seasonal = seasonal - mean(seasonal);
end

function trend = extract_trend_simple(data, season_length)
    % 提取趋势组件 - 简化版本
    
    % 使用移动平均进行趋势提取
    window_size = max(season_length, 7);
    window_size = min(window_size, length(data)/3);
    
    % 确保窗口大小为奇数
    if mod(window_size, 2) == 0
        window_size = window_size + 1;
    end
    
    % 使用移动平均
    trend = movmean(data, window_size);
    
    % 对于长时间序列，进行二次平滑
    if length(data) > 1000
        smooth_window = max(3, round(window_size/3));
        if mod(smooth_window, 2) == 0
            smooth_window = smooth_window + 1;
        end
        trend = movmean(trend, smooth_window);
    end
end

function smoothed = simple_smooth_seasonal(seasonal, season_length)
    % 对季节性组件进行简单平滑处理
    
    smoothed = seasonal;
    n = length(seasonal);
    window_size = 3; % 固定小窗口
    
    for i = 1:season_length
        indices = i:season_length:n;
        if length(indices) > window_size
            values = seasonal(indices);
            smoothed_values = movmean(values, window_size);
            smoothed(indices) = smoothed_values;
        end
    end
end