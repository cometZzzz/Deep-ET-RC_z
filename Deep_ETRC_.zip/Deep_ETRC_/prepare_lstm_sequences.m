function [X_seq, y_seq_supply, y_seq_demand] = prepare_lstm_sequences(X, y_supply, y_demand, sequence_length)
%PREPARE_LSTM_SEQUENCES 为LSTM模型准备序列数据
%
% 输入:
%   X - 特征矩阵 [n_samples x n_features]
%   y_supply - 供给目标变量 [n_samples x 1]
%   y_demand - 消耗目标变量 [n_samples x 1]
%   sequence_length - 序列长度
%
% 输出:
%   X_seq - 序列特征 [n_sequences x sequence_length x n_features]
%   y_seq_supply - 供给目标序列 [n_sequences x 1]
%   y_seq_demand - 消耗目标序列 [n_sequences x 1]

    [n_samples, n_features] = size(X);
    n_sequences = n_samples - sequence_length;
    
    % 初始化输出数组
    X_seq = zeros(n_sequences, sequence_length, n_features);
    y_seq_supply = zeros(n_sequences, 1);
    y_seq_demand = zeros(n_sequences, 1);
    
    % 创建序列
    for i = 1:n_sequences
        % 输入序列：从第i个样本开始的sequence_length个时间步
        X_seq(i, :, :) = X(i:i+sequence_length-1, :);
        
        % 目标值：序列后的下一个时间步
        y_seq_supply(i) = y_supply(i + sequence_length);
        y_seq_demand(i) = y_demand(i + sequence_length);
    end
    
    fprintf('序列数据准备完成: %d个序列，序列长度=%d，特征维度=%d\n', ...
            n_sequences, sequence_length, n_features);
end