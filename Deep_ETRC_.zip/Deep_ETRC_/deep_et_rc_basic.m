% 代码用途：基础版 Deep ET-RC（Echo Temporal - Reservoir Computing）训练与预测
% 简介：可自由设置ET层数、是否进行STL分解（按已优化季节长度）、固定特征列（按约定索引）、训练集比例等，输出预测曲线并计算MSE/MAE/RMSE

function deep_et_rc_basic(settings)
    %% ======================== 可配置超参数 ========================
    % 数据与目标
    DATA_FILE = fullfile(fileparts(mfilename('fullpath')), 'merged_data.csv');
    TARGET_NAME = 'Supply';   % 可选：'Supply' 或 'Consumption'
    % 固定特征列索引（按约定）：
    % Supply 预测: [3, 6, 9, 10, 14]（含自身历史 target_0 = Supply）
    % Consumption 预测: [3, 6, 9, 10, 15]（含自身历史 target_1 = Consumption）
    SUPPLY_FEATURE_IDX = [3, 6, 9, 10, 14];
    CONSUMPTION_FEATURE_IDX = [3, 6, 9, 10, 15];
    USE_FIXED_FEATURES = false;    % 固定使用上述索引作为特征；设为false以选用全部特征
    INCLUDE_TARGET_IN_FEATURES = true;  % 自动选特征时是否包含目标列
    EXCLUDE_DATETIME = true;            % 自动选特征时排除datetime列
    USE_STL = true;                % 是否使用STL分解
    STL_SEASON_LENGTH_HOURS = 168; % 已优化的季节长度（小时），如日周期24、周周期168等
    STL_USE_REMAINDER_AS_TARGET = true;            % 用残差作为训练目标
    STL_APPEND_COMPONENTS_TO_FEATURES = true;      % 将趋势/季节性加入特征

    % 训练与模型参数
    HORIZON = 1;                   % 预测步长 t+HORIZON
    TRAIN_RATIO = 0.8;             % 训练集比例（按时间划分）
    STANDARDIZE_INPUT = true;      % 是否标准化输入特征
    RNG_SEED = 42;                 % 随机数种子

    % ET-RC 深度与各层参数（长度需与层数一致）
    NUM_ET_LAYERS = 3;                             % ET层数（>=1）
    RES_SIZES = [150, 120, 80];                    % 各层 reservoir 大小（略降以提高稳健性）
    LEAK_RATES = [0.5, 0.4, 0.3];                  % 各层泄漏率 (0,1]（减小以提升稳定）
    SPECTRAL_RADII = [0.90, 0.90, 0.90];           % 各层谱半径（略降防发散）
    RIDGE_REG = 1e-4;                              % 读出层岭回归正则（增强泛化）
    SPARSITY = 0.1;                                % reservoir 稀疏度（0-1）
    AUTO_WASHOUT = true;                           % 自动按季周期设置 washout
    WASHOUT_USER = 48;                             % 用户自定义的 washout（小时）
    APPEND_INPUT_TO_READOUT = true;                % 读出层拼接原始标准化输入
    STATE_STANDARDIZE = true;                      % 对 reservoir 状态进行标准化

    % 可视化
    FIG_POSITION = [100, 100, 1200, 600];
    FONT_NAME = 'Times New Roman';
    LINE_WIDTH = 1.4;

    % 结果保存
    SAVE_RESULTS = false;                        % 是否保存图像与指标
    OUTPUT_DIR = fullfile(fileparts(mfilename('fullpath')), 'results_basic');
    EXP_NAME = '';

    %% ======================== 覆盖配置（可选） ========================
    if nargin >= 1 && isstruct(settings)
        fld = @(n) isfield(settings, n);
        if fld('DATA_FILE'), DATA_FILE = settings.DATA_FILE; end
        if fld('TARGET_NAME'), TARGET_NAME = settings.TARGET_NAME; end
        if fld('SUPPLY_FEATURE_IDX'), SUPPLY_FEATURE_IDX = settings.SUPPLY_FEATURE_IDX; end
        if fld('CONSUMPTION_FEATURE_IDX'), CONSUMPTION_FEATURE_IDX = settings.CONSUMPTION_FEATURE_IDX; end
        if fld('USE_FIXED_FEATURES'), USE_FIXED_FEATURES = settings.USE_FIXED_FEATURES; end
        if fld('INCLUDE_TARGET_IN_FEATURES'), INCLUDE_TARGET_IN_FEATURES = settings.INCLUDE_TARGET_IN_FEATURES; end
        if fld('EXCLUDE_DATETIME'), EXCLUDE_DATETIME = settings.EXCLUDE_DATETIME; end
        if fld('USE_STL'), USE_STL = settings.USE_STL; end
        if fld('STL_SEASON_LENGTH_HOURS'), STL_SEASON_LENGTH_HOURS = settings.STL_SEASON_LENGTH_HOURS; end
        if fld('STL_USE_REMAINDER_AS_TARGET'), STL_USE_REMAINDER_AS_TARGET = settings.STL_USE_REMAINDER_AS_TARGET; end
        if fld('STL_APPEND_COMPONENTS_TO_FEATURES'), STL_APPEND_COMPONENTS_TO_FEATURES = settings.STL_APPEND_COMPONENTS_TO_FEATURES; end
        if fld('HORIZON'), HORIZON = settings.HORIZON; end
        if fld('TRAIN_RATIO'), TRAIN_RATIO = settings.TRAIN_RATIO; end
        if fld('STANDARDIZE_INPUT'), STANDARDIZE_INPUT = settings.STANDARDIZE_INPUT; end
        if fld('RNG_SEED'), RNG_SEED = settings.RNG_SEED; end
        if fld('NUM_ET_LAYERS'), NUM_ET_LAYERS = settings.NUM_ET_LAYERS; end
        if fld('RES_SIZES'), RES_SIZES = settings.RES_SIZES; end
        if fld('LEAK_RATES'), LEAK_RATES = settings.LEAK_RATES; end
        if fld('SPECTRAL_RADII'), SPECTRAL_RADII = settings.SPECTRAL_RADII; end
        if fld('RIDGE_REG'), RIDGE_REG = settings.RIDGE_REG; end
        if fld('SPARSITY'), SPARSITY = settings.SPARSITY; end
        if fld('AUTO_WASHOUT'), AUTO_WASHOUT = settings.AUTO_WASHOUT; end
        if fld('WASHOUT_USER'), WASHOUT_USER = settings.WASHOUT_USER; end
        if fld('APPEND_INPUT_TO_READOUT'), APPEND_INPUT_TO_READOUT = settings.APPEND_INPUT_TO_READOUT; end
        if fld('STATE_STANDARDIZE'), STATE_STANDARDIZE = settings.STATE_STANDARDIZE; end
        if fld('FIG_POSITION'), FIG_POSITION = settings.FIG_POSITION; end
        if fld('FONT_NAME'), FONT_NAME = settings.FONT_NAME; end
        if fld('LINE_WIDTH'), LINE_WIDTH = settings.LINE_WIDTH; end
        if fld('SAVE_RESULTS'), SAVE_RESULTS = settings.SAVE_RESULTS; end
        if fld('OUTPUT_DIR'), OUTPUT_DIR = settings.OUTPUT_DIR; end
        if fld('EXP_NAME'), EXP_NAME = settings.EXP_NAME; end
    end

    %% ======================== 环境与数据加载 ========================
    rng(RNG_SEED);
    assert(exist(DATA_FILE, 'file') == 2, '找不到数据文件: %s', DATA_FILE);
    T = readtable(DATA_FILE);

    % 统一列名（老数据为 target_0/target_1）
    if any(strcmp(T.Properties.VariableNames, 'target_0'))
        T.Properties.VariableNames{strcmp(T.Properties.VariableNames, 'target_0')} = 'Supply';
    end
    if any(strcmp(T.Properties.VariableNames, 'target_1'))
        T.Properties.VariableNames{strcmp(T.Properties.VariableNames, 'target_1')} = 'Consumption';
    end

    % 时间列标准化为 datetime
    if ~isdatetime(T.datetime)
        try
            T.datetime = datetime(T.datetime, 'InputFormat', 'yyyy-MM-dd HH:mm:ss');
        catch
            T.datetime = datetime(T.datetime);
        end
    end

    % 提取目标
    assert(any(strcmp(T.Properties.VariableNames, TARGET_NAME)), '目标列不存在: %s', TARGET_NAME);
    target_raw = T.(TARGET_NAME);

    %% ======================== STL 分解（可选） ========================
    trend = []; seasonal = []; remainder = [];
    target_series = target_raw;
    if USE_STL
        try
            [trend, seasonal, remainder] = stl_decompose_simple(target_raw, STL_SEASON_LENGTH_HOURS);
        catch ME
            warning('STL分解失败，改用简化分解: %s', ME.message);
            % 简化备选方案：移动均值作为趋势，余量作为残差
            win = min(STL_SEASON_LENGTH_HOURS, max(5, floor(length(target_raw)/50)));
            trend = movmean(target_raw, win);
            seasonal = zeros(size(target_raw));
            remainder = target_raw - trend;
        end

        if STL_USE_REMAINDER_AS_TARGET
            target_series = remainder;
        end
    end

    %% ======================== 特征构建 ========================
    % 固定特征选择（按提供的索引集）
    widthT = width(T);
    if USE_FIXED_FEATURES
        if strcmpi(TARGET_NAME, 'Supply')
            assert(all(SUPPLY_FEATURE_IDX >= 1 & SUPPLY_FEATURE_IDX <= widthT), 'Supply特征索引越界');
            U = T{:, SUPPLY_FEATURE_IDX};
        elseif strcmpi(TARGET_NAME, 'Consumption')
            assert(all(CONSUMPTION_FEATURE_IDX >= 1 & CONSUMPTION_FEATURE_IDX <= widthT), 'Consumption特征索引越界');
            U = T{:, CONSUMPTION_FEATURE_IDX};
        else
            error('未知目标名称: %s', TARGET_NAME);
        end
    else
        % 自动选择所有数值列；可选地包含目标列，排除datetime
        data_vars = T.Properties.VariableNames;
        feature_mask = false(1, numel(data_vars));
        for i = 1:numel(data_vars)
            vn = data_vars{i};
            if EXCLUDE_DATETIME && strcmp(vn, 'datetime')
                continue;
            end
            if ~INCLUDE_TARGET_IN_FEATURES && strcmp(vn, TARGET_NAME)
                continue;
            end
            col = T.(vn);
            feature_mask(i) = isnumeric(col);
        end
        FEATURE_NAMES = data_vars(feature_mask);
        U = T{:, FEATURE_NAMES};
    end
    % 追加 STL 组件作为特征（若启用）
    if USE_STL && STL_APPEND_COMPONENTS_TO_FEATURES
        U = [U, trend(:), seasonal(:)];
    end

    % 数值化与缺失值处理（避免NaN/Inf导致训练失败）
    U = double(U);
    if any(~isfinite(U), 'all')
        U = fillmissing(U, 'linear', 'EndValues', 'nearest');
        U(~isfinite(U)) = 0; % 极端情况下将非有限值置零
    end
    target_series = double(target_series);
    if any(~isfinite(target_series))
        target_series = fillmissing(target_series, 'linear', 'EndValues', 'nearest');
        target_series(~isfinite(target_series)) = 0;
    end

    %% ======================== 对齐与标准化 ========================
    N = size(U, 1);
    assert(N == numel(target_series), '特征与目标长度不一致');

    valid_idx = 1:(N - HORIZON);
    N_valid = numel(valid_idx);
    N_train = floor(TRAIN_RATIO * N_valid);
    train_idx = valid_idx(1:N_train);
    test_idx  = valid_idx(N_train+1:end);

    if STANDARDIZE_INPUT
        mu = mean(U(train_idx, :), 1);
        sigma = std(U(train_idx, :), 0, 1);
        sigma(sigma == 0) = 1;
        U = (U - mu) ./ sigma;
    end

    %% ======================== 构建并运行：逐层补偿 Deep ET-RC ========================
    % 验证参数长度
    assert(NUM_ET_LAYERS >= 1, 'NUM_ET_LAYERS 需 >= 1');
    assert(numel(RES_SIZES) == NUM_ET_LAYERS);
    assert(numel(LEAK_RATES) == NUM_ET_LAYERS);
    assert(numel(SPECTRAL_RADII) == NUM_ET_LAYERS);

    % 应用 washout 丢弃初始瞬态（如启用自动，则至少一个季节周期）
    washout_effective = WASHOUT_USER;
    if AUTO_WASHOUT
        if USE_STL
            washout_effective = max(WASHOUT_USER, STL_SEASON_LENGTH_HOURS);
        else
            washout_effective = WASHOUT_USER; % 非STL时使用用户设定
        end
    end
    start_idx = max(1, washout_effective + 1);
    valid_idx = start_idx:(N - HORIZON);
    Y_all = target_series(valid_idx + HORIZON);   % 目标 t+HORIZON（若使用STL则为 remainder）

    % 训练/测试切分索引
    N_valid = numel(valid_idx);
    N_train = floor(TRAIN_RATIO * N_valid);
    train_mask = false(N_valid, 1); train_mask(1:N_train) = true;
    test_mask  = ~train_mask;

    % 提取对应段的输入特征
    U_valid = U(valid_idx, :);
    U_train = U_valid(train_mask, :);
    U_test  = U_valid(test_mask,  :);
    Y_train = Y_all(train_mask);
    Y_test  = Y_all(test_mask);

    % ---------- 第1层：基座预测（用原始特征U） ----------
    inSize1 = size(U_train, 2);
    [W_in1, W1] = build_reservoir(inSize1, RES_SIZES(1), SPARSITY, SPECTRAL_RADII(1));
    S1_train = forward_reservoir(W_in1, W1, U_train, LEAK_RATES(1));
    S1_test  = forward_reservoir(W_in1, W1, U_test,  LEAK_RATES(1));

    % 状态标准化（按训练集统计）
    if STATE_STANDARDIZE
        mu_s1 = mean(S1_train, 1); sigma_s1 = std(S1_train, 0, 1); sigma_s1(sigma_s1 == 0) = 1;
        S1_train = (S1_train - mu_s1) ./ sigma_s1;
        S1_test  = (S1_test  - mu_s1) ./ sigma_s1;
    end

    % 读出层设计矩阵（可选拼接原始输入）
    if APPEND_INPUT_TO_READOUT
        X1_train = [S1_train, U_train];
        X1_test  = [S1_test,  U_test];
    else
        X1_train = S1_train; X1_test = S1_test;
    end

    I1 = eye(size(X1_train, 2));
    W_out1 = (X1_train' * X1_train + RIDGE_REG * I1) \ (X1_train' * Y_train);
    yhat_train_acc = X1_train * W_out1;
    yhat_test_acc  = X1_test  * W_out1;

    % ---------- 后续 ET 层：逐层补偿 ----------
    for l = 2:NUM_ET_LAYERS
        % 训练目标为上一层的残差（err = y - yhat）
        err_prev_train = Y_train - yhat_train_acc;
        err_prev_test  = Y_test  - yhat_test_acc;
        % i层输入：上一层残差序列 e^{(i-1)}
        inp_train = err_prev_train;
        inp_test  = err_prev_test;

        % 构建该层的reservoir（单通道输入）
        [W_inL, WL] = build_reservoir(1, RES_SIZES(l), SPARSITY, SPECTRAL_RADII(l));
        SL_train = forward_reservoir(W_inL, WL, inp_train(:), LEAK_RATES(l));
        SL_test  = forward_reservoir(W_inL, WL, inp_test(:),  LEAK_RATES(l));

        % 状态标准化（按训练集统计）
        if STATE_STANDARDIZE
            mu_sL = mean(SL_train, 1); sigma_sL = std(SL_train, 0, 1); sigma_sL(sigma_sL == 0) = 1;
            SL_train = (SL_train - mu_sL) ./ sigma_sL;
            SL_test  = (SL_test  - mu_sL) ./ sigma_sL;
        end

        % 读出层设计矩阵：仅使用 reservoir 状态（避免残差直接“旁路”导致测试阶段零误差）
        % 说明：保留残差作为RC驱动输入，但不将其作为读出层的直通特征，
        % 以免在教师强制（test使用真值残差）时出现 delta ≈ err 的完美拟合，造成不合理的0误差。
        XL_train = SL_train; 
        XL_test  = SL_test;

        IL = eye(size(XL_train, 2));
        % 本层输出为补偿项 delta_l，拟合上一层的残差
        W_outL = (XL_train' * XL_train + RIDGE_REG * IL) \ (XL_train' * err_prev_train);
        delta_train = XL_train * W_outL;
        delta_test  = XL_test  * W_outL;

        % 累加补偿，得到新的预测
        yhat_train_acc = yhat_train_acc + delta_train;
        yhat_test_acc  = yhat_test_acc  + delta_test;
    end

    % 汇总最终预测
    Y_pred_train = yhat_train_acc;
    Y_pred_test  = yhat_test_acc;

    % 若使用了 remainder 作为目标，则重构原目标用于评估
    if USE_STL && STL_USE_REMAINDER_AS_TARGET
        trend_lag = trend(valid_idx + HORIZON);
        seasonal_lag = seasonal(valid_idx + HORIZON);
        Y_true_full = target_raw(valid_idx + HORIZON);
        Y_true_train_full = Y_true_full(1:N_train);
        % 重构原目标用于评估
        Y_pred_train = Y_pred_train + trend_lag(1:N_train) + seasonal_lag(1:N_train);
        Y_pred_test  = Y_pred_test  + trend_lag(N_train+1:end) + seasonal_lag(N_train+1:end);
        Y_train = Y_true_train_full;
        Y_test  = Y_true_full(N_train+1:end);
    end

    %% ======================== 评估指标 ========================
    metrics_train = compute_metrics(Y_train, Y_pred_train);
    metrics_test  = compute_metrics(Y_test,  Y_pred_test);

    fprintf('\n=== 评估指标（%s, horizon=%d）===\n', TARGET_NAME, HORIZON);
    fprintf('Train: MSE=%.6f, RMSE=%.6f, MAE=%.6f\n', metrics_train.mse, metrics_train.rmse, metrics_train.mae);
    fprintf('Test : MSE=%.6f, RMSE=%.6f, MAE=%.6f\n', metrics_test.mse, metrics_test.rmse, metrics_test.mae);

    %% ======================== 绘图 ========================
    figure('Position', FIG_POSITION, 'Color', 'w');
    plot(Y_test, 'k-', 'LineWidth', LINE_WIDTH); hold on;
    plot(Y_pred_test, 'r--', 'LineWidth', LINE_WIDTH);
    grid on; box on; legend({'Actual', 'Predicted'}, 'Location', 'best', 'FontName', FONT_NAME);
    title(sprintf('Deep ET-RC Prediction (%s, t+%d)', TARGET_NAME, HORIZON), 'FontName', FONT_NAME);
    xlabel('Time Index', 'FontName', FONT_NAME); ylabel(sprintf('%s', TARGET_NAME), 'FontName', FONT_NAME);

    %% ======================== 保存图像与指标（可选） ========================
    if SAVE_RESULTS
        if ~exist(OUTPUT_DIR, 'dir'); mkdir(OUTPUT_DIR); end
        stl_tag = ternary(USE_STL, 'STL', 'NoSTL');
        if isempty(EXP_NAME)
            EXP_NAME = sprintf('%s_%s_L%d', TARGET_NAME, stl_tag, NUM_ET_LAYERS);
        end
        fig_path = fullfile(OUTPUT_DIR, sprintf('%s.png', EXP_NAME));
        metrics_path = fullfile(OUTPUT_DIR, sprintf('%s_metrics.txt', EXP_NAME));
        summary_csv = fullfile(OUTPUT_DIR, 'summary_metrics.csv');

        try
            exportgraphics(gcf, fig_path, 'Resolution', 300);
        catch
            print(gcf, '-dpng', '-r300', fig_path);
        end

        fid = fopen(metrics_path, 'w');
        fprintf(fid, 'Target=%s\nUseSTL=%d\nLayers=%d\nWashout=%d\n', TARGET_NAME, USE_STL, NUM_ET_LAYERS, washout_effective);
        fprintf(fid, 'Train: MSE=%.6f, RMSE=%.6f, MAE=%.6f\n', metrics_train.mse, metrics_train.rmse, metrics_train.mae);
        fprintf(fid, 'Test : MSE=%.6f, RMSE=%.6f, MAE=%.6f\n', metrics_test.mse, metrics_test.rmse, metrics_test.mae);
        fclose(fid);

        % 追加到汇总CSV
        write_header = ~exist(summary_csv, 'file');
        fid = fopen(summary_csv, 'a');
        if write_header
            fprintf(fid, 'exp_name,target,use_stl,layers,horizon,train_ratio,rmse,mae,mse\n');
        end
        fprintf(fid, '%s,%s,%d,%d,%d,%.3f,%.6f,%.6f,%.6f\n', EXP_NAME, TARGET_NAME, USE_STL, NUM_ET_LAYERS, HORIZON, TRAIN_RATIO, metrics_test.rmse, metrics_test.mae, metrics_test.mse);
        fclose(fid);
    end
end

%% ======================== 辅助函数 ========================
function states = run_deep_et_rc_layers(U, L, RES_SIZES, LEAK_RATES, SPECTRAL_RADII, SPARSITY)
    N = size(U, 1);
    input_size = size(U, 2);
    states_prev = U;  % 初始以输入特征作为第1层输入

    for l = 1:L
        resSize = RES_SIZES(l);
        leak = LEAK_RATES(l);
        rho = SPECTRAL_RADII(l);
        [W_in, W] = build_reservoir(size(states_prev, 2), resSize, SPARSITY, rho);
        x = zeros(resSize, 1);
        S = zeros(N, resSize);
        for t = 1:N
            u = states_prev(t, :)';
            pre = W_in * [1; u] + W * x;  % 加偏置1
            x = (1 - leak) * x + leak * tanh(pre);
            S(t, :) = x';
        end
        states_prev = S;  % 下一层的输入是上一层的状态
    end

    states = states_prev; % 使用最后一层状态作为读出层输入
end

function states = run_deep_et_rc_layers_error(err_series, L, RES_SIZES, LEAK_RATES, SPECTRAL_RADII, SPARSITY)
% 代码用途：以“上一时刻预测误差序列”为输入的多层 ET-RC 状态生成
% 简介：每层 RC 接收误差单通道输入并生成状态，最终返回最后一层状态
    N = numel(err_series);
    states_input = err_series(:);   % N×1 的误差输入序列

    for l = 1:L
        resSize = RES_SIZES(l);
        leak = LEAK_RATES(l);
        rho = SPECTRAL_RADII(l);
        % 输入维度为 1（误差通道）
        [W_in, W] = build_reservoir(1, resSize, SPARSITY, rho);
        x = zeros(resSize, 1);
        S = zeros(N, resSize);
        for t = 1:N
            u = states_input(t);    % 标量误差作为本时刻输入
            pre = W_in * [1; u] + W * x;  % 加偏置1
            x = (1 - leak) * x + leak * tanh(pre);
            S(t, :) = x';
        end
        % 各层都基于同一误差序列；不使用上一层状态作为输入
    end
    states = S; % 返回最后一层的状态
end

function y = ternary(cond, a, b)
    if cond
        y = a;
    else
        y = b;
    end
end

function [W_in, W] = build_reservoir(inSize, resSize, sparsity, target_rho)
    % 输入权重（含偏置）：resSize x (1 + inSize)
    W_in = (rand(resSize, 1 + inSize) - 0.5) * 2;  % [-1,1]

    % 稀疏随机 reservoir 权重：resSize x resSize
    W = sprand(resSize, resSize, sparsity);
    W = full(W);
    W(W ~= 0) = (W(W ~= 0) - 0.5) * 2;  % [-1,1]

    % 缩放谱半径
    opts.disp = 0;
    try
        rhoW = max(abs(eigs(W, 1, 'lm', opts)));
    catch
        % 回退到完整特征值（矩阵不大时可行），提高鲁棒性
        rhoW = max(abs(eig(W)));
    end
    if rhoW == 0
        rhoW = 1e-3;
    end
    W = W * (target_rho / rhoW);
end

function S = forward_reservoir(W_in, W, U_series, leak)
    % 代码用途：给定固定的 reservoir（W_in, W），在输入序列 U_series 上前向生成状态
    % 简介：支持多维输入（N×D）或单通道向量，返回 N×resSize 的状态矩阵
    if isvector(U_series)
        U_series = U_series(:);
    end
    N = size(U_series, 1);
    resSize = size(W, 1);
    S = zeros(N, resSize);
    x = zeros(resSize, 1);
    for t = 1:N
        u = U_series(t, :)';
        pre = W_in * [1; u] + W * x;  % 加偏置1
        x = (1 - leak) * x + leak * tanh(pre);
        S(t, :) = x';
    end
end

function m = compute_metrics(y, yhat)
    err = yhat - y;
    m.mse = mean(err.^2);
    m.rmse = sqrt(m.mse);
    m.mae = mean(abs(err));
end