%% Deep ET-RC MAE验证脚本
% 目的: 验证Deep ET-RC供给预测MAE为43.9是否合理
% 确保学术诚信，排除数据造假可能

clear; clc; close all;

fprintf('=== Deep ET-RC MAE验证脚本 ===\n');
fprintf('目的: 验证供给预测MAE为43.9的合理性\n\n');

%% 1. 加载和检查原始数据
fprintf('1. 加载原始数据...\n');
data = readtable('merged_data.csv');
supply_data = data{:,13};  % target_0 供给列
demand_data = data{:,14};  % target_1 需求列

% 数据清理
valid_idx = ~isnan(supply_data) & ~isnan(demand_data);
supply_clean = supply_data(valid_idx);
demand_clean = demand_data(valid_idx);

fprintf('原始数据统计:\n');
fprintf('  供给数据范围: %.4f 到 %.4f\n', min(supply_clean), max(supply_clean));
fprintf('  供给数据均值: %.4f, 标准差: %.4f\n', mean(supply_clean), std(supply_clean));
fprintf('  需求数据范围: %.4f 到 %.4f\n', min(demand_clean), max(demand_clean));
fprintf('  需求数据均值: %.4f, 标准差: %.4f\n', mean(demand_clean), std(demand_clean));
fprintf('  有效样本数: %d\n\n', length(supply_clean));

%% 2. 数据分割（模拟实验设置）
fprintf('2. 数据分割...\n');
train_ratio = 0.7;
train_size = floor(train_ratio * length(supply_clean));
test_size = length(supply_clean) - train_size;

train_supply = supply_clean(1:train_size);
test_supply = supply_clean(train_size+1:end);
train_demand = demand_clean(1:train_size);
test_demand = demand_clean(train_size+1:end);

fprintf('训练集大小: %d, 测试集大小: %d\n', train_size, test_size);
fprintf('测试集供给统计: 均值=%.4f, 标准差=%.4f\n', mean(test_supply), std(test_supply));
fprintf('测试集需求统计: 均值=%.4f, 标准差=%.4f\n\n', mean(test_demand), std(test_demand));

%% 3. 基准预测性能分析
fprintf('3. 基准预测性能分析...\n');

% 3.1 常数预测（预测值=训练集均值）
constant_pred_supply = repmat(mean(train_supply), length(test_supply), 1);
constant_mae_supply = mean(abs(test_supply - constant_pred_supply));

constant_pred_demand = repmat(mean(train_demand), length(test_demand), 1);
constant_mae_demand = mean(abs(test_demand - constant_pred_demand));

fprintf('常数预测MAE:\n');
fprintf('  供给: %.4f\n', constant_mae_supply);
fprintf('  需求: %.4f\n', constant_mae_demand);

% 3.2 随机预测
random_pred_supply = normrnd(mean(train_supply), std(train_supply), length(test_supply), 1);
random_mae_supply = mean(abs(test_supply - random_pred_supply));

random_pred_demand = normrnd(mean(train_demand), std(train_demand), length(test_demand), 1);
random_mae_demand = mean(abs(test_demand - random_pred_demand));

fprintf('随机预测MAE:\n');
fprintf('  供给: %.4f\n', random_mae_supply);
fprintf('  需求: %.4f\n', random_mae_demand);

% 3.3 完美预测的理论下限
perfect_mae = 0;
fprintf('完美预测MAE: %.4f\n\n', perfect_mae);

%% 4. 检查Deep ET-RC声称的性能
fprintf('4. Deep ET-RC声称的性能检查...\n');
claimed_supply_mae = 43.9;
claimed_demand_mae = 619.2;

fprintf('声称的MAE:\n');
fprintf('  供给: %.4f\n', claimed_supply_mae);
fprintf('  需求: %.4f\n', claimed_demand_mae);

% 计算相对于基准的改进
supply_improvement = (constant_mae_supply - claimed_supply_mae) / constant_mae_supply * 100;
demand_improvement = (constant_mae_demand - claimed_demand_mae) / constant_mae_demand * 100;

fprintf('相对于常数预测的改进:\n');
fprintf('  供给: %.2f%%\n', supply_improvement);
fprintf('  需求: %.2f%%\n', demand_improvement);

%% 5. 合理性检查
fprintf('\n5. 合理性检查...\n');

% 5.1 检查是否超出理论界限
if claimed_supply_mae < 0
    fprintf('❌ 警告: 供给MAE为负数，不合理！\n');
elseif claimed_supply_mae > constant_mae_supply
    fprintf('⚠️  注意: 供给MAE比常数预测还差\n');
else
    fprintf('✅ 供给MAE在合理范围内\n');
end

if claimed_demand_mae < 0
    fprintf('❌ 警告: 需求MAE为负数，不合理！\n');
elseif claimed_demand_mae > constant_mae_demand
    fprintf('⚠️  注意: 需求MAE比常数预测还差\n');
else
    fprintf('✅ 需求MAE在合理范围内\n');
end

% 5.2 检查数据尺度
supply_range = max(test_supply) - min(test_supply);
demand_range = max(test_demand) - min(test_demand);

fprintf('\n数据尺度分析:\n');
fprintf('  供给数据范围: %.4f\n', supply_range);
fprintf('  需求数据范围: %.4f\n', demand_range);
fprintf('  供给MAE占数据范围比例: %.2f%%\n', claimed_supply_mae/supply_range*100);
fprintf('  需求MAE占数据范围比例: %.2f%%\n', claimed_demand_mae/demand_range*100);

%% 6. 数据预处理检查
fprintf('\n6. 数据预处理检查...\n');

% 检查数据是否已经标准化
supply_mean_close_to_zero = abs(mean(supply_clean)) < 1;
supply_std_close_to_one = abs(std(supply_clean) - 1) < 0.5;

if supply_mean_close_to_zero && supply_std_close_to_one
    fprintf('⚠️  供给数据可能已经标准化 (均值≈0, 标准差≈1)\n');
else
    fprintf('✅ 供给数据未标准化 (均值=%.4f, 标准差=%.4f)\n', mean(supply_clean), std(supply_clean));
end

demand_mean_close_to_zero = abs(mean(demand_clean)) < 100;
demand_std_close_to_one = abs(std(demand_clean) - 1) < 0.5;

if demand_mean_close_to_zero && demand_std_close_to_one
    fprintf('⚠️  需求数据可能已经标准化\n');
else
    fprintf('✅ 需求数据未标准化 (均值=%.4f, 标准差=%.4f)\n', mean(demand_clean), std(demand_clean));
end

%% 7. 生成验证报告
fprintf('\n=== 验证报告 ===\n');

% 计算可信度评分
credibility_score = 100;

% 扣分项
if claimed_supply_mae < constant_mae_supply * 0.1
    credibility_score = credibility_score - 30;
    fprintf('❌ 供给MAE过低，可能存在问题 (-30分)\n');
end

if supply_improvement > 95
    credibility_score = credibility_score - 20;
    fprintf('❌ 供给改进过大，不太可能 (-20分)\n');
end

if claimed_supply_mae < std(test_supply) * 0.1
    credibility_score = credibility_score - 25;
    fprintf('❌ 供给MAE远小于数据标准差，异常 (-25分)\n');
end

% 加分项
if claimed_supply_mae > 0 && claimed_supply_mae < constant_mae_supply
    credibility_score = credibility_score + 10;
    fprintf('✅ 供给MAE在合理范围 (+10分)\n');
end

if claimed_demand_mae > 0 && claimed_demand_mae < constant_mae_demand
    credibility_score = credibility_score + 10;
    fprintf('✅ 需求MAE在合理范围 (+10分)\n');
end

fprintf('\n最终可信度评分: %d/100\n', credibility_score);

if credibility_score >= 80
    fprintf('✅ 结果可信度高\n');
elseif credibility_score >= 60
    fprintf('⚠️  结果可信度中等，需要进一步验证\n');
else
    fprintf('❌ 结果可信度低，建议重新检查实验\n');
end

%% 8. 保存验证结果
verification_results = struct();
verification_results.original_data_stats = struct('supply_mean', mean(supply_clean), ...
    'supply_std', std(supply_clean), 'demand_mean', mean(demand_clean), 'demand_std', std(demand_clean));
verification_results.baseline_performance = struct('constant_mae_supply', constant_mae_supply, ...
    'constant_mae_demand', constant_mae_demand, 'random_mae_supply', random_mae_supply, ...
    'random_mae_demand', random_mae_demand);
verification_results.claimed_performance = struct('supply_mae', claimed_supply_mae, ...
    'demand_mae', claimed_demand_mae);
verification_results.credibility_score = credibility_score;

save('deepetrc_mae_verification.mat', 'verification_results');
fprintf('\n验证结果已保存到 deepetrc_mae_verification.mat\n');

fprintf('\n=== 验证完成 ===\n');