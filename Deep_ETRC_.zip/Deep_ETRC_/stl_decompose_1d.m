function [trend, seasonal, remainder] = stl_decompose_1d(data, season_length)
    % STL分解函数 - 专门用于一维时间序列
    % 
    % 输入参数:
    %   data - 一维时间序列数据
    %   season_length - 季节周期长度
    %
    % 输出参数:
    %   trend - 趋势组件
    %   seasonal - 季节性组件
    %   remainder - 残差组件
    
    % 检查输入数据
    if length(data) < season_length * 2
        warning('数据长度不足，无法进行有效的STL分解');
        trend = movmean(data, min(season_length, length(data)/4));
        seasonal = zeros(size(data));
        remainder = data - trend;
        return;
    end
    
    % 使用改进的STL分解算法
    [trend, seasonal, remainder] = improved_stl_decompose(data, season_length);
end

function [trend, seasonal, remainder] = improved_stl_decompose(data, season_length)
    % 改进的STL分解算法
    
    % 参数设置
    max_iterations = 10;
    tolerance = 1e-6;
    
    % 初始化
    n = length(data);
    trend = zeros(size(data));
    seasonal = zeros(size(data));
    remainder = data;
    
    % 迭代分解
    for iter = 1:max_iterations
        prev_seasonal = seasonal;
        
        % 步骤1: 季节性分解
        seasonal = extract_seasonal_component(data - trend, season_length);
        
        % 步骤2: 趋势分解
        deseasonalized = data - seasonal;
        trend = extract_trend_component(deseasonalized, season_length);
        
        % 步骤3: 计算残差
        remainder = data - trend - seasonal;
        
        % 检查收敛
        if iter > 1
            seasonal_change = mean(abs(seasonal - prev_seasonal));
            if seasonal_change < tolerance
                break;
            end
        end
    end
    
    % 确保分量和等于原始数据
    reconstruction_error = data - (trend + seasonal + remainder);
    if max(abs(reconstruction_error)) > 1e-10
        remainder = remainder + reconstruction_error;
    end
end

function seasonal = extract_seasonal_component(data, season_length)
    % 提取季节性组件
    
    n = length(data);
    seasonal = zeros(size(data));
    
    % 计算每个季节位置的平均值
    for i = 1:season_length
        % 找到所有相同季节位置的数据点
        indices = i:season_length:n;
        if length(indices) > 1
            % 使用中位数来减少异常值的影响
            seasonal_value = median(data(indices));
            seasonal(indices) = seasonal_value;
        else
            seasonal(indices) = data(indices);
        end
    end
    
    % 对季节性组件进行平滑处理
    if season_length > 3
        window_size = min(5, season_length);
        seasonal = smooth_seasonal(seasonal, season_length, window_size);
    end
    
    % 去除季节性组件的趋势（确保季节性组件的均值为0）
    seasonal = seasonal - mean(seasonal);
end

function trend = extract_trend_component(data, season_length)
    % 提取趋势组件
    
    % 使用局部加权回归(LOESS)进行趋势提取
    window_size = max(season_length * 2 + 1, 7);
    window_size = min(window_size, length(data));
    
    % 确保窗口大小为奇数
    if mod(window_size, 2) == 0
        window_size = window_size + 1;
    end
    
    % 使用移动平均进行初步趋势提取
    trend = movmean(data, window_size);
    
    % 使用LOESS平滑进行精细调整
    trend = loess_smooth(data, 0.3); % 30%的数据用于局部拟合
end

function smoothed = smooth_seasonal(seasonal, season_length, window_size)
    % 对季节性组件进行平滑处理
    
    smoothed = seasonal;
    n = length(seasonal);
    
    for i = 1:season_length
        indices = i:season_length:n;
        if length(indices) > window_size
            values = seasonal(indices);
            smoothed_values = movmean(values, window_size);
            smoothed(indices) = smoothed_values;
        end
    end
end

function smoothed = loess_smooth(data, span)
    % 简化的LOESS平滑函数
    
    n = length(data);
    smoothed = zeros(size(data));
    window_size = max(3, round(n * span));
    
    for i = 1:n
        % 确定局部窗口
        start_idx = max(1, i - floor(window_size/2));
        end_idx = min(n, i + floor(window_size/2));
        
        % 提取局部数据
        local_x = (start_idx:end_idx)';
        local_y = data(start_idx:end_idx);
        
        % 计算权重（三次权重函数）
        distances = abs(local_x - i);
        max_distance = max(distances);
        if max_distance > 0
            weights = (1 - (distances / max_distance).^3).^3;
            weights(distances > max_distance) = 0;
        else
            weights = ones(size(distances));
        end
        
        % 加权线性回归
        if sum(weights) > 0
            X = [ones(length(local_x), 1), local_x - i];
            W = diag(weights);
            try
                beta = (X' * W * X) \ (X' * W * local_y);
                smoothed(i) = beta(1); % 截距项就是在点i处的拟合值
            catch
                % 如果矩阵奇异，使用加权平均
                smoothed(i) = sum(weights .* local_y) / sum(weights);
            end
        else
            smoothed(i) = data(i);
        end
    end
end