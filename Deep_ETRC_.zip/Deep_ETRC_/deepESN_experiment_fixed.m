%% Deep ESN实验 - 太阳能发电供需预测 (修复版)
% 使用Deep Echo State Network进行供给和需求序列预测
% 修复了数据索引和维度问题
% 作者: AI Assistant
% 日期: 2024

clear; clc; close all;

%% 添加DeepESN路径
addpath('../DeepESN');

%% 数据加载和预处理
fprintf('=== Deep ESN 太阳能发电供需预测实验 (修复版) ===\n');
fprintf('正在加载数据...\n');

% 加载数据
data = readtable('merged_data.csv');
supply_data = data.target_0;  % 供给数据
demand_data = data.target_1;  % 需求数据

% 移除NaN值
valid_indices = ~isnan(supply_data) & ~isnan(demand_data);
supply_data = supply_data(valid_indices);
demand_data = demand_data(valid_indices);

% 数据标准化
supply_mean = mean(supply_data);
supply_std = std(supply_data);
demand_mean = mean(demand_data);
demand_std = std(demand_data);

supply_normalized = (supply_data - supply_mean) / supply_std;
demand_normalized = (demand_data - demand_mean) / demand_std;

fprintf('数据加载完成。供给数据长度: %d, 需求数据长度: %d\n', ...
    length(supply_data), length(demand_data));

%% 数据分割
train_ratio = 0.7;
total_len = length(supply_data);
train_len = floor(total_len * train_ratio);
test_len = total_len - train_len;

% 供给数据分割
supply_train = supply_normalized(1:train_len);
supply_test = supply_normalized(train_len+1:end);

% 需求数据分割
demand_train = demand_normalized(1:train_len);
demand_test = demand_normalized(train_len+1:end);

fprintf('训练集长度: %d, 测试集长度: %d\n', train_len, test_len);

%% Deep ESN参数设置
fprintf('\n正在设置Deep ESN参数...\n');

% Deep ESN超参数
Nr = 50;           % 每层储备池大小
Nl = 3;            % 储备池层数
Nu = 1;            % 输入维度
Ny = 1;            % 输出维度
spectral_radius = 0.9;     % 谱半径
input_scaling = 1.0;       % 输入缩放
inter_scaling = 0.5;       % 层间连接缩放
leaking_rate = 0.3;        % 泄漏率
washout = 100;             % 冲洗期
readout_regularization = 1e-6;  % 正则化参数

fprintf('Deep ESN参数:\n');
fprintf('  储备池层数: %d\n', Nl);
fprintf('  每层储备池大小: %d\n', Nr);
fprintf('  谱半径: %.2f\n', spectral_radius);
fprintf('  泄漏率: %.2f\n', leaking_rate);
fprintf('  冲洗期: %d\n', washout);

%% 供给序列预测
fprintf('\n=== 供给序列预测 ===\n');

% 创建Deep ESN模型
supply_deepesn = DeepESN();
supply_deepesn.Nr = Nr;
supply_deepesn.Nu = Nu;
supply_deepesn.Ny = Ny;
supply_deepesn.Nl = Nl;
supply_deepesn.spectral_radius = spectral_radius;
supply_deepesn.input_scaling = input_scaling;
supply_deepesn.inter_scaling = inter_scaling;
supply_deepesn.leaking_rate = leaking_rate;
supply_deepesn.washout = washout;
supply_deepesn.readout_regularization = readout_regularization;

% 初始化Deep ESN
supply_deepesn.initialize();

% 准备时间序列数据 (修复版)
% 创建完整的输入输出序列
supply_full_data = [supply_train; supply_test];
total_samples = length(supply_full_data) - 1;  % 减1因为要预测下一个时刻

% 输入: t时刻的值，输出: t+1时刻的值
supply_input = supply_full_data(1:end-1)';     % 1 x (N-1)
supply_target = supply_full_data(2:end)';      % 1 x (N-1)

% 训练和测试索引 (修复版)
train_samples = train_len - 1;  % 训练样本数
training_indices = 1:train_samples;
test_indices = (train_samples+1):total_samples;

fprintf('训练样本数: %d, 测试样本数: %d\n', length(training_indices), length(test_indices));

fprintf('开始训练供给预测模型...\n');
tic;
[supply_train_pred, supply_test_pred] = supply_deepesn.train_test(...
    supply_input, supply_target, training_indices, test_indices);
supply_train_time = toc;
fprintf('供给模型训练完成，用时: %.2f秒\n', supply_train_time);

%% 需求序列预测
fprintf('\n=== 需求序列预测 ===\n');

% 创建Deep ESN模型
demand_deepesn = DeepESN();
demand_deepesn.Nr = Nr;
demand_deepesn.Nu = Nu;
demand_deepesn.Ny = Ny;
demand_deepesn.Nl = Nl;
demand_deepesn.spectral_radius = spectral_radius;
demand_deepesn.input_scaling = input_scaling;
demand_deepesn.inter_scaling = inter_scaling;
demand_deepesn.leaking_rate = leaking_rate;
demand_deepesn.washout = washout;
demand_deepesn.readout_regularization = readout_regularization;

% 初始化Deep ESN
demand_deepesn.initialize();

% 准备时间序列数据 (修复版)
demand_full_data = [demand_train; demand_test];
demand_input = demand_full_data(1:end-1)';
demand_target = demand_full_data(2:end)';

fprintf('开始训练需求预测模型...\n');
tic;
[demand_train_pred, demand_test_pred] = demand_deepesn.train_test(...
    demand_input, demand_target, training_indices, test_indices);
demand_train_time = toc;
fprintf('需求模型训练完成，用时: %.2f秒\n', demand_train_time);

%% 反标准化预测结果
supply_train_pred_denorm = supply_train_pred * supply_std + supply_mean;
supply_test_pred_denorm = supply_test_pred * supply_std + supply_mean;
demand_train_pred_denorm = demand_train_pred * demand_std + demand_mean;
demand_test_pred_denorm = demand_test_pred * demand_std + demand_mean;

% 真实值（修复版索引）
supply_train_true = supply_data(2:train_len);  % 对应训练预测的真实值
supply_test_true = supply_data(train_len+2:end);  % 对应测试预测的真实值
demand_train_true = demand_data(2:train_len);
demand_test_true = demand_data(train_len+2:end);

%% 性能评估
fprintf('\n=== 性能评估 ===\n');

% 供给预测性能
supply_train_rmse = sqrt(mean((supply_train_pred_denorm - supply_train_true).^2));
supply_train_mae = mean(abs(supply_train_pred_denorm - supply_train_true));
supply_train_r2 = 1 - sum((supply_train_true - supply_train_pred_denorm).^2) / ...
                   sum((supply_train_true - mean(supply_train_true)).^2);

supply_test_rmse = sqrt(mean((supply_test_pred_denorm - supply_test_true).^2));
supply_test_mae = mean(abs(supply_test_pred_denorm - supply_test_true));
supply_test_r2 = 1 - sum((supply_test_true - supply_test_pred_denorm).^2) / ...
                  sum((supply_test_true - mean(supply_test_true)).^2);

% 需求预测性能
demand_train_rmse = sqrt(mean((demand_train_pred_denorm - demand_train_true).^2));
demand_train_mae = mean(abs(demand_train_pred_denorm - demand_train_true));
demand_train_r2 = 1 - sum((demand_train_true - demand_train_pred_denorm).^2) / ...
                   sum((demand_train_true - mean(demand_train_true)).^2);

demand_test_rmse = sqrt(mean((demand_test_pred_denorm - demand_test_true).^2));
demand_test_mae = mean(abs(demand_test_pred_denorm - demand_test_true));
demand_test_r2 = 1 - sum((demand_test_true - demand_test_pred_denorm).^2) / ...
                  sum((demand_test_true - mean(demand_test_true)).^2);

% 显示结果
fprintf('供给预测结果:\n');
fprintf('  训练集 - RMSE: %.3f, MAE: %.3f, R²: %.4f\n', ...
    supply_train_rmse, supply_train_mae, supply_train_r2);
fprintf('  测试集 - RMSE: %.3f, MAE: %.3f, R²: %.4f\n', ...
    supply_test_rmse, supply_test_mae, supply_test_r2);

fprintf('\n需求预测结果:\n');
fprintf('  训练集 - RMSE: %.3f, MAE: %.3f, R²: %.4f\n', ...
    demand_train_rmse, demand_train_mae, demand_train_r2);
fprintf('  测试集 - RMSE: %.3f, MAE: %.3f, R²: %.4f\n', ...
    demand_test_rmse, demand_test_mae, demand_test_r2);

%% 保存结果到指定文件夹
fprintf('\n正在保存结果到模型预测结果文件夹...\n');

% 创建结果结构体
deepESN_results = struct();
deepESN_results.parameters = struct(...
    'Nr', Nr, 'Nl', Nl, 'spectral_radius', spectral_radius, ...
    'input_scaling', input_scaling, 'inter_scaling', inter_scaling, ...
    'leaking_rate', leaking_rate, 'washout', washout, ...
    'readout_regularization', readout_regularization);

% 保存预测结果
deepESN_results.supply = struct(...
    'train_pred', supply_train_pred_denorm, 'test_pred', supply_test_pred_denorm, ...
    'train_true', supply_train_true, 'test_true', supply_test_true, ...
    'train_rmse', supply_train_rmse, 'train_mae', supply_train_mae, 'train_r2', supply_train_r2, ...
    'test_rmse', supply_test_rmse, 'test_mae', supply_test_mae, 'test_r2', supply_test_r2, ...
    'train_time', supply_train_time);

deepESN_results.demand = struct(...
    'train_pred', demand_train_pred_denorm, 'test_pred', demand_test_pred_denorm, ...
    'train_true', demand_train_true, 'test_true', demand_test_true, ...
    'train_rmse', demand_train_rmse, 'train_mae', demand_train_mae, 'train_r2', demand_train_r2, ...
    'test_rmse', demand_test_rmse, 'test_mae', demand_test_mae, 'test_r2', demand_test_r2, ...
    'train_time', demand_train_time);

% 保存到指定文件夹
results_dir = 'results/模型预测结果/';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

save([results_dir 'deepESN_results_fixed.mat'], 'deepESN_results');
fprintf('结果已保存到 %sdeepESN_results_fixed.mat\n', results_dir);

%% 可视化结果
fprintf('\n正在生成可视化图表...\n');

% 预测结果对比图
figure('Position', [100, 100, 1200, 800]);

% 供给预测对比
subplot(2,2,1);
plot(supply_train_true, 'b-', 'LineWidth', 1.5); hold on;
plot(supply_train_pred_denorm, 'r--', 'LineWidth', 1.5);
title('供给预测 - 训练集');
xlabel('时间步'); ylabel('供给量');
legend('真实值', '预测值', 'Location', 'best');
grid on;

subplot(2,2,2);
plot(supply_test_true, 'b-', 'LineWidth', 1.5); hold on;
plot(supply_test_pred_denorm, 'r--', 'LineWidth', 1.5);
title('供给预测 - 测试集');
xlabel('时间步'); ylabel('供给量');
legend('真实值', '预测值', 'Location', 'best');
grid on;

% 需求预测对比
subplot(2,2,3);
plot(demand_train_true, 'b-', 'LineWidth', 1.5); hold on;
plot(demand_train_pred_denorm, 'r--', 'LineWidth', 1.5);
title('需求预测 - 训练集');
xlabel('时间步'); ylabel('需求量');
legend('真实值', '预测值', 'Location', 'best');
grid on;

subplot(2,2,4);
plot(demand_test_true, 'b-', 'LineWidth', 1.5); hold on;
plot(demand_test_pred_denorm, 'r--', 'LineWidth', 1.5);
title('需求预测 - 测试集');
xlabel('时间步'); ylabel('需求量');
legend('真实值', '预测值', 'Location', 'best');
grid on;

sgtitle('Deep ESN 预测结果对比 (修复版)', 'FontSize', 16, 'FontWeight', 'bold');
saveas(gcf, [results_dir 'deepESN_prediction_comparison_fixed.png']);
fprintf('预测对比图已保存到 %sdeepESN_prediction_comparison_fixed.png\n', results_dir);

% 性能指标对比图
figure('Position', [200, 200, 1000, 600]);

metrics_names = {'RMSE', 'MAE', 'R²'};
supply_train_metrics = [supply_train_rmse, supply_train_mae, supply_train_r2];
supply_test_metrics = [supply_test_rmse, supply_test_mae, supply_test_r2];
demand_train_metrics = [demand_train_rmse, demand_train_mae, demand_train_r2];
demand_test_metrics = [demand_test_rmse, demand_test_mae, demand_test_r2];

subplot(1,2,1);
x = 1:3;
bar(x-0.15, supply_train_metrics, 0.3, 'FaceColor', [0.2 0.6 0.8]); hold on;
bar(x+0.15, supply_test_metrics, 0.3, 'FaceColor', [0.8 0.4 0.2]);
set(gca, 'XTickLabel', metrics_names);
title('供给预测性能指标');
ylabel('指标值');
legend('训练集', '测试集', 'Location', 'best');
grid on;

subplot(1,2,2);
bar(x-0.15, demand_train_metrics, 0.3, 'FaceColor', [0.2 0.6 0.8]); hold on;
bar(x+0.15, demand_test_metrics, 0.3, 'FaceColor', [0.8 0.4 0.2]);
set(gca, 'XTickLabel', metrics_names);
title('需求预测性能指标');
ylabel('指标值');
legend('训练集', '测试集', 'Location', 'best');
grid on;

sgtitle('Deep ESN 性能指标对比 (修复版)', 'FontSize', 16, 'FontWeight', 'bold');
saveas(gcf, [results_dir 'deepESN_performance_comparison_fixed.png']);
fprintf('性能对比图已保存到 %sdeepESN_performance_comparison_fixed.png\n', results_dir);

%% 总结
fprintf('\n=== Deep ESN 实验总结 (修复版) ===\n');
fprintf('模型配置: %d层Deep ESN，每层%d个神经元\n', Nl, Nr);
fprintf('总训练时间: %.2f秒\n', supply_train_time + demand_train_time);
fprintf('\n最终测试集性能:\n');
fprintf('供给预测: RMSE=%.3f, MAE=%.3f, R²=%.4f\n', ...
    supply_test_rmse, supply_test_mae, supply_test_r2);
fprintf('需求预测: RMSE=%.3f, MAE=%.3f, R²=%.4f\n', ...
    demand_test_rmse, demand_test_mae, demand_test_r2);
fprintf('\nDeep ESN实验 (修复版) 完成！\n');
fprintf('所有结果已保存到: %s\n', results_dir);