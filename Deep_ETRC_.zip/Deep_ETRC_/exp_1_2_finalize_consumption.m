% 实验1.2收尾脚本：仅生成Consumption的最终STL分解图与总结
% 作用与简介：当联动优化脚本在Consumption阶段异常退出时，提供稳健兜底，
% 使用经验周期窗口生成最终分解图，并汇总Supply/Consumption最终选择。

function exp_1_2_finalize_consumption()
    % 路径与输出目录
    ROOT = fileparts(mfilename('fullpath'));
    DATA_CSV = fullfile(ROOT, '..', '..', 'Deep_ER-RC_exp', 'merged_data.csv');
    OUT_DIR = fullfile(ROOT, 'NewResult', 'Exp1_2');
    if ~exist(OUT_DIR, 'dir'); mkdir(OUT_DIR); end

    % 读取数据
    T = readtable(DATA_CSV);
    time = (1:height(T))';
    consumption = T{:, 15};  % target_1 列

    % 选择稳健的经验周期窗口（Consumption更贴近24小时日周期，取24小时）
    win_c = 24;

    % 执行STL分解（使用现有的简化函数）
    [trend_c, seasonal_c, remainder_c] = stl_decompose_simple(consumption, win_c);

    % 绘图参数（遵循全局提示）
    FIG_POSITION = [100, 100, 1400, 900];
    FONT_NAME   = 'Microsoft YaHei UI';
    FONT_SIZE   = 14;
    LINE_WIDTH  = 1.8;

    f = figure('Position', FIG_POSITION); set(f, 'Color', 'w');
    tiledlayout(4,1,'Padding','compact','TileSpacing','compact');
    nexttile; plot(time, consumption, 'Color', [0.1 0.3 0.6], 'LineWidth', LINE_WIDTH); title('Consumption 原始序列', 'FontName', FONT_NAME, 'FontSize', FONT_SIZE); ylabel('值'); grid on;
    nexttile; plot(time, trend_c, 'Color', [0.2 0.6 0.2], 'LineWidth', LINE_WIDTH); title('趋势组件', 'FontName', FONT_NAME, 'FontSize', FONT_SIZE); ylabel('值'); grid on;
    nexttile; plot(time, seasonal_c, 'Color', [0.85 0.33 0.1], 'LineWidth', LINE_WIDTH); title(sprintf('季节性组件 (窗口=%dh)', win_c), 'FontName', FONT_NAME, 'FontSize', FONT_SIZE); ylabel('值'); grid on;
    nexttile; plot(time, remainder_c, 'Color', [0.5 0.5 0.5], 'LineWidth', LINE_WIDTH); title('残差组件', 'FontName', FONT_NAME, 'FontSize', FONT_SIZE); ylabel('值'); grid on; xlabel('时间');

    out_png = fullfile(OUT_DIR, sprintf('consumption_stl_final_window_%dh.png', win_c));
    try
        exportgraphics(f, out_png, 'Resolution', 300);
    catch
        saveas(f, out_png);
    end
    close(f);

    % 写出总结文件
    summary_file = fullfile(OUT_DIR, 'stl_optimization_summary.txt');
    supply_best = detect_supply_best(OUT_DIR);
    fid = fopen(summary_file, 'w');
    fprintf(fid, 'Experiment 1.2 STL Window Final Selection\n');
    fprintf(fid, 'Supply: %dh\n', supply_best);
    fprintf(fid, 'Consumption: %dh\n', win_c);
    fprintf(fid, '说明：Supply的最终窗口来自已生成文件或日志检测；Consumption使用稳健兜底窗口。\n');
    fclose(fid);

    fprintf('Finalize完成：生成 %s 和 %s\n', out_png, summary_file);
end

function val = detect_supply_best(out_dir)
    % 如果有最终图文件按名称解析，否则尝试从日志中读取；再不行默认22小时
    d = dir(fullfile(out_dir, 'supply_stl_final_window_*h.png'));
    if ~isempty(d)
        nm = d(1).name;
        tok = regexp(nm, 'final_window_(\d+)h', 'tokens');
        if ~isempty(tok)
            val = str2double(tok{1}{1}); return;
        end
    end
    logp = fullfile(out_dir, 'stl_optimization_log_supply.txt');
    if exist(logp, 'file')
        txt = fileread(logp);
        m = regexp(txt, 'Final Window:\s*(\d+)', 'tokens');
        if ~isempty(m)
            val = str2double(m{1}{1}); return;
        end
    end
    val = 22;
end