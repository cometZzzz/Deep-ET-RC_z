%% 简化版四模型性能对比分析
% 对比模型: Deep ET-RC (STL), ResESN, Deep ESN, LSTM
% 作者: AI Assistant
% 日期: 2024

clear; clc; close all;

fprintf('=== 简化版四模型性能对比分析 ===\n');
fprintf('对比模型: Deep ET-RC (STL), ResESN, Deep ESN, LSTM\n');

%% 1. 加载模型预测结果
fprintf('\n1. 加载模型预测结果...\n');

try
    % Deep ET-RC (STL) 结果
    fprintf('加载 Deep ET-RC (STL) 结果...\n');
    deepetrc_file = 'results/performance_metrics.csv';
    deepetrc_data = readtable(deepetrc_file);
    
    % ResESN 结果
    fprintf('加载 ResESN 结果...\n');
    resESN_file = 'results/模型预测结果/ResESN/resESN_performance.csv';
    resESN_data = readtable(resESN_file);
    
    % Deep ESN 结果
    fprintf('加载 Deep ESN 结果...\n');
    deepESN_file = 'results/模型预测结果/performance_metrics.csv';
    deepESN_data = readtable(deepESN_file);
    
    % LSTM 结果
    fprintf('加载 LSTM 结果...\n');
    lstm_file = 'results/模型预测结果/LSTM/robust_lstm_performance.csv';
    lstm_data = readtable(lstm_file);
    
    fprintf('所有模型结果加载成功！\n');
    
catch ME
    fprintf('错误: %s\n', ME.message);
    return;
end

%% 2. 数据预处理和统一格式
fprintf('\n2. 数据预处理和统一格式...\n');

% 提取Deep ET-RC结果 (取第一行，即t+1预测结果)
deepetrc_supply_rmse = deepetrc_data.supply_rmse(1);
deepetrc_supply_mae = deepetrc_data.supply_mae(1);
deepetrc_demand_rmse = deepetrc_data.demand_rmse(1);
deepetrc_demand_mae = deepetrc_data.demand_mae(1);

% 提取ResESN结果 (测试集结果)
resESN_test_idx = strcmp(resESN_data.Dataset, 'Test');
resESN_supply_rmse = resESN_data.RMSE(resESN_test_idx & strcmp(resESN_data.Target, 'Supply'));
resESN_supply_mae = resESN_data.MAE(resESN_test_idx & strcmp(resESN_data.Target, 'Supply'));
resESN_demand_rmse = resESN_data.RMSE(resESN_test_idx & strcmp(resESN_data.Target, 'Demand'));
resESN_demand_mae = resESN_data.MAE(resESN_test_idx & strcmp(resESN_data.Target, 'Demand'));

% 提取Deep ESN结果 (取第一行)
deepESN_supply_rmse = deepESN_data.supply_rmse(1);
deepESN_supply_mae = deepESN_data.supply_mae(1);
deepESN_demand_rmse = deepESN_data.demand_rmse(1);
deepESN_demand_mae = deepESN_data.demand_mae(1);

% 提取LSTM结果
lstm_supply_rmse = lstm_data.Supply_RMSE;
lstm_supply_mae = lstm_data.Supply_MAE;
lstm_demand_rmse = lstm_data.Demand_RMSE;
lstm_demand_mae = lstm_data.Demand_MAE;

%% 3. 创建对比数据结构
fprintf('\n3. 创建对比数据结构...\n');

% 模型名称
model_names = {'Deep ET-RC (STL)', 'ResESN', 'Deep ESN', 'LSTM'};

% 供应预测RMSE和MAE
supply_rmse = [deepetrc_supply_rmse, resESN_supply_rmse, deepESN_supply_rmse, lstm_supply_rmse];
supply_mae = [deepetrc_supply_mae, resESN_supply_mae, deepESN_supply_mae, lstm_supply_mae];

% 需求预测RMSE和MAE
demand_rmse = [deepetrc_demand_rmse, resESN_demand_rmse, deepESN_demand_rmse, lstm_demand_rmse];
demand_mae = [deepetrc_demand_mae, resESN_demand_mae, deepESN_demand_mae, lstm_demand_mae];

%% 4. 生成误差指标展示表
fprintf('\n4. 生成误差指标展示表...\n');

% 创建表格
comparison_table = table(model_names', supply_rmse', supply_mae', demand_rmse', demand_mae', ...
    'VariableNames', {'Model', 'Supply_RMSE', 'Supply_MAE', 'Demand_RMSE', 'Demand_MAE'});

fprintf('\n=== 四模型性能对比表 ===\n');
disp(comparison_table);

%% 5. 生成箱线图
fprintf('\n5. 生成箱线图...\n');

% 创建输出目录
output_dir = '对比图';
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

% 创建图形
figure('Position', [100, 100, 1200, 800]);

% 供应预测误差对比
subplot(2, 2, 1);
bar(supply_rmse);
set(gca, 'XTickLabel', model_names);
title('供应预测 RMSE 对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('RMSE', 'FontSize', 12);
grid on;
xtickangle(45);

subplot(2, 2, 2);
bar(supply_mae);
set(gca, 'XTickLabel', model_names);
title('供应预测 MAE 对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MAE', 'FontSize', 12);
grid on;
xtickangle(45);

% 需求预测误差对比
subplot(2, 2, 3);
bar(demand_rmse);
set(gca, 'XTickLabel', model_names);
title('需求预测 RMSE 对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('RMSE', 'FontSize', 12);
grid on;
xtickangle(45);

subplot(2, 2, 4);
bar(demand_mae);
set(gca, 'XTickLabel', model_names);
title('需求预测 MAE 对比', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('MAE', 'FontSize', 12);
grid on;
xtickangle(45);

% 调整布局
sgtitle('四模型性能对比分析', 'FontSize', 16, 'FontWeight', 'bold');

% 保存图形
saveas(gcf, fullfile(output_dir, 'four_models_performance_comparison.fig'));
saveas(gcf, fullfile(output_dir, 'four_models_performance_comparison.png'));

%% 6. 保存结果
fprintf('\n6. 保存结果...\n');

% 保存对比表
writetable(comparison_table, fullfile(output_dir, 'four_models_comparison_table.csv'));

% 保存MATLAB数据
save(fullfile(output_dir, 'four_models_comparison_results.mat'), ...
    'comparison_table', 'model_names', 'supply_rmse', 'supply_mae', ...
    'demand_rmse', 'demand_mae');

fprintf('\n=== 分析完成 ===\n');
fprintf('结果已保存到: %s\n', output_dir);
fprintf('- 对比表: four_models_comparison_table.csv\n');
fprintf('- 对比图: four_models_performance_comparison.png\n');
fprintf('- 数据文件: four_models_comparison_results.mat\n');