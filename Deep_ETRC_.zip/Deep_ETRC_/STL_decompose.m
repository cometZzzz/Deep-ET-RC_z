function U_decomposed = STL_decompose(U, stl_config)
%% STL_decompose - 季节性-趋势分解函数
% 对输入数据进行STL分解，支持可配置参数
%
% 输入参数:
%   U          - 数据结构体，包含:
%                U.u_train - 训练输入 (时间步 x 特征维度)
%                U.u_test  - 测试输入 (时间步 x 特征维度)
%                U.y_train - 训练目标
%                U.y_test  - 测试目标
%   stl_config - STL配置结构体，包含:
%                stl_config.enable         - 是否启用STL分解
%                stl_config.season_length  - 季节周期长度
%                stl_config.trend_window   - 趋势窗口大小
%                stl_config.seasonal_window- 季节窗口大小
%                stl_config.robust         - 是否使用鲁棒STL
%
% 输出:
%   U_decomposed - 分解后的数据结构体

    %% 参数验证
    if ~isstruct(U)
        error('STL_decompose: U必须是结构体');
    end
    
    if ~isstruct(stl_config)
        error('STL_decompose: stl_config必须是结构体');
    end
    
    % 如果未启用STL分解，直接返回原数据
    if ~stl_config.enable
        fprintf('STL分解已禁用，使用原始数据\n');
        U_decomposed = U;
        return;
    end
    
    fprintf('开始STL分解...\n');
    fprintf('季节长度: %d\n', stl_config.season_length);
    fprintf('趋势窗口: %d\n', stl_config.trend_window);
    fprintf('季节窗口: %d\n', stl_config.seasonal_window);
    
    %% 初始化输出结构体
    U_decomposed = U;
    
    %% 处理训练数据
    if isfield(U, 'u_train') && ~isempty(U.u_train)
        fprintf('分解训练数据...\n');
        U_decomposed.u_train = decompose_data(U.u_train, stl_config, '训练');
    end
    
    %% 处理测试数据
    if isfield(U, 'u_test') && ~isempty(U.u_test)
        fprintf('分解测试数据...\n');
        U_decomposed.u_test = decompose_data(U.u_test, stl_config, '测试');
    end
    
    fprintf('STL分解完成\n');
end

function decomposed_data = decompose_data(data, stl_config, data_type)
%% 对单个数据集进行STL分解
    
    [n_samples, n_features] = size(data);
    
    % 初始化分解后的数据 (样本数 x 特征数 x 3个分量)
    % 第三维: 1=季节性, 2=趋势性, 3=残差
    decomposed_data = zeros(n_samples, n_features, 3);
    
    for feat_idx = 1:n_features
        current_feature = data(:, feat_idx);
        
        % 检查数据长度是否足够进行分解
        min_length = stl_config.season_length * 2;
        if length(current_feature) < min_length
            warning('STL_decompose: %s数据第%d个特征长度不足(%d < %d)，跳过分解', ...
                    data_type, feat_idx, length(current_feature), min_length);
            
            % 不分解，将原数据放入趋势分量
            decomposed_data(:, feat_idx, 1) = zeros(n_samples, 1);  % 季节性 = 0
            decomposed_data(:, feat_idx, 2) = current_feature;       % 趋势 = 原数据
            decomposed_data(:, feat_idx, 3) = zeros(n_samples, 1);  % 残差 = 0
            continue;
        end
        
        try
            % 执行STL分解
            [trend, seasonal, remainder] = perform_stl_decomposition(...
                current_feature, stl_config);
            
            % 存储分解结果
            decomposed_data(:, feat_idx, 1) = seasonal;
            decomposed_data(:, feat_idx, 2) = trend;
            decomposed_data(:, feat_idx, 3) = remainder;
            
        catch ME
            warning('STL_decompose: %s数据第%d个特征分解失败: %s', ...
                    data_type, feat_idx, ME.message);
            
            % 分解失败，使用原数据
            decomposed_data(:, feat_idx, 1) = zeros(n_samples, 1);
            decomposed_data(:, feat_idx, 2) = current_feature;
            decomposed_data(:, feat_idx, 3) = zeros(n_samples, 1);
        end
    end
end

function [trend, seasonal, remainder] = perform_stl_decomposition(data, stl_config)
%% 执行STL分解的核心算法
    
    n = length(data);
    
    % 数据预处理
    data_clean = double(data);
    invalid_idx = ~isfinite(data_clean);
    
    if any(invalid_idx)
        % 用均值替换无效值
        valid_mean = mean(data_clean(~invalid_idx));
        if isfinite(valid_mean)
            data_clean(invalid_idx) = valid_mean;
        else
            data_clean(invalid_idx) = 0;
        end
    end
    
    %% 1. 趋势提取
    trend = extract_trend(data_clean, stl_config);
    
    %% 2. 季节性提取
    detrended = data_clean - trend;
    seasonal = extract_seasonal(detrended, stl_config);
    
    %% 3. 残差计算
    remainder = data_clean - trend - seasonal;
    
    %% 4. 鲁棒性处理
    if stl_config.robust
        [trend, seasonal, remainder] = robust_adjustment(...
            data_clean, trend, seasonal, remainder, stl_config);
    end
    
    %% 5. 最终检查和清理
    trend(~isfinite(trend)) = 0;
    seasonal(~isfinite(seasonal)) = 0;
    remainder(~isfinite(remainder)) = 0;
    
    % 确保分解的一致性: data = trend + seasonal + remainder
    reconstruction_error = data_clean - (trend + seasonal + remainder);
    if max(abs(reconstruction_error)) > 1e-10
        % 将重构误差分配给残差
        remainder = remainder + reconstruction_error;
    end
end

function trend = extract_trend(data, stl_config)
%% 提取趋势分量
    
    n = length(data);
    trend_window = stl_config.trend_window;
    
    % 确保窗口大小是奇数且合理
    if mod(trend_window, 2) == 0
        trend_window = trend_window + 1;
    end
    
    if trend_window > n
        trend_window = n;
        if mod(trend_window, 2) == 0
            trend_window = trend_window - 1;
        end
    end
    
    if trend_window < 3
        % 数据太短，使用线性趋势
        x = (1:n)';
        coeffs = polyfit(x, data, 1);
        trend = polyval(coeffs, x);
    else
        % 使用移动平均提取趋势
        half_window = floor(trend_window / 2);
        trend = zeros(n, 1);
        
        for i = 1:n
            start_idx = max(1, i - half_window);
            end_idx = min(n, i + half_window);
            trend(i) = mean(data(start_idx:end_idx));
        end
    end
end

function seasonal = extract_seasonal(detrended_data, stl_config)
%% 提取季节性分量
    
    n = length(detrended_data);
    season_length = stl_config.season_length;
    seasonal_window = stl_config.seasonal_window;
    
    % 初始化季节性分量
    seasonal = zeros(n, 1);
    
    if n < 2 * season_length
        % 数据太短，无法提取季节性
        return;
    end
    
    % 创建季节索引
    season_indices = mod(0:n-1, season_length)' + 1;
    
    % 对每个季节位置计算平滑平均值
    seasonal_means = zeros(season_length, 1);
    
    for s = 1:season_length
        % 找到所有属于当前季节位置的数据点
        pos_mask = (season_indices == s);
        pos_values = detrended_data(pos_mask);
        
        if ~isempty(pos_values)
            if length(pos_values) == 1
                seasonal_means(s) = pos_values;
            else
                % 使用移动平均平滑季节值
                if seasonal_window > 1 && length(pos_values) >= seasonal_window
                    seasonal_means(s) = mean(pos_values);
                else
                    seasonal_means(s) = mean(pos_values);
                end
            end
        end
    end
    
    % 确保季节分量的均值为零
    seasonal_means = seasonal_means - mean(seasonal_means);
    
    % 构建完整的季节性序列
    seasonal = seasonal_means(season_indices);
end

function [trend_robust, seasonal_robust, remainder_robust] = robust_adjustment(...
    data, trend, seasonal, remainder, stl_config)
%% 鲁棒性调整
    
    % 计算残差的鲁棒统计量
    abs_remainder = abs(remainder);
    median_abs_remainder = median(abs_remainder);
    
    if median_abs_remainder == 0
        % 如果中位数绝对残差为0，不进行鲁棒调整
        trend_robust = trend;
        seasonal_robust = seasonal;
        remainder_robust = remainder;
        return;
    end
    
    % 计算权重 (基于Tukey's biweight函数)
    c = 6 * median_abs_remainder;  % 调整参数
    weights = zeros(size(remainder));
    
    for i = 1:length(remainder)
        u = abs(remainder(i)) / c;
        if u <= 1
            weights(i) = (1 - u^2)^2;
        else
            weights(i) = 0;
        end
    end
    
    % 使用权重重新计算趋势和季节性
    % 这里简化处理，实际STL算法会进行多次迭代
    trend_robust = trend;
    seasonal_robust = seasonal;
    remainder_robust = remainder;
    
    % 对异常值进行调整
    outlier_threshold = 3 * median_abs_remainder;
    outlier_mask = abs_remainder > outlier_threshold;
    
    if any(outlier_mask)
        % 对异常值位置的残差进行调整
        remainder_robust(outlier_mask) = sign(remainder(outlier_mask)) * outlier_threshold;
        
        % 相应调整趋势或季节性分量以保持一致性
        adjustment = remainder(outlier_mask) - remainder_robust(outlier_mask);
        trend_robust(outlier_mask) = trend(outlier_mask) + adjustment;
    end
end