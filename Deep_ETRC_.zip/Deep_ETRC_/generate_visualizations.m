function visualization_results = generate_visualizations(supply_predictions, demand_predictions, ...
    balance_predictions, supply_actuals, demand_actuals, balance_actuals, ...
    performance_metrics, results_dir)
%% generate_visualizations - 生成Deep ET-RC实验结果可视化
% 
% 输入参数:
%   supply_predictions  - 供给预测结果 (cell array)
%   demand_predictions  - 消耗预测结果 (cell array)
%   balance_predictions - 供需关系预测结果 (cell array)
%   supply_actuals      - 供给实际值 (cell array)
%   demand_actuals      - 消耗实际值 (cell array)
%   balance_actuals     - 供需关系实际值 (cell array)
%   performance_metrics - 性能指标结构体数组
%   results_dir         - 结果保存目录
%
% 输出:
%   visualization_results - 可视化结果信息

    fprintf('生成可视化图表...\n');
    
    % 确保结果目录存在
    if ~exist(results_dir, 'dir')
        mkdir(results_dir);
    end
    
    max_horizon = length(supply_predictions);
    visualization_results = struct();
    
    %% 1. 多步预测结果对比图
    fprintf('  生成多步预测结果对比图...\n');
    
    % 选择几个代表性的预测步长进行可视化
    horizons_to_plot = min(4, max_horizon);
    selected_horizons = round(linspace(1, max_horizon, horizons_to_plot));
    
    for i = 1:length(selected_horizons)
        h = selected_horizons(i);
        
        % 创建预测结果对比图
        fig = figure('Position', [100, 100, 1200, 800], 'Visible', 'off');
        
        % 供给预测子图
        subplot(3, 1, 1);
        plot_prediction_comparison(supply_predictions{h}, supply_actuals{h}, ...
            sprintf('供给预测 (t+%d)', h), 'Supply');
        
        % 消耗预测子图
        subplot(3, 1, 2);
        plot_prediction_comparison(demand_predictions{h}, demand_actuals{h}, ...
            sprintf('消耗预测 (t+%d)', h), 'Demand');
        
        % 供需关系子图
        subplot(3, 1, 3);
        plot_prediction_comparison(balance_predictions{h}, balance_actuals{h}, ...
            sprintf('供需关系 (t+%d)', h), 'Balance');
        
        % 添加整体标题
        sgtitle(sprintf('Deep ET-RC 预测结果对比 - 步长 t+%d', h), ...
                'FontSize', 16, 'FontWeight', 'bold');
        
        % 保存图片
        filename = sprintf('prediction_comparison_horizon_%d.png', h);
        filepath = fullfile(results_dir, filename);
        saveas(fig, filepath);
        close(fig);
        
        fprintf('    保存预测对比图: %s\n', filename);
    end
    
    %% 2. 性能指标趋势图
    fprintf('  生成性能指标趋势图...\n');
    
    fig = figure('Position', [100, 100, 1400, 1000], 'Visible', 'off');
    
    % 提取性能指标数据
    horizons = 1:max_horizon;
    supply_rmse = [performance_metrics.supply_rmse];
    demand_rmse = [performance_metrics.demand_rmse];
    balance_rmse = [performance_metrics.balance_rmse];
    supply_r2 = [performance_metrics.supply_r2];
    demand_r2 = [performance_metrics.demand_r2];
    balance_r2 = [performance_metrics.balance_r2];
    
    % RMSE趋势图
    subplot(2, 2, 1);
    plot(horizons, supply_rmse, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
    hold on;
    plot(horizons, demand_rmse, 'r-s', 'LineWidth', 2, 'MarkerSize', 6);
    plot(horizons, balance_rmse, 'g-^', 'LineWidth', 2, 'MarkerSize', 6);
    xlabel('预测步长');
    ylabel('RMSE');
    title('RMSE 随预测步长变化');
    legend('供给', '消耗', '供需关系', 'Location', 'best');
    grid on;
    
    % R²趋势图
    subplot(2, 2, 2);
    plot(horizons, supply_r2, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
    hold on;
    plot(horizons, demand_r2, 'r-s', 'LineWidth', 2, 'MarkerSize', 6);
    plot(horizons, balance_r2, 'g-^', 'LineWidth', 2, 'MarkerSize', 6);
    xlabel('预测步长');
    ylabel('R²');
    title('R² 随预测步长变化');
    legend('供给', '消耗', '供需关系', 'Location', 'best');
    grid on;
    
    % 性能指标热力图
    subplot(2, 2, 3);
    metrics_matrix = [supply_rmse; demand_rmse; balance_rmse];
    imagesc(metrics_matrix);
    colorbar;
    colormap('hot');
    set(gca, 'XTick', 1:max_horizon, 'XTickLabel', horizons);
    set(gca, 'YTick', 1:3, 'YTickLabel', {'供给', '消耗', '供需关系'});
    xlabel('预测步长');
    title('RMSE 热力图');
    
    % 综合性能柱状图
    subplot(2, 2, 4);
    avg_rmse = [mean(supply_rmse), mean(demand_rmse), mean(balance_rmse)];
    avg_r2 = [mean(supply_r2), mean(demand_r2), mean(balance_r2)];
    
    x = categorical({'供给', '消耗', '供需关系'});
    yyaxis left;
    bar(x, avg_rmse, 'FaceColor', [0.2 0.6 0.8]);
    ylabel('平均 RMSE');
    yyaxis right;
    plot(x, avg_r2, 'ro-', 'LineWidth', 2, 'MarkerSize', 8);
    ylabel('平均 R²');
    title('平均性能指标');
    
    sgtitle('Deep ET-RC 性能指标分析', 'FontSize', 16, 'FontWeight', 'bold');
    
    % 保存性能指标图
    filename = 'performance_metrics_analysis.png';
    filepath = fullfile(results_dir, filename);
    saveas(fig, filepath);
    close(fig);
    
    fprintf('    保存性能指标图: %s\n', filename);
    
    %% 3. 误差分布图
    fprintf('  生成误差分布图...\n');
    
    fig = figure('Position', [100, 100, 1200, 800], 'Visible', 'off');
    
    % 计算所有步长的误差
    all_supply_errors = [];
    all_demand_errors = [];
    all_balance_errors = [];
    
    for h = 1:max_horizon
        supply_errors = supply_predictions{h} - supply_actuals{h};
        demand_errors = demand_predictions{h} - demand_actuals{h};
        balance_errors = balance_predictions{h} - balance_actuals{h};
        
        all_supply_errors = [all_supply_errors; supply_errors(:)];
        all_demand_errors = [all_demand_errors; demand_errors(:)];
        all_balance_errors = [all_balance_errors; balance_errors(:)];
    end
    
    % 供给误差分布
    subplot(2, 3, 1);
    histogram(all_supply_errors, 50, 'Normalization', 'probability', ...
              'FaceColor', [0.2 0.6 0.8], 'EdgeColor', 'none');
    xlabel('预测误差');
    ylabel('概率密度');
    title('供给预测误差分布');
    grid on;
    
    % 消耗误差分布
    subplot(2, 3, 2);
    histogram(all_demand_errors, 50, 'Normalization', 'probability', ...
              'FaceColor', [0.8 0.2 0.2], 'EdgeColor', 'none');
    xlabel('预测误差');
    ylabel('概率密度');
    title('消耗预测误差分布');
    grid on;
    
    % 供需关系误差分布
    subplot(2, 3, 3);
    histogram(all_balance_errors, 50, 'Normalization', 'probability', ...
              'FaceColor', [0.2 0.8 0.2], 'EdgeColor', 'none');
    xlabel('预测误差');
    ylabel('概率密度');
    title('供需关系误差分布');
    grid on;
    
    % Q-Q图检验正态性
    subplot(2, 3, 4);
    qqplot(all_supply_errors);
    title('供给误差 Q-Q 图');
    
    subplot(2, 3, 5);
    qqplot(all_demand_errors);
    title('消耗误差 Q-Q 图');
    
    subplot(2, 3, 6);
    qqplot(all_balance_errors);
    title('供需关系误差 Q-Q 图');
    
    sgtitle('预测误差分布分析', 'FontSize', 16, 'FontWeight', 'bold');
    
    % 保存误差分布图
    filename = 'error_distribution_analysis.png';
    filepath = fullfile(results_dir, filename);
    saveas(fig, filepath);
    close(fig);
    
    fprintf('    保存误差分布图: %s\n', filename);
    
    %% 4. 生成汇总报告
    fprintf('  生成实验汇总报告...\n');
    
    report_file = fullfile(results_dir, 'experiment_summary.txt');
    generate_summary_report(report_file, performance_metrics, ...
        all_supply_errors, all_demand_errors, all_balance_errors);
    
    %% 整理可视化结果
    visualization_results.figures_saved = {
        'prediction_comparison_*.png',
        'performance_metrics_analysis.png',
        'error_distribution_analysis.png'
    };
    visualization_results.summary_report = report_file;
    visualization_results.results_directory = results_dir;
    
    fprintf('可视化完成！所有图表已保存到: %s\n', results_dir);
end

function plot_prediction_comparison(predictions, actuals, title_str, data_type)
%% 绘制预测值与实际值对比图

    n_samples = min(length(predictions), length(actuals));
    x = 1:n_samples;
    
    plot(x, actuals(1:n_samples), 'b-', 'LineWidth', 2, 'DisplayName', '实际值');
    hold on;
    plot(x, predictions(1:n_samples), 'r--', 'LineWidth', 2, 'DisplayName', '预测值');
    
    xlabel('样本序号');
    ylabel('数值');
    title(title_str);
    legend('Location', 'best');
    grid on;
    
    % 计算并显示相关系数
    corr_coef = corr(actuals(1:n_samples), predictions(1:n_samples));
    text(0.02, 0.98, sprintf('相关系数: %.4f', corr_coef), ...
         'Units', 'normalized', 'VerticalAlignment', 'top', ...
         'BackgroundColor', 'white', 'EdgeColor', 'black');
end

function generate_summary_report(report_file, performance_metrics, ...
    supply_errors, demand_errors, balance_errors)
%% 生成实验汇总报告

    fid = fopen(report_file, 'w');
    if fid == -1
        warning('无法创建汇总报告文件: %s', report_file);
        return;
    end
    
    fprintf(fid, '=== Deep ET-RC 实验汇总报告 ===\n\n');
    fprintf(fid, '生成时间: %s\n\n', datestr(now));
    
    % 整体性能统计
    fprintf(fid, '1. 整体性能统计\n');
    fprintf(fid, '预测步长数量: %d\n', length(performance_metrics));
    
    % 供给预测统计
    supply_rmse = [performance_metrics.supply_rmse];
    supply_r2 = [performance_metrics.supply_r2];
    fprintf(fid, '\n供给预测:\n');
    fprintf(fid, '  平均 RMSE: %.6f (±%.6f)\n', mean(supply_rmse), std(supply_rmse));
    fprintf(fid, '  平均 R²: %.4f (±%.4f)\n', mean(supply_r2), std(supply_r2));
    fprintf(fid, '  最佳 RMSE: %.6f (步长 %d)\n', min(supply_rmse), find(supply_rmse == min(supply_rmse), 1));
    fprintf(fid, '  最佳 R²: %.4f (步长 %d)\n', max(supply_r2), find(supply_r2 == max(supply_r2), 1));
    
    % 消耗预测统计
    demand_rmse = [performance_metrics.demand_rmse];
    demand_r2 = [performance_metrics.demand_r2];
    fprintf(fid, '\n消耗预测:\n');
    fprintf(fid, '  平均 RMSE: %.6f (±%.6f)\n', mean(demand_rmse), std(demand_rmse));
    fprintf(fid, '  平均 R²: %.4f (±%.4f)\n', mean(demand_r2), std(demand_r2));
    fprintf(fid, '  最佳 RMSE: %.6f (步长 %d)\n', min(demand_rmse), find(demand_rmse == min(demand_rmse), 1));
    fprintf(fid, '  最佳 R²: %.4f (步长 %d)\n', max(demand_r2), find(demand_r2 == max(demand_r2), 1));
    
    % 供需关系统计
    balance_rmse = [performance_metrics.balance_rmse];
    balance_r2 = [performance_metrics.balance_r2];
    fprintf(fid, '\n供需关系:\n');
    fprintf(fid, '  平均 RMSE: %.6f (±%.6f)\n', mean(balance_rmse), std(balance_rmse));
    fprintf(fid, '  平均 R²: %.4f (±%.4f)\n', mean(balance_r2), std(balance_r2));
    fprintf(fid, '  最佳 RMSE: %.6f (步长 %d)\n', min(balance_rmse), find(balance_rmse == min(balance_rmse), 1));
    fprintf(fid, '  最佳 R²: %.4f (步长 %d)\n', max(balance_r2), find(balance_r2 == max(balance_r2), 1));
    
    % 误差统计
    fprintf(fid, '\n2. 误差统计分析\n');
    fprintf(fid, '供给预测误差:\n');
    fprintf(fid, '  均值: %.6f, 标准差: %.6f\n', mean(supply_errors), std(supply_errors));
    fprintf(fid, '  偏度: %.4f, 峰度: %.4f\n', skewness(supply_errors), kurtosis(supply_errors));
    
    fprintf(fid, '\n消耗预测误差:\n');
    fprintf(fid, '  均值: %.6f, 标准差: %.6f\n', mean(demand_errors), std(demand_errors));
    fprintf(fid, '  偏度: %.4f, 峰度: %.4f\n', skewness(demand_errors), kurtosis(demand_errors));
    
    fprintf(fid, '\n供需关系误差:\n');
    fprintf(fid, '  均值: %.6f, 标准差: %.6f\n', mean(balance_errors), std(balance_errors));
    fprintf(fid, '  偏度: %.4f, 峰度: %.4f\n', skewness(balance_errors), kurtosis(balance_errors));
    
    % 详细性能表
    fprintf(fid, '\n3. 详细性能表\n');
    fprintf(fid, '步长\t供给RMSE\t供给R²\t\t消耗RMSE\t消耗R²\t\t关系RMSE\t关系R²\n');
    for i = 1:length(performance_metrics)
        fprintf(fid, '%d\t%.6f\t%.4f\t\t%.6f\t%.4f\t\t%.6f\t%.4f\n', ...
                i, performance_metrics(i).supply_rmse, performance_metrics(i).supply_r2, ...
                performance_metrics(i).demand_rmse, performance_metrics(i).demand_r2, ...
                performance_metrics(i).balance_rmse, performance_metrics(i).balance_r2);
    end
    
    fclose(fid);
    fprintf('    保存汇总报告: experiment_summary.txt\n');
end