function net = train_lstm_model(X_seq, y_seq, config)
%TRAIN_LSTM_MODEL 训练LSTM回归模型
%
% 输入:
%   X_seq - 序列特征 [n_sequences x sequence_length x n_features]
%   y_seq - 目标序列 [n_sequences x 1]
%   config - 配置结构体
%
% 输出:
%   net - 训练好的LSTM网络

    fprintf('开始训练LSTM模型...\n');
    
    % 获取数据维度
    [n_sequences, sequence_length, n_features] = size(X_seq);
    fprintf('训练数据: %d个序列，序列长度=%d，特征维度=%d\n', ...
            n_sequences, sequence_length, n_features);
    
    % 转换数据格式为cell数组（MATLAB LSTM要求）
    X_cell = cell(n_sequences, 1);
    
    for i = 1:n_sequences
        % 转置以符合MATLAB LSTM输入格式 [n_features x sequence_length]
        X_cell{i} = squeeze(X_seq(i, :, :))';
    end
    
    % 响应变量保持为向量格式
    y_vector = y_seq;
    
    % 定义LSTM网络架构
    layers = [
        sequenceInputLayer(n_features, 'Name', 'input')
        lstmLayer(config.hidden_units, 'OutputMode', 'sequence', 'Name', 'lstm1')
        dropoutLayer(config.dropout_rate, 'Name', 'dropout1')
    ];
    
    % 添加额外的LSTM层（如果配置了多层）
    if config.num_layers > 1
        for layer_idx = 2:config.num_layers-1
            layers = [layers
                lstmLayer(config.hidden_units, 'OutputMode', 'sequence', ...
                         'Name', sprintf('lstm%d', layer_idx))
                dropoutLayer(config.dropout_rate, 'Name', sprintf('dropout%d', layer_idx))
            ];
        end
        % 最后一层LSTM输出最后时间步
        layers = [layers
            lstmLayer(config.hidden_units, 'OutputMode', 'last', ...
                     'Name', sprintf('lstm%d', config.num_layers))
        ];
    else
        % 单层LSTM，修改输出模式为last
        layers(2) = lstmLayer(config.hidden_units, 'OutputMode', 'last', 'Name', 'lstm1');
    end
    
    % 添加全连接层和回归输出层
    layers = [layers
        fullyConnectedLayer(1, 'Name', 'fc')
        regressionLayer('Name', 'output')
    ];
    
    % 训练选项
    options = trainingOptions('adam', ...
        'MaxEpochs', config.max_epochs, ...
        'MiniBatchSize', config.mini_batch_size, ...
        'InitialLearnRate', config.learning_rate, ...
        'LearnRateSchedule', 'piecewise', ...
        'LearnRateDropFactor', 0.5, ...
        'LearnRateDropPeriod', 20, ...
        'GradientThreshold', 1, ...
        'ValidationFrequency', 10, ...
        'ValidationPatience', config.validation_patience, ...
        'Shuffle', 'every-epoch', ...
        'Verbose', true, ...
        'Plots', 'none', ...
        'ExecutionEnvironment', 'auto');
    
    % 数据分割（80%训练，20%验证）
    n_train = round(0.8 * n_sequences);
    train_idx = 1:n_train;
    val_idx = (n_train+1):n_sequences;
    
    X_train = X_cell(train_idx);
    y_train = y_vector(train_idx);
    X_val = X_cell(val_idx);
    y_val = y_vector(val_idx);
    
    % 设置验证数据
    options.ValidationData = {X_val, y_val};
    
    fprintf('训练集大小: %d, 验证集大小: %d\n', length(X_train), length(X_val));
    
    % 训练网络
    fprintf('开始训练LSTM网络...\n');
    tic;
    net = trainNetwork(X_train, y_train, layers, options);
    training_time = toc;
    
    fprintf('LSTM训练完成，用时: %.2f秒\n', training_time);
    
    % 在验证集上评估性能
    y_val_pred = predict(net, X_val);
    y_val_actual = y_val;
    val_rmse = sqrt(mean((y_val_pred - y_val_actual).^2));
    val_mae = mean(abs(y_val_pred - y_val_actual));
    
    fprintf('验证集性能: RMSE=%.4f, MAE=%.4f\n', val_rmse, val_mae);
end