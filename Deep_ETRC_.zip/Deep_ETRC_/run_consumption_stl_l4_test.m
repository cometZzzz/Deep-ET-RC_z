% 代码用途：单次运行 Consumption + STL + L4 并保存结果
% 简介：调用 deep_et_rc_basic(settings) 生成图与指标

outDir = fullfile('D:\eqrthquake\太阳能发电供需预测\代码\STL-DeepETRC_分析\Deep_ETRC_EXP','NewResult','Exp2_1');
if ~exist(outDir, 'dir'); mkdir(outDir); end

settings = struct();
settings.TARGET_NAME = 'Consumption';
settings.USE_STL = true;
settings.NUM_ET_LAYERS = 4;
settings.RES_SIZES = [120, 100, 80, 60];
settings.LEAK_RATES = [0.5, 0.4, 0.35, 0.3];
settings.SPECTRAL_RADII = 0.90 * ones(1, 4);
settings.RIDGE_REG = 1e-4;
settings.SPARSITY = 0.1;
settings.AUTO_WASHOUT = true;
settings.WASHOUT_USER = 168;  % 与季节长度一致，保证瞬态充分洗出
settings.APPEND_INPUT_TO_READOUT = true;
settings.STATE_STANDARDIZE = true;
settings.USE_FIXED_FEATURES = false;
settings.INCLUDE_TARGET_IN_FEATURES = true;
settings.EXCLUDE_DATETIME = true;
settings.STL_SEASON_LENGTH_HOURS = 168;
settings.STL_USE_REMAINDER_AS_TARGET = true;
settings.STL_APPEND_COMPONENTS_TO_FEATURES = true;
settings.SAVE_RESULTS = true;
settings.OUTPUT_DIR = outDir;
settings.EXP_NAME = 'Consumption_STL_L4';

deep_et_rc_basic(settings);
close all;