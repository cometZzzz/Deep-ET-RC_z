% 代码用途：批量运行 Exp2_1 的16组实验（Supply/Consumption × 是否STL × ET层数1-4）
% 简介：调用 deep_et_rc_basic(settings) 生成预测图与评估指标，并保存到指定目录

% 脚本模式，便于 batch 调用与错误记录
outDir = fullfile('D:\eqrthquake\太阳能发电供需预测\代码\STL-DeepETRC_分析\Deep_ETRC_EXP','NewResult','Exp2_1');
if ~exist(outDir, 'dir'); mkdir(outDir); end
logFile = fullfile(outDir, 'run_log.txt');
errFile = fullfile(outDir, 'errors.txt');
diary(logFile);

targets = {'Supply','Consumption'};
layers_list = [1 2 3 4];
stl_opts = [false true];

for ti = 1:numel(targets)
    tgt = targets{ti};
    for si = 1:numel(stl_opts)
        use_stl = stl_opts(si);
        for li = 1:numel(layers_list)
            L = layers_list(li);
            exp_name = sprintf('%s_%s_L%d', tgt, ternary(use_stl,'STL','NoSTL'), L);
            settings = struct();
            settings.TARGET_NAME = tgt;
            settings.USE_STL = use_stl;
            settings.NUM_ET_LAYERS = L;
            % 稳定性与通用配置
            settings.RES_SIZES = max(20, round(linspace(120, 60, L))); % 逐层递减
            settings.LEAK_RATES = linspace(0.5, 0.3, L);
            settings.SPECTRAL_RADII = 0.90 * ones(1, L);
            settings.RIDGE_REG = 1e-4;
            settings.SPARSITY = 0.1;
            settings.AUTO_WASHOUT = true;
            settings.WASHOUT_USER = 48;
            settings.APPEND_INPUT_TO_READOUT = true;
            settings.STATE_STANDARDIZE = true;
            % 特征选择：全部数值列，包含目标历史
            settings.USE_FIXED_FEATURES = false;
            settings.INCLUDE_TARGET_IN_FEATURES = true;
            settings.EXCLUDE_DATETIME = true;
            % STL参数（如开启）
            settings.STL_SEASON_LENGTH_HOURS = 168;
            settings.STL_USE_REMAINDER_AS_TARGET = true;
            settings.STL_APPEND_COMPONENTS_TO_FEATURES = true;
            % 保存输出
            settings.SAVE_RESULTS = true;
            settings.OUTPUT_DIR = outDir;
            settings.EXP_NAME = exp_name;

            fprintf('\n>>> 运行实验：%s\n', exp_name);
            try
                deep_et_rc_basic(settings);
            catch ME
                fid = fopen(errFile, 'a');
                fprintf(fid, '[%s] %s: %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'), exp_name, ME.message);
                fclose(fid);
            end
            close all;
        end
    end
end

fprintf('\n所有16组实验已完成，输出目录：%s\n', outDir);
diary off;

function y = ternary(cond, a, b)
    if cond
        y = a;
    else
        y = b;
    end
end
% 允许脚本内本地函数