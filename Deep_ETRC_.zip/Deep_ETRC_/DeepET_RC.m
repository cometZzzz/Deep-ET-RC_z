function output = DeepET_RC(N, params_RC, params_ET, U)
%% DeepET_RC - 逐层补偿的深度 ET-RC 模型
% 用途与简介：
% 本函数实现论文所述“逐层补偿”结构：
% - 第1层为 RC（基准预测），得到 comp_0(t)；
% - 第 i 层（i>=2）为 ET 层，输入为上一层预测与其上一时刻误差的补偿信号：
%   x_i(t) = yhat_{i-1}(t) - err_{i-1}(t-1)，其中 err_{i-1}(t) = y(t+H) - yhat_{i-1}(t)
% - 第 i 层输出为补偿项 delta_i(t)，并累加到上一层预测：yhat_i(t) = yhat_{i-1}(t) + delta_i(t)
% 训练与测试均采用滞后一时刻的误差作为输入的一部分，避免未来信息泄露。
% 输入参数:
%   N         - 网络层数 (>=2, 包含1个RC层和N-1个ET层)
%   params_RC - RC层参数结构体
%   params_ET - ET层参数结构体
%   U         - 输入数据结构体 (包含u_train, u_test, y_train, y_test)
% 输出:
%   output    - 预测结果、各层输出与性能指标

    %% 参数验证
    if N < 2
        error('DeepET_RC: 网络层数N必须至少为2 (1个RC层 + 至少1个ET层)');
    end
    
    if ~isstruct(params_RC)
        error('DeepET_RC: params_RC必须是结构体');
    end
    
    if ~isstruct(params_ET)
        error('DeepET_RC: params_ET必须是结构体');
    end
    
    if ~isstruct(U) || ~all(isfield(U, {'u_train', 'u_test', 'y_train', 'y_test'}))
        error('DeepET_RC: U必须包含u_train, u_test, y_train, y_test字段');
    end
    
    %% 数据预处理
    % 转换为double类型并处理NaN/Inf
    U.u_train = double(U.u_train);
    U.u_test = double(U.u_test);
    U.y_train = double(U.y_train);
    U.y_test = double(U.y_test);
    
    % 检查并处理异常值
    U.u_train(~isfinite(U.u_train)) = 0;
    U.u_test(~isfinite(U.u_test)) = 0;
    U.y_train(~isfinite(U.y_train)) = 0;
    U.y_test(~isfinite(U.y_test)) = 0;
    
    %% 处理ET层参数
    % 将params_ET转换为结构体数组以便处理多层
    if ~isfield(params_ET, 'layer1')
        % 如果params_ET不是分层结构，则复制为所有ET层使用相同参数
        temp_params = params_ET;
        params_ET = struct();
        for i = 1:N-1
            params_ET.(sprintf('layer%d', i)) = temp_params;
        end
    end
    
    %% 初始化变量
    train_size = size(U.u_train, 1);
    test_size = size(U.u_test, 1);
    
    % 存储每层的预测结果
    layer_outputs = cell(N, 1);
    
    %% 第一层: RC层训练（基准预测 comp_0）
    fprintf('训练RC层 (第1层)...\n');

    U_RC = struct();
    U_RC.u_train = U.u_train;
    U_RC.u_test  = U.u_test;
    U_RC.y_train = U.y_train;
    U_RC.y_test  = U.y_test;

    try
        rc_result = ESNnet(U_RC, params_RC);
        layer_outputs{1} = rc_result;
    catch ME
        error('DeepET_RC: RC层训练失败 - %s', ME.message);
    end

    % 从 ESN 输出中提取训练/测试预测
    rc_train_pred = rc_result.tarin_;
    rc_test_pred  = rc_result.y_prediction';

    % 检查并修正异常值
    rc_train_pred(~isfinite(rc_train_pred)) = 0;
    rc_test_pred(~isfinite(rc_test_pred))   = 0;

    % 维度匹配
    if length(rc_train_pred) ~= length(U.y_train)
        min_len = min(length(rc_train_pred), length(U.y_train));
        rc_train_pred = rc_train_pred(1:min_len);
        U.y_train     = U.y_train(1:min_len);
    end

    if length(rc_test_pred) ~= length(U.y_test)
        min_len = min(length(rc_test_pred), length(U.y_test));
        rc_test_pred = rc_test_pred(1:min_len);
        U.y_test     = U.y_test(1:min_len);
    end

    % 初始化逐层补偿：comp_0 和残差 r_0
    comp_train = rc_train_pred;
    comp_test  = rc_test_pred;
    resid_train = U.y_train - comp_train;
    resid_test  = U.y_test  - comp_test;

    %% ET层逐层补偿 (第2层到第N层)
    for layer = 2:N
        fprintf('训练ET层 (第%d层)...\n', layer);

        % 获取当前层参数
        layer_name = sprintf('layer%d', layer-1);
        if isfield(params_ET, layer_name)
            current_params = params_ET.(layer_name);
        else
            error('DeepET_RC: 缺少第%d层ET参数', layer-1);
        end

        % 构造逐层补偿输入：x_i(t) = yhat_{i-1}(t) - err_{i-1}(t-1)
        resid_train_lag = [0; resid_train(1:end-1)];
        resid_test_lag  = [resid_train(end); resid_test(1:end-1)];
        x_train = comp_train - resid_train_lag;
        x_test  = comp_test  - resid_test_lag;

        % 该层目标为上一层残差：r_i(t) = y(t+H) - yhat_{i-1}(t)
        U_ET = struct();
        U_ET.u_train = x_train;
        U_ET.u_test  = x_test;
        U_ET.y_train = resid_train;
        U_ET.y_test  = resid_test;

        % 训练当前ET层，预测补偿项 delta_i
        try
            et_result = ESNnet(U_ET, current_params);
            layer_outputs{layer} = et_result;
        catch ME
            warning('DeepET_RC: 第%d层ET训练失败，跳过 - %s', layer, ME.message);
            continue;
        end

        delta_train = et_result.tarin_;
        delta_test  = et_result.y_prediction';

        % 修正异常值
        delta_train(~isfinite(delta_train)) = 0;
        delta_test(~isfinite(delta_test))   = 0;

        % 维度匹配（按训练残差长度裁剪）
        if length(delta_train) ~= length(resid_train)
            min_len = min(length(delta_train), length(resid_train));
            delta_train = delta_train(1:min_len);
            resid_train = resid_train(1:min_len);
        end
        if length(delta_test) ~= length(resid_test)
            min_len = min(length(delta_test), length(resid_test));
            delta_test = delta_test(1:min_len);
            resid_test = resid_test(1:min_len);
        end

        % 累加补偿得到新的 comp_i，并更新残差 r_i
        comp_train = comp_train + delta_train;
        comp_test  = comp_test  + delta_test;
        resid_train = U.y_train - comp_train;
        resid_test  = U.y_test  - comp_test;
    end

    %% 最终预测为 comp_L(t)
    final_train_pred = comp_train;
    final_test_pred  = comp_test;
    
    % 处理最终预测中的异常值
    final_train_pred(~isfinite(final_train_pred)) = rc_result.train_pred(~isfinite(final_train_pred));
    final_test_pred(~isfinite(final_test_pred)) = rc_result.test_pred(~isfinite(final_test_pred));
    
    %% 计算性能指标
    % 训练集性能
    train_mse = calculate_mse(U.y_train, final_train_pred);
    train_rmse = sqrt(train_mse);
    train_mae = calculate_mae(U.y_train, final_train_pred);
    
    % 测试集性能
    test_mse = calculate_mse(U.y_test, final_test_pred);
    test_rmse = sqrt(test_mse);
    test_mae = calculate_mae(U.y_test, final_test_pred);
    
    %% 输出结果
    output = struct();
    output.train_pred = final_train_pred;
    output.test_pred  = final_test_pred;
    output.train_mse  = train_mse;
    output.train_rmse = train_rmse;
    output.train_mae  = train_mae;
    output.test_mse   = test_mse;
    output.test_rmse  = test_rmse;
    output.test_mae   = test_mae;
    output.layer_outputs = layer_outputs;
    
    fprintf('DeepET_RC训练完成 - 测试RMSE: %.6f\n', test_rmse);
end

%% 辅助函数
function mse = calculate_mse(y_true, y_pred)
    % 计算均方误差，处理异常值
    if length(y_true) ~= length(y_pred)
        min_len = min(length(y_true), length(y_pred));
        y_true = y_true(1:min_len);
        y_pred = y_pred(1:min_len);
    end
    
    valid_idx = isfinite(y_true) & isfinite(y_pred);
    if sum(valid_idx) == 0
        mse = Inf;
    else
        mse = mean((y_true(valid_idx) - y_pred(valid_idx)).^2);
    end
end

function mae = calculate_mae(y_true, y_pred)
    % 计算平均绝对误差，处理异常值
    if length(y_true) ~= length(y_pred)
        min_len = min(length(y_true), length(y_pred));
        y_true = y_true(1:min_len);
        y_pred = y_pred(1:min_len);
    end
    
    valid_idx = isfinite(y_true) & isfinite(y_pred);
    if sum(valid_idx) == 0
        mae = Inf;
    else
        mae = mean(abs(y_true(valid_idx) - y_pred(valid_idx)));
    end
end